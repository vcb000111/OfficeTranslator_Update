# -*- coding: utf-8 -*-
"""
Update Checker Module
====================
Handles checking for application updates from remote server.
"""

import sys
import os
import json
from typing import Optional, Dict
from urllib.parse import quote

# Import requests for update check
try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

# ============================================================================
# UPDATE CHECK CONFIGURATION
# ============================================================================
# URLs for update check
VERSION_CHECK_URL = "https://raw.githubusercontent.com/vcb000111/OfficeTranslator_Update/main/version.txt"
UPDATE_LINK_URL = "https://raw.githubusercontent.com/vcb000111/OfficeTranslator_Update/main/update_link.txt"

# Timeout for update check (seconds)
UPDATE_CHECK_TIMEOUT = 5

# Enable/disable auto update check
AUTO_CHECK_UPDATES = True
# ============================================================================

# Proxy configuration
PROXY_SETTINGS_FILE = ".proxy_settings.json"


def get_current_version() -> str:
    """
    Get current version from version.txt file
    Tries multiple locations:
    1. Same directory as executable (when running as exe)
    2. _internal directory (onedir mode - files are in _internal/)
    3. Same directory as this file (src/version.txt) - when running as script
    4. Parent directory (version.txt) - when running as script
    
    Returns:
        str: Current version string, or "3.1" as fallback
    """
    fallback_version = "3.1"
    
    # Try to find version.txt file
    possible_paths = []
    
    if getattr(sys, 'frozen', False):
        # Running as exe
        exe_dir = os.path.dirname(sys.executable)
        # Try same directory as exe
        possible_paths.append(os.path.join(exe_dir, "version.txt"))
        # Try _internal directory (onedir mode)
        internal_dir = os.path.join(exe_dir, "_internal")
        possible_paths.append(os.path.join(internal_dir, "version.txt"))
    else:
        # Running as script
        # Try src/version.txt (same directory as this file)
        this_file_dir = os.path.dirname(os.path.abspath(__file__))
        possible_paths.append(os.path.join(this_file_dir, "version.txt"))
        
        # Try parent directory version.txt
        parent_dir = os.path.dirname(this_file_dir)
        possible_paths.append(os.path.join(parent_dir, "version.txt"))
    
    # Try to read version from file
    for version_path in possible_paths:
        try:
            if os.path.exists(version_path):
                with open(version_path, 'r', encoding='utf-8') as f:
                    version = f.read().strip()
                    if version:
                        # Log for debugging (only in development)
                        if not getattr(sys, 'frozen', False):
                            print(f"[Update Check] Loaded version from: {version_path} -> {version}")
                        return version
        except Exception as e:
            # Log for debugging (only in development)
            if not getattr(sys, 'frozen', False):
                print(f"[Update Check] Error reading {version_path}: {str(e)}")
            continue
    
    # Fallback to default version
    if not getattr(sys, 'frozen', False):
        print(f"[Update Check] Could not find version.txt, using fallback: {fallback_version}")
    return fallback_version


# Get current version (will be read from file)
CURRENT_VERSION = get_current_version()


def get_proxy_settings_file() -> str:
    """Get path to proxy settings file"""
    if getattr(sys, 'frozen', False):
        # Running as exe
        exe_dir = os.path.dirname(sys.executable)
        return os.path.join(exe_dir, PROXY_SETTINGS_FILE)
    else:
        # Running as script
        script_dir = os.path.dirname(os.path.abspath(__file__))
        parent_dir = os.path.dirname(script_dir)
        return os.path.join(parent_dir, PROXY_SETTINGS_FILE)

def load_proxy_settings() -> Optional[Dict[str, str]]:
    """
    Load proxy settings from file
    
    Returns:
        Optional[Dict]: Dictionary with 'http', 'https' proxy URLs and optional 'username', 'password', or None
    """
    proxy_file = get_proxy_settings_file()
    try:
        if os.path.exists(proxy_file):
            with open(proxy_file, 'r', encoding='utf-8') as f:
                settings = json.load(f)
                if settings.get('http') or settings.get('https'):
                    return settings
    except Exception as e:
        if not getattr(sys, 'frozen', False):
            print(f"[Update Check] Error loading proxy settings: {str(e)}")
    return None

def save_proxy_settings(proxy_dict: Dict[str, str]) -> bool:
    """
    Save proxy settings to file
    
    Args:
        proxy_dict: Dictionary with 'http' and/or 'https' proxy URLs
        
    Returns:
        bool: True if saved successfully, False otherwise
    """
    proxy_file = get_proxy_settings_file()
    try:
        with open(proxy_file, 'w', encoding='utf-8') as f:
            json.dump(proxy_dict, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        if not getattr(sys, 'frozen', False):
            print(f"[Update Check] Error saving proxy settings: {str(e)}")
        return False

def normalize_proxy_url(url: str) -> str:
    """
    Normalize proxy URL - ensure it has proper format
    
    Args:
        url: Proxy URL (may or may not have http:// prefix)
        
    Returns:
        str: Normalized proxy URL with http:// prefix
    """
    if not url:
        return url
    
    url = url.strip()
    
    # Remove all duplicate http:// or https:// prefixes
    while url.startswith('http://http://') or url.startswith('https://http://') or url.startswith('http://https://'):
        if url.startswith('http://http://'):
            url = url[7:]  # Remove first "http://"
        elif url.startswith('https://http://'):
            url = url[8:]  # Remove "https://"
        elif url.startswith('http://https://'):
            url = url[7:]  # Remove "http://"
    
    # If URL already has http:// or https://, return as is
    if url.startswith('http://') or url.startswith('https://'):
        return url
    
    # Add http:// if not present
    url = f"http://{url}"
    
    return url

def detect_system_proxy() -> Optional[Dict[str, str]]:
    """
    Detect proxy settings from system environment variables
    
    Returns:
        Optional[Dict]: Dictionary with 'http' and 'https' proxy URLs, or None
    """
    proxy_dict = {}
    
    # Check environment variables
    http_proxy = os.environ.get('HTTP_PROXY') or os.environ.get('http_proxy')
    https_proxy = os.environ.get('HTTPS_PROXY') or os.environ.get('https_proxy')
    
    if http_proxy:
        proxy_dict['http'] = normalize_proxy_url(http_proxy)
    if https_proxy:
        proxy_dict['https'] = normalize_proxy_url(https_proxy)
    
    # Check Windows registry for proxy (if on Windows)
    if sys.platform == "win32":
        try:
            import winreg
            # Check Internet Settings proxy
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"
            )
            try:
                proxy_enable = winreg.QueryValueEx(key, "ProxyEnable")[0]
                if proxy_enable:
                    proxy_server = winreg.QueryValueEx(key, "ProxyServer")[0]
                    if proxy_server:
                        # Format: "proxy:port" or "http=proxy:port;https=proxy:port"
                        if '=' in proxy_server:
                            # Multiple proxies
                            for part in proxy_server.split(';'):
                                if '=' in part:
                                    proto, addr = part.split('=', 1)
                                    # Normalize to avoid duplicate http://
                                    normalized = normalize_proxy_url(addr)
                                    proxy_dict[proto.lower()] = normalized
                        else:
                            # Single proxy for both
                            normalized = normalize_proxy_url(proxy_server)
                            if 'http' not in proxy_dict:
                                proxy_dict['http'] = normalized
                            if 'https' not in proxy_dict:
                                proxy_dict['https'] = normalized
            finally:
                winreg.CloseKey(key)
        except Exception:
            pass  # Ignore registry errors
    
    return proxy_dict if proxy_dict else None

def get_proxy_config() -> Optional[Dict[str, str]]:
    """
    Get proxy configuration from multiple sources (priority order):
    1. Saved proxy settings file
    2. System environment variables
    3. Windows registry (if Windows)
    
    Returns:
        Optional[Dict]: Dictionary with 'http' and 'https' proxy URLs, or None
    """
    # Try saved settings first
    saved_proxy = load_proxy_settings()
    if saved_proxy:
        return saved_proxy
    
    # Try system detection
    system_proxy = detect_system_proxy()
    if system_proxy:
        # Save detected proxy for future use
        save_proxy_settings(system_proxy)
        return system_proxy
    
    return None

def compare_versions(current: str, latest: str) -> bool:
    """
    Compare version strings
    Returns True if latest > current
    Format: "3.1" or "3.1.1"
    
    Args:
        current: Current version string
        latest: Latest version string from server
        
    Returns:
        bool: True if latest > current, False otherwise
    """
    try:
        # Split version strings into parts
        current_parts = [int(x) for x in current.split('.')]
        latest_parts = [int(x) for x in latest.split('.')]
        
        # Pad with zeros to make same length
        max_len = max(len(current_parts), len(latest_parts))
        current_parts += [0] * (max_len - len(current_parts))
        latest_parts += [0] * (max_len - len(latest_parts))
        
        # Compare each part
        for i in range(max_len):
            if latest_parts[i] > current_parts[i]:
                return True
            elif latest_parts[i] < current_parts[i]:
                return False
        return False  # Versions are equal
    except Exception:
        # If parsing fails, do string comparison
        return latest > current


def build_proxy_url(proxy_config: Dict[str, str]) -> Dict[str, str]:
    """
    Build proxy URL with authentication if username/password provided
    
    Args:
        proxy_config: Dictionary with 'http', 'https', optional 'username', 'password'
        
    Returns:
        Dict[str, str]: Dictionary with 'http' and 'https' proxy URLs with auth
    """
    proxies = {}
    username = proxy_config.get('username', '').strip()
    password = proxy_config.get('password', '').strip()
    
    for proto in ['http', 'https']:
        if proto in proxy_config:
            proxy_url = proxy_config[proto].strip()
            
            # Normalize proxy URL first (remove any duplicate http://)
            proxy_url = normalize_proxy_url(proxy_url)
            
            # Add authentication if provided
            if username and password:
                # URL encode username and password to handle special characters
                encoded_username = quote(username, safe='')
                encoded_password = quote(password, safe='')
                
                # Check if URL already has authentication
                if '@' in proxy_url:
                    # Remove existing auth if present
                    if '://' in proxy_url:
                        scheme, rest = proxy_url.split('://', 1)
                        if '@' in rest:
                            rest = rest.split('@', 1)[1]  # Remove existing auth
                        proxy_url = f"{scheme}://{encoded_username}:{encoded_password}@{rest}"
                else:
                    # Add authentication
                    if proxy_url.startswith('http://'):
                        proxy_url = proxy_url.replace('http://', f'http://{encoded_username}:{encoded_password}@', 1)
                    elif proxy_url.startswith('https://'):
                        proxy_url = proxy_url.replace('https://', f'https://{encoded_username}:{encoded_password}@', 1)
                    else:
                        proxy_url = f'http://{encoded_username}:{encoded_password}@{proxy_url}'
            
            proxies[proto] = proxy_url
    
    return proxies

def get_latest_version(proxy_config: Optional[Dict[str, str]] = None, log_callback=None) -> Optional[str]:
    """
    Get latest version from server
    
    Args:
        proxy_config: Optional proxy configuration dictionary (may include username/password)
        log_callback: Optional callback function to log messages (for GUI logging)
        
    Returns:
        Optional[str]: Latest version string, or None if error
    """
    def log_msg(msg: str):
        """Log message to both console and callback"""
        if not getattr(sys, 'frozen', False):
            print(f"[Update Check] {msg}")
        if log_callback:
            log_callback(f"[Update Check] {msg}")
    
    if not REQUESTS_AVAILABLE:
        log_msg("requests module not available")
        return None
    
    # Get proxy config if not provided
    if proxy_config is None:
        proxy_config = get_proxy_config()
    
    # Log proxy configuration (without password)
    if proxy_config:
        safe_config = {k: v for k, v in proxy_config.items() if k != 'password'}
        log_msg(f"Proxy config: {safe_config}")
    else:
        log_msg("No proxy configuration")
    
    # Build proxy URLs with authentication
    proxies = None
    if proxy_config:
        proxies = build_proxy_url(proxy_config)
        # Don't log password, but log proxy URLs (without showing password)
        safe_proxies = {}
        for k, v in proxies.items():
            # Hide password in logged URL
            if '@' in v:
                parts = v.split('@')
                if len(parts) == 2:
                    auth_part = parts[0]
                    if '://' in auth_part:
                        scheme = auth_part.split('://')[0]
                        auth_rest = auth_part.split('://')[1]
                        if ':' in auth_rest:
                            user_part = auth_rest.split(':')[0]
                            server_part = parts[1]
                            safe_proxies[k] = f"{scheme}://{user_part}:***@{server_part}"
                        else:
                            safe_proxies[k] = v
                    elif ':' in auth_part:
                        user_part = auth_part.split(':')[0]
                        safe_proxies[k] = f"{user_part}:***@{parts[1]}"
                    else:
                        safe_proxies[k] = v
                else:
                    safe_proxies[k] = v
            else:
                safe_proxies[k] = v
        
        log_msg(f"Proxy URLs (built): {safe_proxies}")
    
    try:
        log_msg(f"Fetching version from: {VERSION_CHECK_URL}")
        log_msg(f"Timeout: {UPDATE_CHECK_TIMEOUT}s")
        
        # Disable SSL verification when using proxy (many corporate proxies use self-signed certs)
        # Always disable SSL verify when using proxy to avoid certificate issues
        verify_ssl = False if proxies else True
        
        if proxies:
            log_msg("SSL verification disabled (proxy may use self-signed certificate)")
        
        response = requests.get(
            VERSION_CHECK_URL, 
            timeout=UPDATE_CHECK_TIMEOUT,
            proxies=proxies,
            verify=verify_ssl
        )
        
        log_msg(f"Response status: {response.status_code}")
        response.raise_for_status()
        version = response.text.strip()
        
        log_msg(f"Fetched version from server: '{version}'")
        return version if version else None
        
    except requests.exceptions.ProxyError as e:
        error_detail = str(e)
        log_msg(f"✗ ProxyError: {error_detail}")
        # Log proxy URL format for debugging (without password)
        if proxies:
            safe_proxies = {}
            for k, v in proxies.items():
                if '@' in v:
                    parts = v.split('@')
                    if len(parts) == 2:
                        auth_part = parts[0]
                        if '://' in auth_part:
                            scheme = auth_part.split('://')[0]
                            auth_rest = auth_part.split('://')[1]
                            if ':' in auth_rest:
                                user_part = auth_rest.split(':')[0]
                                server_part = parts[1]
                                safe_proxies[k] = f"{scheme}://{user_part}:***@{server_part}"
                            else:
                                safe_proxies[k] = v
                        elif ':' in auth_part:
                            user_part = auth_part.split(':')[0]
                            safe_proxies[k] = f"{user_part}:***@{parts[1]}"
                        else:
                            safe_proxies[k] = v
                    else:
                        safe_proxies[k] = v
                else:
                    safe_proxies[k] = v
            log_msg(f"Proxy URLs used: {safe_proxies}")
        return None
    except requests.exceptions.Timeout as e:
        error_detail = f"Timeout khi kết nối đến server (>{UPDATE_CHECK_TIMEOUT}s): {str(e)}"
        log_msg(f"✗ {error_detail}")
        return None
    except requests.exceptions.ConnectionError as e:
        error_detail = str(e)
        # Check if it's SSL certificate error
        if 'CERTIFICATE_VERIFY_FAILED' in error_detail or 'SSL' in error_detail:
            log_msg(f"✗ SSL Certificate Error: {error_detail}")
            log_msg("Proxy đang sử dụng self-signed certificate")
            log_msg("Đang thử lại với SSL verification disabled...")
            
            # Retry with SSL verification disabled
            try:
                response = requests.get(
                    VERSION_CHECK_URL, 
                    timeout=UPDATE_CHECK_TIMEOUT,
                    proxies=proxies,
                    verify=False
                )
                log_msg(f"Response status (retry): {response.status_code}")
                response.raise_for_status()
                version = response.text.strip()
                log_msg(f"Fetched version from server (retry): '{version}'")
                return version if version else None
            except Exception as retry_e:
                log_msg(f"✗ Retry failed: {str(retry_e)}")
                return None
        else:
            log_msg(f"✗ ConnectionError: {error_detail}")
            if proxy_config:
                log_msg("Kiểm tra: Proxy có yêu cầu authentication không?")
        return None
    except requests.exceptions.RequestException as e:
        error_detail = f"RequestException: {str(e)}"
        log_msg(f"✗ {error_detail}")
        return None
    except Exception as e:
        error_detail = f"Unexpected error: {type(e).__name__}: {str(e)}"
        log_msg(f"✗ {error_detail}")
        if not getattr(sys, 'frozen', False):
            import traceback
            traceback.print_exc()
        return None


def get_update_link(proxy_config: Optional[Dict[str, str]] = None, log_callback=None) -> Optional[str]:
    """
    Get update link from server
    
    Args:
        proxy_config: Optional proxy configuration dictionary (may include username/password)
        log_callback: Optional callback function to log messages (for GUI logging)
        
    Returns:
        Optional[str]: Update link string, or None if error
    """
    def log_msg(msg: str):
        """Log message to both console and callback"""
        if not getattr(sys, 'frozen', False):
            print(f"[Update Check] {msg}")
        if log_callback:
            log_callback(f"[Update Check] {msg}")
    
    if not REQUESTS_AVAILABLE:
        log_msg("requests module not available")
        return None
    
    # Get proxy config if not provided
    if proxy_config is None:
        proxy_config = get_proxy_config()
    
    # Build proxy URLs with authentication
    proxies = None
    if proxy_config:
        proxies = build_proxy_url(proxy_config)
        safe_proxies = {}
        for k, v in proxies.items():
            if '@' in v:
                parts = v.split('@')
                if len(parts) == 2:
                    auth_part = parts[0]
                    if '://' in auth_part:
                        scheme = auth_part.split('://')[0]
                        auth_rest = auth_part.split('://')[1]
                        if ':' in auth_rest:
                            user_part = auth_rest.split(':')[0]
                            server_part = parts[1]
                            safe_proxies[k] = f"{scheme}://{user_part}:***@{server_part}"
                        else:
                            safe_proxies[k] = v
                    elif ':' in auth_part:
                        user_part = auth_part.split(':')[0]
                        safe_proxies[k] = f"{user_part}:***@{parts[1]}"
                    else:
                        safe_proxies[k] = v
                else:
                    safe_proxies[k] = v
            else:
                safe_proxies[k] = v
        log_msg(f"Using proxy URLs for update link: {safe_proxies}")
    
    try:
        log_msg(f"Fetching update link from: {UPDATE_LINK_URL}")
        # Disable SSL verification when using proxy (many corporate proxies use self-signed certs)
        # Always disable SSL verify when using proxy to avoid certificate issues
        verify_ssl = False if proxies else True
        
        if proxies:
            log_msg("SSL verification disabled (proxy may use self-signed certificate)")
        
        response = requests.get(
            UPDATE_LINK_URL, 
            timeout=UPDATE_CHECK_TIMEOUT,
            proxies=proxies,
            verify=verify_ssl
        )
        log_msg(f"Response status: {response.status_code}")
        response.raise_for_status()
        link = response.text.strip()
        log_msg(f"Fetched update link: {link}")
        return link if link else None
    except requests.exceptions.ConnectionError as e:
        error_detail = str(e)
        # Check if it's SSL certificate error
        if 'CERTIFICATE_VERIFY_FAILED' in error_detail or 'SSL' in error_detail:
            log_msg(f"✗ SSL Certificate Error: {error_detail}")
            log_msg("Đang thử lại với SSL verification disabled...")
            try:
                response = requests.get(
                    UPDATE_LINK_URL, 
                    timeout=UPDATE_CHECK_TIMEOUT,
                    proxies=proxies,
                    verify=False
                )
                log_msg(f"Response status (retry): {response.status_code}")
                response.raise_for_status()
                link = response.text.strip()
                log_msg(f"Fetched update link (retry): {link}")
                return link if link else None
            except Exception as retry_e:
                log_msg(f"✗ Retry failed: {str(retry_e)}")
                return None
        else:
            error_detail = f"Error fetching update link: {type(e).__name__}: {str(e)}"
            log_msg(f"✗ {error_detail}")
            return None
    except Exception as e:
        error_detail = f"Error fetching update link: {type(e).__name__}: {str(e)}"
        log_msg(f"✗ {error_detail}")
        return None


def check_for_update(proxy_config: Optional[Dict[str, str]] = None, log_callback=None) -> Optional[dict]:
    """
    Check if there's an update available
    
    Args:
        proxy_config: Optional proxy configuration dictionary
        log_callback: Optional callback function to log messages (for GUI logging)
        
    Returns:
        Optional[dict]: Dictionary with 'latest_version' and 'update_link' if update available,
                       None if no update or error
    """
    def log_msg(msg: str):
        """Log message to both console and callback"""
        if not getattr(sys, 'frozen', False):
            print(f"[Update Check] {msg}")
        if log_callback:
            log_callback(f"[Update Check] {msg}")
    
    try:
        log_msg(f"Current version: {CURRENT_VERSION}")
        
        # Get proxy config if not provided
        if proxy_config is None:
            proxy_config = get_proxy_config()
        
        # Log current version and proxy info
        if proxy_config:
            safe_config = {k: v for k, v in proxy_config.items() if k != 'password'}
            log_msg(f"Using proxy config: {safe_config}")
        else:
            log_msg("No proxy configured")
        
        latest_version = get_latest_version(proxy_config, log_callback)
        if not latest_version:
            log_msg("Could not get latest version from server")
            return None
        
        log_msg(f"Current: {CURRENT_VERSION}, Latest: {latest_version}")
        
        is_newer = compare_versions(CURRENT_VERSION, latest_version)
        
        log_msg(f"Compare result: {is_newer} (Latest > Current: {is_newer})")
        
        if is_newer:
            # Get update link
            log_msg(f"Fetching update link from: {UPDATE_LINK_URL}")
            
            update_link = get_update_link(proxy_config, log_callback)
            if not update_link:
                # Fallback to default network path
                update_link = r"\\172.25.191.52\ShareFile\Dp-it\05. Public Soft DP\22.OfficeTranslator\2. Publish"
                log_msg(f"Using fallback update link: {update_link}")
            
            log_msg(f"Update available! Latest: {latest_version}, Link: {update_link}")
            
            return {
                'latest_version': latest_version,
                'update_link': update_link
            }
        else:
            log_msg(f"No update available (current: {CURRENT_VERSION}, latest: {latest_version})")
            return None
    except Exception as e:
        error_detail = f"Error: {type(e).__name__}: {str(e)}"
        log_msg(f"✗ {error_detail}")
        if not getattr(sys, 'frozen', False):
            import traceback
            traceback.print_exc()
        return None


#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
PowerPoint File Processor
-------------------------
Handles translation of PowerPoint files (.pptx)
"""

import os
import sys
import re
import datetime
from typing import Optional, Callable, Any, List, Dict, Tuple

# Import helper functions from translator
from translator import (
    print_info, print_success, print_warning, print_error,
    clean_text, should_translate, translate_batch, IS_DEBUGGING
)

# Import pptx
try:
    from pptx import Presentation
    from pptx.enum.shapes import MSO_SHAPE_TYPE
    HAS_PPTX = True
except ImportError:
    HAS_PPTX = False
    print_warning("python-pptx not available. PowerPoint file processing will be disabled.")

# Import COM for advanced processing
try:
    import win32com.client
    import pythoncom
    HAS_COM = True
except ImportError:
    HAS_COM = False

def _update_pptx_paragraph_preserve_formatting(paragraph, new_text: str):
    """Update paragraph text while preserving formatting"""
    if not paragraph.runs:
        paragraph.text = new_text
        return
    
    # Save formatting from first run
    first_run = paragraph.runs[0]
    font_name = first_run.font.name
    font_size = first_run.font.size
    is_bold = first_run.font.bold
    is_italic = first_run.font.italic
    is_underline = first_run.font.underline
    
    # Get color
    try:
        if first_run.font.color and hasattr(first_run.font.color, 'rgb') and first_run.font.color.rgb:
            font_color = first_run.font.color.rgb
        elif hasattr(first_run.font.color, 'theme_color'):
            font_color = first_run.font.color.theme_color
        else:
            font_color = None
    except:
        font_color = None
    
    # Clear existing runs
    paragraph.clear()
    
    # Add new run with preserved formatting
    # Note: add_run() in python-pptx accepts text as keyword argument or no argument
    new_run = paragraph.add_run()
    new_run.text = new_text
    if font_name:
        new_run.font.name = font_name
    if font_size:
        new_run.font.size = font_size
    if is_bold is not None:
        new_run.font.bold = is_bold
    if is_italic is not None:
        new_run.font.italic = is_italic
    if is_underline is not None:
        new_run.font.underline = is_underline
    if font_color:
        try:
            from pptx.dml.color import RGBColor
            if isinstance(font_color, int):
                new_run.font.color.rgb = RGBColor(
                    (font_color >> 16) & 0xFF,
                    (font_color >> 8) & 0xFF,
                    font_color & 0xFF
                )
            else:
                new_run.font.color.rgb = font_color
        except:
            pass

def _update_pptx_cell_preserve_formatting(cell, new_text: str):
    """Update table cell text while preserving formatting"""
    if cell.text_frame.paragraphs:
        _update_pptx_paragraph_preserve_formatting(cell.text_frame.paragraphs[0], new_text)

class AdvancedPowerPointProcessor:
    """
    Advanced PowerPoint processor with multi-engine approach to handle complex elements
    like SmartArt, WordArt, OLE objects, and complex shapes.
    """
    
    def __init__(self):
        self.engines = {
            'hybrid': self._process_with_hybrid_approach,
            'python_pptx': self._process_with_python_pptx,
            'com_automation': self._process_with_com_automation,
            'xml_direct': self._process_with_xml_direct
        }
        self.extracted_elements = []
        
    def process_presentation(self, file_path: str, target_lang: str = "ja", api_client: Any = None, progress: Optional[Any] = None) -> Optional[str]:
        """Main processing method with multiple fallback engines"""
        
        filename = os.path.basename(file_path)
        print_info(f"Starting advanced PowerPoint processing for: {filename}")
        
        # Try engines in order of capability
        for engine_name, engine_func in self.engines.items():
            try:
                print_info(f"Attempting processing with {engine_name} engine...")
                result = engine_func(file_path, target_lang, api_client, progress, log_callback)
                if result:
                    print_success(f"Successfully processed with {engine_name} engine")
                    return result
            except Exception as e:
                print_warning(f"{engine_name} engine failed: {str(e)}")
                continue
                
        raise Exception("All processing engines failed")

    def _process_with_hybrid_approach(self, file_path: str, target_lang: str, api_client: Any, output_dir: Optional[str] = None, progress: Optional[Any] = None, log_callback: Optional[Callable[[str], None]] = None) -> Optional[str]:
        """Most comprehensive approach combining all methods"""
        
        filename = os.path.basename(file_path)
        print_info(f"Using hybrid approach for advanced PowerPoint processing")
        
        # Step 1: Extract with enhanced python-pptx (baseline)
        basic_elements = self._extract_with_enhanced_pptx(file_path, progress)
        
        # Step 2: Extract complex elements with COM automation (Windows only)
        if HAS_COM and os.name == 'nt':
            try:
                print_info("Attempting COM automation for advanced elements...")
                complex_elements = self._extract_with_com_automation_only(file_path)
                basic_elements.extend(complex_elements)
                print_info(f"COM automation found {len(complex_elements)} additional elements")
            except Exception as e:
                print_warning(f"COM automation not available: {e}")
                
        # Step 3: Extract missed elements with direct XML parsing
        if HAS_LXML:
            try:
                print_info("Attempting XML parsing for additional elements...")
                xml_elements = self._extract_with_xml_parsing(file_path)
                basic_elements.extend(xml_elements)
                print_info(f"XML parsing found {len(xml_elements)} additional elements")
            except Exception as e:
                print_warning(f"XML parsing failed: {e}")
                
        # Step 4: Process translations
        if basic_elements:
            print_info(f"Processing {len(basic_elements)} total extracted elements")
            translated_elements = self._translate_elements(basic_elements, target_lang, api_client, progress, log_callback)
            return self._apply_translations(file_path, translated_elements, progress, output_dir)
            
        print_warning("No elements extracted by any engine")
        return None

    def _extract_with_enhanced_pptx(self, file_path: str, progress: Optional[Any]) -> List[Dict]:
        """Enhanced python-pptx extraction with additional element types"""
        elements = []
        
        try:
            from pptx import Presentation
            prs = Presentation(file_path)
            
            slide_count = len(prs.slides)
            print_info(f"Extracting from {slide_count} slides using enhanced python-pptx")
            
            for slide_idx, slide in enumerate(prs.slides):
                if progress:
                    progress.update(progress.task_ids[0] if progress.task_ids else None, 
                                   description=f"[green]Enhanced scanning slide {slide_idx+1}/{slide_count}")
                
                # Standard shapes with enhanced detection
                for shape_idx, shape in enumerate(slide.shapes):
                    elements.extend(self._extract_from_shape_enhanced(shape, slide_idx, shape_idx))
                    
                # Layout and master slide elements
                try:
                    layout_elements = self._extract_from_layout(slide.slide_layout, slide_idx)
                    elements.extend(layout_elements)
                except Exception as e:
                    print_warning(f"Layout extraction failed: {e}")
                    
                # Notes with enhanced extraction
                try:
                    if hasattr(slide, "notes_slide") and slide.notes_slide:
                        notes_elements = self._extract_notes_enhanced(slide.notes_slide, slide_idx)
                        elements.extend(notes_elements)
                except Exception as e:
                    print_warning(f"Notes extraction failed: {e}")
                    
        except Exception as e:
            print_error(f"Enhanced python-pptx extraction failed: {e}")
            
        print_info(f"Enhanced python-pptx extracted {len(elements)} elements")
        return elements

    def _extract_from_shape_enhanced(self, shape, slide_idx: int, shape_idx: int) -> List[Dict]:
        """Enhanced shape text extraction with better element detection"""
        elements = []
        
        try:
            # Regular text frames with multiple paragraph support
            if hasattr(shape, "text_frame") and shape.text_frame:
                for para_idx, paragraph in enumerate(shape.text_frame.paragraphs):
                    if paragraph.text and paragraph.text.strip():
                        elements.append({
                            'type': 'text_frame_paragraph',
                            'location': (slide_idx, shape_idx, para_idx),
                            'text': paragraph.text.strip(),
                            'shape': shape,
                            'paragraph': paragraph
                        })
            
            # Enhanced table processing - handle paragraphs in cells (for bullet points)
            if hasattr(shape, "table"):
                for row_idx, row in enumerate(shape.table.rows):
                    for col_idx, cell in enumerate(row.cells):
                        # Check if cell has text_frame with paragraphs (for bullet points)
                        if hasattr(cell, "text_frame") and cell.text_frame and cell.text_frame.paragraphs:
                            # Extract each paragraph separately (each bullet point is a paragraph)
                            for para_idx, paragraph in enumerate(cell.text_frame.paragraphs):
                                if paragraph.text and paragraph.text.strip():
                                    elements.append({
                                        'type': 'table_cell_paragraph',
                                        'location': (slide_idx, shape_idx, row_idx, col_idx, para_idx),
                                        'text': paragraph.text.strip(),
                                        'cell': cell,
                                        'paragraph': paragraph
                                    })
                        # Fallback: if no paragraphs, use cell.text
                        elif cell.text and cell.text.strip():
                            elements.append({
                                'type': 'table_cell',
                                'location': (slide_idx, shape_idx, row_idx, col_idx),
                                'text': cell.text.strip(),
                                'cell': cell
                            })
            
            # Chart elements (enhanced)
            if hasattr(shape, "chart"):
                chart_elements = self._extract_from_chart_enhanced(shape.chart, slide_idx, shape_idx)
                elements.extend(chart_elements)
                
            # Group items with recursive processing
            if hasattr(shape, "shapes"):  # Group shape
                for group_idx, group_shape in enumerate(shape.shapes):
                    group_elements = self._extract_from_shape_enhanced(group_shape, slide_idx, f"{shape_idx}-{group_idx}")
                    elements.extend(group_elements)
                    
            # Placeholder detection (improved error handling)
            if hasattr(shape, "placeholder_format") and shape.placeholder_format:
                try:
                    # Safely check if it's a real placeholder with valid type
                    placeholder_type = getattr(shape.placeholder_format, 'type', None)
                    if placeholder_type is not None and hasattr(shape, 'text') and shape.text and shape.text.strip():
                        elements.append({
                            'type': 'placeholder',
                            'location': (slide_idx, shape_idx),
                            'text': shape.text.strip(),
                            'shape': shape,
                            'placeholder_type': placeholder_type
                        })
                except AttributeError as e:
                    # Shape has placeholder_format but accessing type failed
                    if "placeholder" in str(e).lower():
                        # Still try to extract text if available
                        if hasattr(shape, 'text') and shape.text and shape.text.strip():
                            elements.append({
                                'type': 'text_shape',
                                'location': (slide_idx, shape_idx),
                                'text': shape.text.strip(),
                                'shape': shape
                            })
                except Exception:
                    # Any other error, just skip this placeholder processing
                    pass
                    
        except Exception as e:
            print_warning(f"Error extracting from shape {shape_idx}: {e}")
            
        return elements

    def _extract_from_chart_enhanced(self, chart, slide_idx: int, shape_idx: int) -> List[Dict]:
        """Enhanced chart text extraction"""
        elements = []
        
        try:
            # Chart title
            if hasattr(chart, 'chart_title') and chart.chart_title and hasattr(chart.chart_title, 'text_frame'):
                title_text = chart.chart_title.text_frame.text
                if title_text and title_text.strip():
                    elements.append({
                        'type': 'chart_title',
                        'location': (slide_idx, shape_idx, 'title'),
                        'text': title_text.strip(),
                        'chart': chart
                    })
            
            # Axis titles
            try:
                if hasattr(chart, 'value_axis') and chart.value_axis.axis_title:
                    axis_text = chart.value_axis.axis_title.text_frame.text
                    if axis_text and axis_text.strip():
                        elements.append({
                            'type': 'chart_axis_title',
                            'location': (slide_idx, shape_idx, 'value_axis'),
                            'text': axis_text.strip(),
                            'chart': chart
                        })
            except:
                pass
                
            try:
                if hasattr(chart, 'category_axis') and chart.category_axis.axis_title:
                    axis_text = chart.category_axis.axis_title.text_frame.text
                    if axis_text and axis_text.strip():
                        elements.append({
                            'type': 'chart_axis_title',
                            'location': (slide_idx, shape_idx, 'category_axis'),
                            'text': axis_text.strip(),
                            'chart': chart
                        })
            except:
                pass
                
        except Exception as e:
            print_warning(f"Chart extraction failed: {e}")
            
        return elements

    def _extract_from_layout(self, layout, slide_idx: int) -> List[Dict]:
        """Extract text from slide layout and master slide"""
        elements = []
        
        try:
            # Layout placeholders
            for placeholder in layout.placeholders:
                if hasattr(placeholder, 'text_frame') and placeholder.text_frame.text:
                    text = placeholder.text_frame.text.strip()
                    if text and should_translate(text):
                        elements.append({
                            'type': 'layout_placeholder',
                            'location': (slide_idx, 'layout', placeholder.placeholder_format.idx),
                            'text': text,
                            'placeholder': placeholder
                        })
                        
        except Exception as e:
            print_warning(f"Layout extraction failed: {e}")
            
        return elements

    def _extract_notes_enhanced(self, notes_slide, slide_idx: int) -> List[Dict]:
        """Enhanced notes extraction"""
        elements = []
        
        try:
            if hasattr(notes_slide, "notes_text_frame") and notes_slide.notes_text_frame:
                # Extract paragraph by paragraph
                for para_idx, paragraph in enumerate(notes_slide.notes_text_frame.paragraphs):
                    if paragraph.text and paragraph.text.strip() and should_translate(paragraph.text):
                        elements.append({
                            'type': 'notes_paragraph',
                            'location': (slide_idx, 'notes', para_idx),
                            'text': paragraph.text.strip(),
                            'paragraph': paragraph
                        })
                        
        except Exception as e:
            print_warning(f"Notes extraction failed: {e}")
            
        return elements

    def _extract_with_com_automation_only(self, file_path: str) -> List[Dict]:
        """Windows COM automation for advanced elements only"""
        elements = []
        
        if not HAS_COM or os.name != 'nt':
            return elements
            
        try:
            print_info("Starting COM automation for advanced elements...")
            
            # Start PowerPoint application
            ppt_app = win32com.client.Dispatch("PowerPoint.Application")
            ppt_app.Visible = False
            
            # Open presentation
            presentation = ppt_app.Presentations.Open(os.path.abspath(file_path))
            
            for slide_idx in range(presentation.Slides.Count):
                slide = presentation.Slides[slide_idx + 1]  # COM is 1-indexed
                
                for shape_idx in range(slide.Shapes.Count):
                    shape = slide.Shapes[shape_idx + 1]  # COM is 1-indexed
                    
                    # SmartArt extraction
                    if shape.Type == 15:  # SmartArt
                        smartart_elements = self._extract_smartart_com(shape, slide_idx, shape_idx)
                        elements.extend(smartart_elements)
                    
                    # WordArt extraction
                    try:
                        if hasattr(shape, 'TextEffect') and shape.TextEffect.Text:
                            wordart_text = shape.TextEffect.Text.strip()
                            if wordart_text and should_translate(wordart_text):
                                elements.append({
                                    'type': 'wordart',
                                    'location': (slide_idx, shape_idx),
                                    'text': wordart_text,
                                    'com_shape': shape,
                                    'requires_com': True
                                })
                    except:
                        pass
                    
                    # OLE Objects
                    if shape.Type == 7:  # OLE Object
                        try:
                            ole_text = self._extract_ole_object_text(shape)
                            if ole_text and should_translate(ole_text):
                                elements.append({
                                    'type': 'ole_object',
                                    'location': (slide_idx, shape_idx),
                                    'text': ole_text,
                                    'com_shape': shape,
                                    'requires_com': True
                                })
                        except:
                            pass
            
            # Close presentation and application
            presentation.Close()
            ppt_app.Quit()
            
            print_info(f"COM automation extracted {len(elements)} advanced elements")
            
        except Exception as e:
            print_warning(f"COM automation failed: {e}")
            
        return elements

    def _extract_smartart_com(self, shape, slide_idx: int, shape_idx: int) -> List[Dict]:
        """Extract text from SmartArt using COM"""
        elements = []
        
        try:
            smartart = shape.SmartArt
            
            # Extract from all nodes
            for node_idx in range(smartart.AllNodes.Count):
                node = smartart.AllNodes[node_idx + 1]  # COM is 1-indexed
                
                if hasattr(node, 'TextFrame2') and node.TextFrame2.HasText:
                    node_text = node.TextFrame2.TextRange.Text.strip()
                    if node_text and should_translate(node_text):
                        elements.append({
                            'type': 'smartart_node',
                            'location': (slide_idx, shape_idx, node_idx),
                            'text': node_text,
                            'com_shape': shape,
                            'node_index': node_idx,
                            'requires_com': True
                        })
                        
        except Exception as e:
            print_warning(f"SmartArt extraction failed: {e}")
            
        return elements

    def _extract_ole_object_text(self, shape) -> Optional[str]:
        """Extract text from OLE objects"""
        try:
            # Try different methods to get OLE object text
            if hasattr(shape, 'OLEFormat') and shape.OLEFormat:
                ole_object = shape.OLEFormat.Object
                
                # For Excel objects
                if hasattr(ole_object, 'Cells'):
                    # This would require more complex Excel COM automation
                    return "Excel Object (requires manual translation)"
                    
                # For Word objects
                if hasattr(ole_object, 'Content'):
                    return ole_object.Content.Text
                    
                # Generic text extraction
                if hasattr(ole_object, 'Text'):
                    return ole_object.Text
                    
        except:
            pass
            
        return None

    def _extract_with_xml_parsing(self, file_path: str) -> List[Dict]:
        """Direct XML parsing for elements missed by other methods"""
        elements = []
        
        if not HAS_LXML:
            return elements
            
        try:
            print_info("Starting XML parsing for additional elements...")
            
            # PowerPoint files are ZIP archives
            with zipfile.ZipFile(file_path, 'r') as pptx_zip:
                # Parse slide XML files
                slide_files = [f for f in pptx_zip.namelist() if f.startswith('ppt/slides/slide') and f.endswith('.xml')]
                
                for slide_file in slide_files:
                    slide_idx = int(slide_file.split('slide')[1].split('.')[0]) - 1
                    
                    with pptx_zip.open(slide_file) as xml_file:
                        xml_content = xml_file.read()
                        xml_elements = self._parse_slide_xml(xml_content, slide_idx)
                        elements.extend(xml_elements)
                        
            print_info(f"XML parsing extracted {len(elements)} additional elements")
            
        except Exception as e:
            print_warning(f"XML parsing failed: {e}")
            
        return elements

    def _parse_slide_xml(self, xml_content: bytes, slide_idx: int) -> List[Dict]:
        """Parse slide XML for advanced elements"""
        elements = []
        
        try:
            root = etree.fromstring(xml_content)
            
            # Define namespaces
            namespaces = {
                'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
                'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
                'dgm': 'http://schemas.openxmlformats.org/drawingml/2006/diagram'
            }
            
            # Find all text elements not caught by python-pptx
            text_elements = root.xpath('.//a:t[not(ancestor::p:txBody)]', namespaces=namespaces)
            
            for idx, text_elem in enumerate(text_elements):
                if text_elem.text and text_elem.text.strip() and should_translate(text_elem.text):
                    elements.append({
                        'type': 'xml_text',
                        'location': (slide_idx, f'xml_{idx}'),
                        'text': text_elem.text.strip(),
                        'xml_element': text_elem,
                        'requires_xml': True
                    })
                    
        except Exception as e:
            print_warning(f"XML slide parsing failed: {e}")
            
        return elements

    def _process_with_python_pptx(self, file_path: str, target_lang: str, api_client: Any, progress: Optional[Any], log_callback: Optional[Callable[[str], None]] = None) -> Optional[str]:
        """Fallback to basic python-pptx processing"""
        print_info("Falling back to basic python-pptx processing")
        return process_powerpoint_file_basic(file_path, target_lang, api_client, progress, log_callback)

    def _process_with_com_automation(self, file_path: str, target_lang: str, api_client: Any, progress: Optional[Any], log_callback: Optional[Callable[[str], None]] = None) -> Optional[str]:
        """Pure COM automation approach (Windows only)"""
        if not HAS_COM or os.name != 'nt':
            raise Exception("COM automation not available on this platform")
            
        print_info("Using pure COM automation approach")
        # This would be a complete COM implementation - for now, fall back
        return self._process_with_hybrid_approach(file_path, target_lang, api_client, progress, log_callback)

    def _process_with_xml_direct(self, file_path: str, target_lang: str, api_client: Any, progress: Optional[Any], log_callback: Optional[Callable[[str], None]] = None) -> Optional[str]:
        """Direct XML manipulation approach"""
        if not HAS_LXML:
            raise Exception("LXML not available for XML processing")
            
        print_info("Using direct XML manipulation approach")
        # This would be a complete XML implementation - for now, fall back
        return self._process_with_hybrid_approach(file_path, target_lang, api_client, progress, log_callback)

    def _translate_elements(self, elements: List[Dict], target_lang: str, api_client: Any, progress: Optional[Any], log_callback: Optional[Callable[[str], None]] = None) -> List[Dict]:
        """Translate extracted elements using existing translation function"""
        if not elements:
            return []
            
        print_info(f"Translating {len(elements)} extracted elements")
        
        # Group texts for batch translation
        texts_to_translate = []
        element_map = {}
        
        for idx, element in enumerate(elements):
            if element['text'] and should_translate(element['text']):
                clean_text_value = clean_text(element['text'])
                texts_to_translate.append(clean_text_value)
                element_map[len(texts_to_translate) - 1] = idx
        
        if not texts_to_translate:
            return elements
            
        print_info(f"Processing {len(texts_to_translate)} texts for translation")
        
        # Use existing translation function
        translated_texts = translate_batch(texts_to_translate, target_lang, api_client, log_callback=log_callback)
        
        # Map translations back to elements
        for trans_idx, translated_text in enumerate(translated_texts):
            if trans_idx in element_map:
                original_idx = element_map[trans_idx]
                elements[original_idx]['translated_text'] = translated_text
                
        return elements

    def _apply_translations(self, file_path: str, translated_elements: List[Dict], progress: Optional[Any], output_dir: Optional[str] = None) -> Optional[str]:
        """Apply translations back to the presentation"""
        
        # Create output path with consistent naming format
        filename = os.path.basename(file_path)
        base_name, ext = os.path.splitext(filename)
        
        # Create timestamp for consistent naming
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Use provided output_dir or create default
        if output_dir is None:
            project_dir = os.path.dirname(os.path.abspath(__file__))
            output_dir = os.path.join(project_dir, "output")
        os.makedirs(output_dir, exist_ok=True)
        output_path = os.path.join(output_dir, f"{base_name}_TRANSLATED_{timestamp}{ext}")
        
        try:
            print_info(f"Applying translations to {len(translated_elements)} elements")
            
            # Load presentation
            from pptx import Presentation
            prs = Presentation(file_path)
            
            # Track updates
            updated_count = 0
            com_updates_needed = []
            
            # Apply translations
            for element in translated_elements:
                if 'translated_text' not in element:
                    continue
                    
                try:
                    element_type = element['type']
                    translated_text = element['translated_text']
                    original_text = element.get('text', '')[:30] + "..." if len(element.get('text', '')) > 30 else element.get('text', '')
                    
                    if element_type == 'text_frame_paragraph':
                        para = element['paragraph']
                        _update_pptx_paragraph_preserve_formatting(para, translated_text)
                        updated_count += 1
                        if IS_DEBUGGING:
                            print_info(f"Updated text_frame_paragraph: {len(original_text)} chars -> {len(translated_text)} chars")
                        
                    elif element_type == 'table_cell_paragraph':
                        # Table cell with specific paragraph (for bullet points)
                        para = element['paragraph']
                        _update_pptx_paragraph_preserve_formatting(para, translated_text)
                        updated_count += 1
                        print_info(f"Updated table_cell_paragraph: {len(original_text)} chars -> {len(translated_text)} chars")
                    elif element_type == 'table_cell':
                        # Table cell without paragraph index (fallback)
                        cell = element['cell']
                        _update_pptx_cell_preserve_formatting(cell, translated_text)
                        updated_count += 1
                        print_info(f"Updated table_cell: {len(original_text)} chars -> {len(translated_text)} chars")
                        
                    elif element_type in ['chart_title', 'chart_axis_title']:
                        if element_type == 'chart_title':
                            # Chart titles - try to preserve formatting
                            chart_title = element['chart'].chart_title
                            if hasattr(chart_title, 'text_frame') and chart_title.text_frame.paragraphs:
                                para = chart_title.text_frame.paragraphs[0]
                                _update_pptx_paragraph_preserve_formatting(para, translated_text)
                            else:
                                chart_title.text_frame.text = translated_text
                        updated_count += 1
                        print_info(f"Updated {element_type}: {len(original_text)} chars -> {len(translated_text)} chars")
                        
                    elif element_type == 'placeholder':
                        # For shapes, preserve formatting if possible
                        shape = element['shape']
                        if hasattr(shape, 'text_frame') and shape.text_frame.paragraphs:
                            para = shape.text_frame.paragraphs[0]
                            _update_pptx_paragraph_preserve_formatting(para, translated_text)
                        else:
                            shape.text = translated_text
                        updated_count += 1
                        print_info(f"Updated placeholder: {len(original_text)} chars -> {len(translated_text)} chars")
                        
                    elif element_type == 'text_shape':
                        # Handle text shapes that aren't placeholders
                        if 'shape' in element:
                            shape = element['shape']
                            if hasattr(shape, 'text_frame') and shape.text_frame.paragraphs:
                                para = shape.text_frame.paragraphs[0]
                                _update_pptx_paragraph_preserve_formatting(para, translated_text)
                            else:
                                shape.text = translated_text
                            updated_count += 1
                            if IS_DEBUGGING:
                                print_info(f"Updated text_shape: {len(original_text)} chars -> {len(translated_text)} chars")
                        
                    elif element_type == 'layout_placeholder':
                        # Handle layout placeholders - preserve formatting
                        if 'placeholder' in element:
                            placeholder = element['placeholder']
                            if hasattr(placeholder, 'text_frame') and placeholder.text_frame.paragraphs:
                                para = placeholder.text_frame.paragraphs[0]
                                _update_pptx_paragraph_preserve_formatting(para, translated_text)
                            else:
                                placeholder.text_frame.text = translated_text
                            updated_count += 1
                            print_info(f"Updated layout_placeholder: {len(original_text)} chars -> {len(translated_text)} chars")
                        
                    elif element_type == 'notes_paragraph':
                        # Preserve formatting for notes
                        para = element['paragraph']
                        _update_pptx_paragraph_preserve_formatting(para, translated_text)
                        updated_count += 1
                        print_info(f"Updated notes_paragraph: {len(original_text)} chars -> {len(translated_text)} chars")
                        
                    elif element.get('requires_com', False):
                        # Store COM updates for later processing
                        com_updates_needed.append(element)
                        
                    elif element.get('requires_xml', False):
                        # XML updates would require more complex handling
                        print_warning(f"XML element update not yet implemented: {element_type}")
                        
                    else:
                        print_warning(f"Unknown element type for translation application: {element_type}")
                        
                except Exception as e:
                    print_warning(f"Failed to apply translation to {element.get('type', 'unknown')}: {e}")
                    import traceback
                    print_warning(f"Error details: {traceback.format_exc()}")
            
            # Save presentation with basic updates
            prs.save(output_path)
            print_success(f"Applied {updated_count} translations using python-pptx")
            
            # Apply COM updates if needed and available
            if com_updates_needed and HAS_COM and os.name == 'nt':
                print_info(f"Applying {len(com_updates_needed)} COM-based translations")
                self._apply_com_updates(com_updates_needed, output_path)
            elif com_updates_needed:
                print_warning(f"Skipped {len(com_updates_needed)} advanced elements (COM not available)")
            
            print_success(f"Advanced translation completed: {output_path}")
            return output_path
            
        except Exception as e:
            print_error(f"Failed to apply translations: {e}")
            return None

    def _apply_com_updates(self, com_elements: List[Dict], file_path: str):
        """Apply COM-based updates to advanced elements"""
        try:
            import win32com.client
            
            ppt_app = win32com.client.Dispatch("PowerPoint.Application")
            ppt_app.Visible = False
            
            presentation = ppt_app.Presentations.Open(os.path.abspath(file_path))
            
            for element in com_elements:
                try:
                    slide_idx, shape_idx = element['location'][:2]
                    slide = presentation.Slides[slide_idx + 1]  # COM is 1-indexed
                    shape = slide.Shapes[shape_idx + 1]
                    
                    if element['type'] == 'smartart_node':
                        node_idx = element['node_index']
                        node = shape.SmartArt.AllNodes[node_idx + 1]
                        node.TextFrame2.TextRange.Text = element['translated_text']
                        
                    elif element['type'] == 'wordart':
                        shape.TextEffect.Text = element['translated_text']
                        
                    # OLE objects would need more specific handling per type
                        
                    print_success(f"Updated {element['type']} via COM")
                    
                except Exception as e:
                    print_warning(f"COM update failed for {element['type']}: {e}")
            
            presentation.Save()
            presentation.Close()
            ppt_app.Quit()
            
        except Exception as e:
            print_warning(f"COM updates failed: {e}")

# PDF processing removed to streamline the application


def process_powerpoint_file_basic(
    input_path: str, 
    target_lang: str = "ja", 
    api_client: Any = None,
    output_dir: Optional[str] = None,
    progress: Optional[Any] = None,
    log_callback: Optional[Callable[[str], None]] = None
) -> Optional[str]:
    """
    Process PowerPoint file using basic python-pptx approach: read, translate and save with original format.
    
    Args:
        input_path: Path to the PowerPoint file
        target_lang: Target language code
        api_client: OpenAI client instance
        progress: Optional rich progress instance
        
    Returns:
        Optional[str]: Path to the translated file, or None if processing failed
    """
    try:
        # Import python-pptx here to ensure it's loaded
        from pptx import Presentation
        
        # Create output file path with consistent naming format
        filename = os.path.basename(input_path)
        base_name, ext = os.path.splitext(filename)
        
        # Create timestamp for consistent naming
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

        # Use provided output_dir or create default
        if output_dir is None:
            project_dir = os.path.dirname(os.path.abspath(__file__))
            output_dir = os.path.join(project_dir, "output")
        os.makedirs(output_dir, exist_ok=True)
        output_path = os.path.join(output_dir, f"{base_name}_TRANSLATED_{timestamp}{ext}")

        print_info(f"Processing PowerPoint file: {filename}")

        # Task IDs for progress tracking
        scan_task = None
        file_task = None
        
        if progress:
            file_task = progress.add_task(f"[cyan]Processing {filename}", total=1.0)
            scan_task = progress.add_task("[green]Scanning slides", total=1.0)

        # Load the presentation
        prs = Presentation(input_path)
        
        if progress:
            # Update progress: file opened
            progress.update(file_task, completed=0.2, description=f"[cyan]Processing {filename} - File opened")
            # Update scanning task: starting scan
            progress.update(scan_task, completed=0.1, description="[green]Scanning slides")
        
        # Collect all text elements that need translation
        texts_to_translate = []
        text_references = []
        
        # Process each slide
        slide_count = len(prs.slides)
        
        for slide_idx, slide in enumerate(prs.slides):
            if progress:
                progress.update(scan_task, completed=0.1 + (0.8 * ((slide_idx + 1) / slide_count)), 
                               description=f"[green]Scanning slide {slide_idx+1}/{slide_count}")
            
            print_info(f"Scanning slide {slide_idx + 1}/{slide_count}")
            
            # Process shapes in the slide (text boxes, titles, etc.)
            for shape_idx, shape in enumerate(slide.shapes):
                # Process text frames - check both shape.text and text_frame.paragraphs
                # Some shapes have text in paragraphs that might not be in shape.text
                text_found = False
                
                # First, try to get text from text_frame paragraphs (more comprehensive)
                if hasattr(shape, "text_frame") and shape.text_frame:
                    for para_idx, paragraph in enumerate(shape.text_frame.paragraphs):
                        if paragraph.text and paragraph.text.strip():
                            text = paragraph.text.strip()
                            if should_translate(text):
                                clean_text_value = clean_text(text)
                                texts_to_translate.append(clean_text_value)
                                # Store reference as (slide index, shape index, para index)
                                text_references.append((slide_idx, shape_idx, para_idx))
                                if IS_DEBUGGING:
                                    print_info(f"Found text in slide {slide_idx + 1}, shape {shape_idx + 1}, paragraph {para_idx + 1} ({len(clean_text_value)} chars)")
                                text_found = True
                
                # Fallback: if no text_frame or no paragraphs found, check shape.text directly
                if not text_found and hasattr(shape, "text") and shape.text:
                    text = shape.text
                    if should_translate(text):
                        clean_text_value = clean_text(text)
                        texts_to_translate.append(clean_text_value)
                        # Store reference as (slide index, shape index)
                        text_references.append((slide_idx, shape_idx))
                        preview = clean_text_value[:30] + "..." if len(clean_text_value) > 30 else clean_text_value
                        if IS_DEBUGGING:
                            print_info(f"Found text in slide {slide_idx + 1}, shape {shape_idx + 1} ({len(shape.text)} chars)")
                
                # Process text in tables - handle paragraphs in cells (for bullet points)
                if hasattr(shape, "has_table") and shape.has_table:
                    table = shape.table
                    for row_idx, row in enumerate(table.rows):
                        for col_idx, cell in enumerate(row.cells):
                            # Check if cell has text_frame with paragraphs (for bullet points)
                            if hasattr(cell, "text_frame") and cell.text_frame and cell.text_frame.paragraphs:
                                # Extract each paragraph separately (each bullet point is a paragraph)
                                for para_idx, paragraph in enumerate(cell.text_frame.paragraphs):
                                    if paragraph.text and paragraph.text.strip() and should_translate(paragraph.text):
                                        clean_text_value = clean_text(paragraph.text)
                                        texts_to_translate.append(clean_text_value)
                                        # Store reference as (slide index, shape index, "table", row index, col index, para index)
                                        text_references.append((slide_idx, shape_idx, "table", row_idx, col_idx, para_idx))
                                        preview = clean_text_value[:30] + "..." if len(clean_text_value) > 30 else clean_text_value
                                        if IS_DEBUGGING:
                                            print_info(f"Found text in slide {slide_idx + 1}, table cell [{row_idx + 1}, {col_idx + 1}], paragraph {para_idx + 1} ({len(paragraph.text)} chars)")
                            # Fallback: if no paragraphs, use cell.text
                            elif cell.text and should_translate(cell.text):
                                clean_text_value = clean_text(cell.text)
                                texts_to_translate.append(clean_text_value)
                                # Store reference as (slide index, shape index, "table", row index, col index)
                                text_references.append((slide_idx, shape_idx, "table", row_idx, col_idx))
                                preview = clean_text_value[:30] + "..." if len(clean_text_value) > 30 else clean_text_value
                                if IS_DEBUGGING:
                                    print_info(f"Found text in slide {slide_idx + 1}, table cell [{row_idx + 1}, {col_idx + 1}] ({len(cell.text)} chars)")
                
                # Process text in groups (handle nested shapes)
                # Check if shape is a group by checking if it has 'shapes' attribute
                if hasattr(shape, "shapes") and shape.shapes:
                    for group_idx, group_shape in enumerate(shape.shapes):
                        text_found_in_group = False
                        
                        # Check text_frame paragraphs first
                        if hasattr(group_shape, "text_frame") and group_shape.text_frame:
                            for para_idx, paragraph in enumerate(group_shape.text_frame.paragraphs):
                                if paragraph.text and paragraph.text.strip():
                                    text = paragraph.text.strip()
                                    if should_translate(text):
                                        clean_text_value = clean_text(text)
                                        texts_to_translate.append(clean_text_value)
                                        # Store reference as (slide index, shape index, "group", group shape index, para index)
                                        text_references.append((slide_idx, shape_idx, "group", group_idx, para_idx))
                                        preview = clean_text_value[:30] + "..." if len(clean_text_value) > 30 else clean_text_value
                                        if IS_DEBUGGING:
                                            print_info(f"Found text in slide {slide_idx + 1}, grouped shape {group_idx + 1}, paragraph {para_idx + 1} ({len(paragraph.text)} chars)")
                                        text_found_in_group = True
                        
                        # Fallback to group_shape.text
                        if not text_found_in_group and hasattr(group_shape, "text") and group_shape.text and group_shape.text.strip():
                            text = group_shape.text.strip()
                            if should_translate(text):
                                clean_text_value = clean_text(text)
                                texts_to_translate.append(clean_text_value)
                                # Store reference as (slide index, shape index, "group", group shape index)
                                text_references.append((slide_idx, shape_idx, "group", group_idx))
                                preview = clean_text_value[:30] + "..." if len(clean_text_value) > 30 else clean_text_value
                                if IS_DEBUGGING:
                                    print_info(f"Found text in slide {slide_idx + 1}, grouped shape {group_idx + 1} ({len(text)} chars)")
                        
                        # Recursively process nested groups within group shapes
                        if hasattr(group_shape, "shapes") and group_shape.shapes:
                            for nested_idx, nested_shape in enumerate(group_shape.shapes):
                                if hasattr(nested_shape, "text_frame") and nested_shape.text_frame:
                                    for para_idx, paragraph in enumerate(nested_shape.text_frame.paragraphs):
                                        if paragraph.text and paragraph.text.strip():
                                            text = paragraph.text.strip()
                                            if should_translate(text):
                                                clean_text_value = clean_text(text)
                                                texts_to_translate.append(clean_text_value)
                                                # Store reference as (slide index, shape index, "group", group shape index, nested shape index, para index)
                                                text_references.append((slide_idx, shape_idx, "group", group_idx, nested_idx, para_idx))
                                                if IS_DEBUGGING:
                                                    print_info(f"Found text in slide {slide_idx + 1}, nested grouped shape {group_idx + 1}-{nested_idx + 1}, paragraph {para_idx + 1} ({len(paragraph.text)} chars)")
                                elif hasattr(nested_shape, "text") and nested_shape.text and nested_shape.text.strip():
                                    text = nested_shape.text.strip()
                                    if should_translate(text):
                                        clean_text_value = clean_text(text)
                                        texts_to_translate.append(clean_text_value)
                                        # Store reference as (slide index, shape index, "group", group shape index, nested shape index)
                                        text_references.append((slide_idx, shape_idx, "group", group_idx, nested_idx))
                                        if IS_DEBUGGING:
                                            print_info(f"Found text in slide {slide_idx + 1}, nested grouped shape {group_idx + 1}-{nested_idx + 1} ({len(text)} chars)")

        # Process notes - check paragraphs in notes_text_frame
        for slide_idx, slide in enumerate(prs.slides):
            if hasattr(slide, "notes_slide") and slide.notes_slide and hasattr(slide.notes_slide, "notes_text_frame"):
                notes_frame = slide.notes_slide.notes_text_frame
                notes_found = False
                
                # Check paragraphs in notes_text_frame
                if hasattr(notes_frame, "paragraphs"):
                    for para_idx, paragraph in enumerate(notes_frame.paragraphs):
                        if paragraph.text and paragraph.text.strip():
                            text = paragraph.text.strip()
                            if should_translate(text):
                                clean_text_value = clean_text(text)
                                texts_to_translate.append(clean_text_value)
                                # Store reference as (slide index, "notes", para index)
                                text_references.append((slide_idx, "notes", para_idx))
                                print_info(f"Found notes in slide {slide_idx + 1}, paragraph {para_idx + 1} ({len(clean_text_value)} chars)")
                                notes_found = True
                
                # Fallback to notes_text_frame.text
                if not notes_found and hasattr(notes_frame, "text") and notes_frame.text:
                    text = notes_frame.text
                    if should_translate(text):
                        clean_text_value = clean_text(text)
                        texts_to_translate.append(clean_text_value)
                        # Store reference as (slide index, "notes")
                        text_references.append((slide_idx, "notes"))
                        preview = clean_text_value[:30] + "..." if len(clean_text_value) > 30 else clean_text_value
                        print_info(f"Found notes in slide {slide_idx + 1} ({len(notes_text)} chars)")
        
        # Finish scanning phase
        if progress:
            progress.update(scan_task, completed=1.0, description="[green]Scanning complete")
        
        # Skip if no text to translate
        if not texts_to_translate:
            print_success(f"No text to translate in presentation '{filename}'.")
            if progress:
                progress.update(file_task, completed=1.0, description=f"[cyan]Processing {filename} - No translation needed")
            # Still save a copy in the output directory
            prs.save(output_path)
            print_success(f"File saved at: {output_path}")
            return output_path
        
        # Add translation task
        total_elements = len(texts_to_translate)
        if progress:
            trans_task = progress.add_task("[yellow]Translating content", total=total_elements)
            progress.update(file_task, completed=0.4, description=f"[cyan]Processing {filename} - Translation in progress")
            
        # Split into batches for processing
        batch_size = 50  # Smaller batch size for better progress tracking
        total_batches = (len(texts_to_translate) - 1) // batch_size + 1
        processed_count = 0
        
        print_info(f"Preparing to translate {len(texts_to_translate)} text segments in {total_batches} batches.")
        
        for i in range(0, len(texts_to_translate), batch_size):
            batch_texts = texts_to_translate[i:i+batch_size]
            batch_refs = text_references[i:i+batch_size]
            current_batch_num = i // batch_size + 1
            
            if IS_DEBUGGING:
                print_info(f"Translating batch {current_batch_num}/{total_batches} ({len(batch_texts)} texts)")
            
            # Define a progress callback for translation
            def update_translation_progress(current: int, total: int) -> None:
                if progress:
                    progress.update(trans_task, 
                                   description=f"[yellow]Translating batch {current_batch_num}/{total_batches} (Attempt {current+1}/{total+1})")
            
            # Translate batch
            translated_batch = translate_batch(
                batch_texts, 
                target_lang,
                api_client, 
                progress_callback=update_translation_progress,
                log_callback=log_callback
            )
            
            # Update translated content
            if IS_DEBUGGING:
                print_info(f"Updating content for batch {current_batch_num}...")
            
            for j, ref in enumerate(batch_refs):
                # Update progress
                if progress:
                    processed_count += 1
                    progress.update(trans_task, completed=processed_count)
                    
                if j < len(translated_batch) and translated_batch[j] and translated_batch[j].strip():
                    try:
                        # Regular shape - preserve formatting
                        # Check if reference includes paragraph index
                        if len(ref) == 3 and isinstance(ref[0], int) and isinstance(ref[1], int) and isinstance(ref[2], int):
                            # Reference with paragraph index: (slide_idx, shape_idx, para_idx)
                            slide_idx, shape_idx, para_idx = ref
                            shape = prs.slides[slide_idx].shapes[shape_idx]
                            if hasattr(shape, 'text_frame') and shape.text_frame.paragraphs and para_idx < len(shape.text_frame.paragraphs):
                                para = shape.text_frame.paragraphs[para_idx]
                                _update_pptx_paragraph_preserve_formatting(para, translated_batch[j])
                            else:
                                # Fallback to shape.text if paragraph not found
                                if hasattr(shape, 'text'):
                                    shape.text = translated_batch[j]
                            if IS_DEBUGGING:
                                print_success(f"Updated text in slide {slide_idx + 1}, shape {shape_idx + 1}, paragraph {para_idx + 1}")
                        elif len(ref) == 2 and isinstance(ref[0], int) and isinstance(ref[1], int):
                            # Reference without paragraph index: (slide_idx, shape_idx)
                            slide_idx, shape_idx = ref
                            shape = prs.slides[slide_idx].shapes[shape_idx]
                            if hasattr(shape, 'text_frame') and shape.text_frame.paragraphs:
                                # Update first paragraph if available
                                para = shape.text_frame.paragraphs[0]
                                _update_pptx_paragraph_preserve_formatting(para, translated_batch[j])
                            else:
                                # Fallback to shape.text
                                if hasattr(shape, 'text'):
                                    shape.text = translated_batch[j]
                            if IS_DEBUGGING:
                                print_success(f"Updated text in slide {slide_idx + 1}, shape {shape_idx + 1}")
                        
                        # Table cell - preserve formatting
                        elif len(ref) == 6 and ref[2] == "table":
                            # Reference with paragraph index: (slide_idx, shape_idx, "table", row_idx, col_idx, para_idx)
                            slide_idx, shape_idx, _, row_idx, col_idx, para_idx = ref
                            cell = prs.slides[slide_idx].shapes[shape_idx].table.rows[row_idx].cells[col_idx]
                            if hasattr(cell, "text_frame") and cell.text_frame.paragraphs and para_idx < len(cell.text_frame.paragraphs):
                                para = cell.text_frame.paragraphs[para_idx]
                                _update_pptx_paragraph_preserve_formatting(para, translated_batch[j])
                                if IS_DEBUGGING:
                                    print_success(f"Updated text in slide {slide_idx + 1}, table cell [{row_idx + 1}, {col_idx + 1}], paragraph {para_idx + 1}")
                            else:
                                # Fallback to cell text
                                _update_pptx_cell_preserve_formatting(cell, translated_batch[j])
                                if IS_DEBUGGING:
                                    print_success(f"Updated text in slide {slide_idx + 1}, table cell [{row_idx + 1}, {col_idx + 1}]")
                        elif len(ref) == 5 and ref[2] == "table":
                            # Reference without paragraph index: (slide_idx, shape_idx, "table", row_idx, col_idx)
                            slide_idx, shape_idx, _, row_idx, col_idx = ref
                            cell = prs.slides[slide_idx].shapes[shape_idx].table.rows[row_idx].cells[col_idx]
                            _update_pptx_cell_preserve_formatting(cell, translated_batch[j])
                            if IS_DEBUGGING:
                                print_success(f"Updated text in slide {slide_idx + 1}, table cell [{row_idx + 1}, {col_idx + 1}]")
                        
                        # Group shape - preserve formatting
                        elif len(ref) == 5 and ref[2] == "group" and isinstance(ref[4], int):
                            # Reference with paragraph index: (slide_idx, shape_idx, "group", group_idx, para_idx)
                            slide_idx, shape_idx, _, group_idx, para_idx = ref
                            group_shape = prs.slides[slide_idx].shapes[shape_idx]
                            if hasattr(group_shape, 'shapes') and group_idx < len(group_shape.shapes):
                                shape = group_shape.shapes[group_idx]
                                if hasattr(shape, 'text_frame') and shape.text_frame.paragraphs and para_idx < len(shape.text_frame.paragraphs):
                                    para = shape.text_frame.paragraphs[para_idx]
                                    _update_pptx_paragraph_preserve_formatting(para, translated_batch[j])
                                else:
                                    if hasattr(shape, 'text'):
                                        shape.text = translated_batch[j]
                                if IS_DEBUGGING:
                                    print_success(f"Updated text in slide {slide_idx + 1}, grouped shape {group_idx + 1}, paragraph {para_idx + 1}")
                        elif len(ref) == 4 and ref[2] == "group":
                            # Reference without paragraph index: (slide_idx, shape_idx, "group", group_idx)
                            slide_idx, shape_idx, _, group_idx = ref
                            group_shape = prs.slides[slide_idx].shapes[shape_idx]
                            if hasattr(group_shape, 'shapes') and group_idx < len(group_shape.shapes):
                                shape = group_shape.shapes[group_idx]
                                if hasattr(shape, 'text_frame') and shape.text_frame.paragraphs:
                                    para = shape.text_frame.paragraphs[0]
                                    _update_pptx_paragraph_preserve_formatting(para, translated_batch[j])
                                else:
                                    if hasattr(shape, 'text'):
                                        shape.text = translated_batch[j]
                                if IS_DEBUGGING:
                                    print_success(f"Updated text in slide {slide_idx + 1}, grouped shape {group_idx + 1}")
                        elif len(ref) == 6 and ref[2] == "group":
                            # Reference with nested group: (slide_idx, shape_idx, "group", group_idx, nested_idx, para_idx)
                            slide_idx, shape_idx, _, group_idx, nested_idx, para_idx = ref
                            group_shape = prs.slides[slide_idx].shapes[shape_idx]
                            if hasattr(group_shape, 'shapes') and group_idx < len(group_shape.shapes):
                                nested_group = group_shape.shapes[group_idx]
                                if hasattr(nested_group, 'shapes') and nested_idx < len(nested_group.shapes):
                                    shape = nested_group.shapes[nested_idx]
                                    if hasattr(shape, 'text_frame') and shape.text_frame.paragraphs and para_idx < len(shape.text_frame.paragraphs):
                                        para = shape.text_frame.paragraphs[para_idx]
                                        _update_pptx_paragraph_preserve_formatting(para, translated_batch[j])
                                    else:
                                        if hasattr(shape, 'text'):
                                            shape.text = translated_batch[j]
                                    if IS_DEBUGGING:
                                        print_success(f"Updated text in slide {slide_idx + 1}, nested grouped shape {group_idx + 1}-{nested_idx + 1}, paragraph {para_idx + 1}")
                        elif len(ref) == 5 and ref[2] == "group" and isinstance(ref[3], int) and isinstance(ref[4], int):
                            # Reference with nested group without para: (slide_idx, shape_idx, "group", group_idx, nested_idx)
                            slide_idx, shape_idx, _, group_idx, nested_idx = ref
                            group_shape = prs.slides[slide_idx].shapes[shape_idx]
                            if hasattr(group_shape, 'shapes') and group_idx < len(group_shape.shapes):
                                nested_group = group_shape.shapes[group_idx]
                                if hasattr(nested_group, 'shapes') and nested_idx < len(nested_group.shapes):
                                    shape = nested_group.shapes[nested_idx]
                                    if hasattr(shape, 'text_frame') and shape.text_frame.paragraphs:
                                        para = shape.text_frame.paragraphs[0]
                                        _update_pptx_paragraph_preserve_formatting(para, translated_batch[j])
                                    else:
                                        if hasattr(shape, 'text'):
                                            shape.text = translated_batch[j]
                                    if IS_DEBUGGING:
                                        print_success(f"Updated text in slide {slide_idx + 1}, nested grouped shape {group_idx + 1}-{nested_idx + 1}")
                        
                        # Notes - preserve formatting
                        elif len(ref) == 3 and ref[1] == "notes" and isinstance(ref[2], int):
                            # Reference with paragraph index: (slide_idx, "notes", para_idx)
                            slide_idx, _, para_idx = ref
                            if prs.slides[slide_idx].notes_slide and hasattr(prs.slides[slide_idx].notes_slide, "notes_text_frame"):
                                notes_frame = prs.slides[slide_idx].notes_slide.notes_text_frame
                                if hasattr(notes_frame, 'paragraphs') and notes_frame.paragraphs and para_idx < len(notes_frame.paragraphs):
                                    para = notes_frame.paragraphs[para_idx]
                                    _update_pptx_paragraph_preserve_formatting(para, translated_batch[j])
                                else:
                                    if hasattr(notes_frame, 'text'):
                                        notes_frame.text = translated_batch[j]
                                print_success(f"Updated notes in slide {slide_idx + 1}, paragraph {para_idx + 1}")
                        elif len(ref) == 2 and ref[1] == "notes":
                            # Reference without paragraph index: (slide_idx, "notes")
                            slide_idx = ref[0]
                            if prs.slides[slide_idx].notes_slide and hasattr(prs.slides[slide_idx].notes_slide, "notes_text_frame"):
                                notes_frame = prs.slides[slide_idx].notes_slide.notes_text_frame
                                if hasattr(notes_frame, 'paragraphs') and notes_frame.paragraphs:
                                    para = notes_frame.paragraphs[0]
                                    _update_pptx_paragraph_preserve_formatting(para, translated_batch[j])
                                else:
                                    if hasattr(notes_frame, 'text'):
                                        notes_frame.text = translated_batch[j]
                                print_success(f"Updated notes in slide {slide_idx + 1}")
                        
                        else:
                            print_warning(f"Unknown reference type: {ref}")
                            
                    except Exception as update_err:
                        print_warning(f"Error updating content: {str(update_err)}")
        
        # Update file task
        if progress:
            progress.update(file_task, completed=0.8, description=f"[cyan]Processing {filename} - Saving file")
            progress.update(trans_task, completed=total_elements, description="[yellow]Translation complete")
            
        # Save the translated presentation
        print_info(f"Saving translated PowerPoint to: {output_path}")
        prs.save(output_path)
        print_success(f"File saved successfully: {output_path}")
        
        if progress:
            progress.update(file_task, completed=1.0, description=f"[cyan]Processing {filename} - Complete")
            
        return output_path
        
    except Exception as e:
        print_error(f"Error processing PowerPoint file '{input_path}': {str(e)}")
        if progress and file_task:
            progress.update(file_task, completed=1.0, description=f"[red]Processing {filename} - Failed")
        return None



def process_powerpoint_file(
    input_path: str, 
    target_lang: str = "ja", 
    api_client: Any = None,
    output_dir: Optional[str] = None,
    progress: Optional[Any] = None,
    log_callback: Optional[Callable[[str], None]] = None
) -> Optional[str]:
    """
    PowerPoint file processor - using basic approach for reliability.
    
    The advanced processor with multi-engine approach has been temporarily disabled
    due to file corruption issues. Using the reliable basic processor instead.
    
    Args:
        input_path: Path to the PowerPoint file
        target_lang: Target language code
        api_client: OpenAI client instance
        progress: Optional rich progress instance
        
    Returns:
        Optional[str]: Path to the translated file, or None if processing failed
    """
    filename = os.path.basename(input_path)
    
    print_info(f"🚀 Processing PowerPoint file with basic processor: {filename}")
    
    try:
        # Use basic processor directly for reliability
        result = process_powerpoint_file_basic(input_path, target_lang, api_client, output_dir, progress, log_callback)
        
        if result:
            print_success(f"✅ PowerPoint processing completed successfully: {filename}")
            return result
        else:
            print_error(f"❌ PowerPoint processing failed for: {filename}")
            return None
            
    except Exception as e:
        print_error(f"❌ PowerPoint processing failed for {filename}: {str(e)}")
        return None

# PDF file processing removed to streamline the application


# Lịch Sử Phiên Bản

Các cập nhật và cải tiến quan trọng của ứng dụng.

---

## Phiên Bản 3.1 - 15/11/2025

### ✨ Tính Năng Mới
- **Chọn File Riêng Lẻ**: Thêm tùy chọn chọn file riêng lẻ thay vì chỉ chọn thư mục
  - Có thể chọn nhiều file cùng lúc để dịch
  - Hiển thị danh sách file đã chọn
  - Lưu danh sách file đã chọn để sử dụng lại
- **Xem Lịch Sử Phiên Bản**: Thêm nút "Phiên bản" để xem các cập nhật của ứng dụng
- **Tự Động Kiểm Tra Phiên Bản Mới**: Ứng dụng tự động kiểm tra phiên bản mới khi khởi động
  - Hiển thị thông báo nếu có phiên bản mới với link tải về
  - Kiểm tra ngầm trong background, không làm gián đoạn công việc
- **Hỗ Trợ Proxy với Xác Thực**: Tự động phát hiện và hỗ trợ proxy công ty
  - Tự động phát hiện proxy từ hệ thống Windows
  - Dialog nhập username/password proxy khi cần xác thực
  - Tự động xử lý SSL certificate cho proxy self-signed
  - Lưu thông tin proxy để sử dụng lại
- **Lưu Ý Về Hình Ảnh**: Thông báo rõ ràng về việc không hỗ trợ dịch văn bản trong hình ảnh

### 🔄 Thay Đổi
- **Dịch Lại File**: Giờ có thể dịch lại các file đã dịch trước đó (bỏ giới hạn bỏ qua file có "_TRANSLATED_")
- **Giao Diện**: Thêm radiobuttons để chuyển đổi giữa chế độ chọn thư mục và chọn file

---

## Phiên Bản 3.0 - 13/11/2025

### ✨ Tính Năng Mới
- **Lưu Cài Đặt Tự Động**: Ứng dụng tự động nhớ các cài đặt từ lần sử dụng trước (thư mục, ngôn ngữ dịch, ngôn ngữ giao diện)
- **Cảnh Báo Bảo Mật**: Thêm thông báo rõ ràng về bảo mật dữ liệu khi dịch

### 🔄 Thay Đổi
- **Giao Diện**: Tối ưu giao diện để hiển thị nhiều thông tin hơn

### ❌ Loại Bỏ
- **Liên Kết API Key**: Ẩn các liên kết không cần thiết khi chạy file thực thi

---

## Phiên Bản 2.0 - 05/2024

### ✨ Tính Năng Mới
- **Giao Diện Đồ Họa**: Thêm giao diện dễ sử dụng thay cho dòng lệnh
- **Hỗ Trợ Đa Định Dạng**: Thêm hỗ trợ Word và PowerPoint (trước đây chỉ có Excel)
- **Dịch Hàng Loạt**: Có thể dịch nhiều file cùng lúc
- **Theo Dõi Tiến Trình**: Hiển thị tiến trình dịch real-time

### 🔄 Cải Tiến
- Giữ nguyên định dạng file sau khi dịch
- Xử lý lỗi tốt hơn
- Trải nghiệm người dùng được cải thiện

---

## Phiên Bản 1.0 - 04/2024

### ✨ Phát Hành Đầu Tiên
- Hỗ trợ dịch file Excel
- Sử dụng Google Gemini API để dịch
- Giao diện dòng lệnh

---

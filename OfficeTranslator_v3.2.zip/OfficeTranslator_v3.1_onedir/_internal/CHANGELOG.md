# Changelog

Tất cả các thay đổi đáng chú ý trong dự án này sẽ được ghi lại trong file này.

## [3.1] - 2025-11-15

### Added
- **File Selection Mode**: Thêm chức năng chọn file riêng lẻ thay vì chỉ chọn thư mục
  - Thêm 2 radiobuttons để chọn giữa "Folder" và "File"
  - Hỗ trợ chọn nhiều file cùng lúc (multiple file selection)
  - Hiển thị danh sách file đã chọn với tên file (tối đa 3 file, sau đó hiển thị "... (+N more)")
  - Lưu danh sách file đã chọn vào settings để khôi phục khi mở lại ứng dụng
  - Validation: Kiểm tra file còn tồn tại trước khi dịch
- **Version History Dialog**: Thêm button "Phiên bản" để xem lịch sử cập nhật phiên bản
- **Auto Update Checker**: Thêm tính năng tự động kiểm tra phiên bản mới khi khởi động ứng dụng
  - Tự động kiểm tra từ GitHub repository khi ứng dụng khởi động
  - Hiển thị dialog thông báo nếu có phiên bản mới với link tải về
  - Kiểm tra ngầm trong background thread, không block UI
  - Đọc phiên bản hiện tại từ file `version.txt` (embedded trong build)
  - So sánh semantic version để xác định phiên bản mới
- **Proxy Support with Authentication**: Thêm hỗ trợ proxy với xác thực cho mạng công ty
  - Tự động phát hiện proxy từ Windows environment variables và registry
  - Dialog nhập username/password proxy khi cần xác thực (407 Proxy Authentication Required)
  - Tự động xử lý SSL certificate verification cho proxy self-signed
  - Lưu proxy credentials vào `.proxy_settings.json` để sử dụng lại
  - Hỗ trợ URL encoding cho username/password có ký tự đặc biệt
  - Normalize proxy URL để tránh duplicate `http://` prefix
- **Image Translation Note**: Thêm lưu ý về việc không hỗ trợ dịch hình ảnh trong dialog Notes

### Changed
- **Version Update**: Cập nhật phiên bản từ v3.0 lên v3.1
- **File Filtering**: Bỏ logic bỏ qua file có suffix "_TRANSLATED_" - giờ có thể dịch lại file đã dịch
- **Translation Logic**: Cập nhật `run_translation()` để xử lý cả hai chế độ:
  - Folder mode: Xử lý tất cả file trong thư mục (như cũ)
  - File mode: Xử lý từng file đã chọn riêng lẻ
- **UI Layout**: Thêm file selection frame với label và button riêng, hiển thị/ẩn dựa trên mode đã chọn
- **Settings Storage**: Thêm `input_mode` và `selected_files` vào settings để lưu trữ

### Removed
- **PDF Translation Support**: Bỏ chức năng dịch file PDF do hạn chế về chỉnh sửa format sau khi dịch

### Technical Details
- **File Selection**: Sử dụng `filedialog.askopenfilenames()` để chọn nhiều file
- **File Validation**: Tự động lọc các file không được hỗ trợ và kiểm tra file còn tồn tại
- **UI State Management**: Sử dụng `grid()` và `grid_remove()` để hiển thị/ẩn các frame tương ứng với mode
- **Update Checker Module**: Tách logic kiểm tra phiên bản ra file `src/update_checker.py` riêng
  - `get_current_version()`: Đọc version từ `version.txt` (tìm trong exe_dir, _internal, src/, parent_dir)
  - `get_latest_version()`: Fetch version từ GitHub raw URL với timeout 5s
  - `compare_versions()`: So sánh semantic version (major.minor.patch)
  - `check_for_update()`: Orchestrate update check process
- **Proxy Handling**:
  - `detect_system_proxy()`: Phát hiện proxy từ `HTTP_PROXY`, `HTTPS_PROXY`, Windows registry
  - `build_proxy_url()`: Xây dựng proxy URL với authentication (URL-encoded username:password)
  - `normalize_proxy_url()`: Chuẩn hóa proxy URL, loại bỏ duplicate `http://` prefix
  - `get_proxy_config()`: Ưu tiên saved settings, fallback về system proxy
  - SSL verification tự động disabled khi dùng proxy (corporate proxy thường dùng self-signed cert)
  - Retry logic với `verify=False` khi gặp SSL certificate error
- **Version File**: File `version.txt` được embed vào build trong `_internal` directory

## [3.0] - 2025-11-13

### Added
- **Security Warning Disclaimer**: Thêm disclaimer vào security warning dialog thông báo DP-IT Team không chịu trách nhiệm về vấn đề bảo mật hoặc rò rỉ dữ liệu
- **Settings Persistence**: Thêm chức năng lưu và tự động load settings từ lần chạy trước (input folder, output folder, target language, UI language)
- **Debug Configuration**: Thêm config `SAVE_SECURITY_PREFERENCE` ở đầu file để điều khiển việc lưu security warning preference (dùng cho debug)
- **OneDir Build Mode**: Tạo file `build_exe_onedir.py` để build với PyInstaller --onedir mode, tối ưu dung lượng file và tốc độ khởi động

### Changed
- **UI Padding**: Giảm padding top và bottom của các elements để tăng không gian hiển thị cho activity log
  - Main frame padding: 20 → 10
  - LabelFrame padding: 8 → 5
  - Giảm pady spacing giữa các elements
- **Security Warning**: Cập nhật message để bao gồm disclaimer về trách nhiệm của DP-IT Team (có trong cả 3 ngôn ngữ: en, vi, ja)

### Removed
- **API Key Link in EXE**: Ẩn link "Get FREE Gemini API Key" khi chạy ở chế độ executable (chỉ hiển thị khi chạy script)
- **Reset Security Warning Button**: Bỏ nút reset security warning (thay bằng config `SAVE_SECURITY_PREFERENCE`)
- **API Key Free Text**: Bỏ tất cả text "lấy API miễn phí" trong GUI
- **Setup Folder**: Bỏ tạo thư mục `setup` và các file hướng dẫn khi build onedir
- **README.txt**: Bỏ tạo file README.txt khi build onedir

### Fixed
- **OneDir Build Error**: Sửa lỗi build onedir - bỏ flag `--onedir` khi sử dụng file `.spec` (mode đã được định nghĩa trong spec file)

### Improved
- **OneDir Build**: 
  - Tự động ẩn thư mục `_internal` sau khi build (dùng `attrib +H` trên Windows)
  - Tối ưu cấu trúc package, chỉ giữ lại các file cần thiết
- **Settings Management**: 
  - Tự động lưu settings khi user thay đổi input/output folder, target language, hoặc UI language
  - Hiển thị thông báo "Loaded settings from last session" khi có settings đã lưu
- **Code Organization**: 
  - Tách localization strings ra file `localization.py` riêng
  - Cải thiện cấu trúc code để dễ bảo trì

### Technical Details
- **Settings Storage**: Settings được lưu trong file `.app_settings.json` (JSON format)
- **OneDir vs OneFile**: 
  - OneDir: File exe nhỏ hơn, khởi động nhanh hơn, dễ debug
  - OneFile: Một file duy nhất nhưng lớn hơn và chậm hơn
- **Hidden Files**: 
  - `.env` file được set hidden sau khi tạo
  - `_internal` folder được set hidden sau khi build onedir

## [2.0.0] - 2024-05

### Added
- **GUI Interface**: Thêm giao diện đồ họa user-friendly (`gui_translator.py`)
- **Multi-format Support**: Hỗ trợ thêm Word (.docx, .doc) và PowerPoint (.pptx, .ppt)
- **Build Tools**: Thêm script `build_exe.py` để tạo standalone executable
- **Real-time Progress**: Theo dõi tiến trình dịch real-time
- **Batch Processing**: Xử lý nhiều file cùng lúc

### Improved
- Format preservation cho tất cả các loại file
- Error handling và retry mechanism
- User experience với GUI

## [1.0.0] - 2024-04

### Added
- Initial release với hỗ trợ Excel translation
- Core translation engine với Google Gemini API
- Command line interface

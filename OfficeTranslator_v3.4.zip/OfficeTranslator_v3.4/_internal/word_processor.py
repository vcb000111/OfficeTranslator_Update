#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Word File Processor
-------------------
Handles translation of Word files (.docx, .doc)
"""

import os
import sys
import re
import datetime
import tempfile
from typing import Optional, Callable, Any

# Import helper functions from translator
from translator import (
    print_info, print_success, print_warning, print_error,
    clean_text, should_translate, translate_batch, IS_DEBUGGING
)

# Import context holder for specialized translation
try:
    from context_holder import get_translation_context
except ImportError:
    def get_translation_context():
        return "general"

# Import docx
try:
    from docx import Document
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False
    print_warning("python-docx not available. Word file processing will be disabled.")

# Import COM for .doc conversion
try:
    import win32com.client
    import pythoncom
    HAS_COM = True
except ImportError:
    HAS_COM = False

def _update_paragraph_text_preserve_formatting(paragraph, new_text: str):
    """Update paragraph text while preserving formatting"""
    if not paragraph.runs:
        paragraph.text = new_text
        return
    
    # Save formatting from first run
    first_run = paragraph.runs[0]
    font_name = first_run.font.name
    font_size = first_run.font.size
    is_bold = first_run.font.bold
    is_italic = first_run.font.italic
    is_underline = first_run.font.underline
    
    # Get color
    try:
        if first_run.font.color and first_run.font.color.rgb:
            font_color = first_run.font.color.rgb
        else:
            font_color = None
    except:
        font_color = None
    
    # Clear existing runs
    paragraph.clear()
    
    # Add new run with preserved formatting
    # Note: add_run() in python-docx accepts text as keyword argument or no argument
    new_run = paragraph.add_run()
    new_run.text = new_text
    if font_name:
        new_run.font.name = font_name
    if font_size:
        new_run.font.size = font_size
    if is_bold is not None:
        new_run.font.bold = is_bold
    if is_italic is not None:
        new_run.font.italic = is_italic
    if is_underline is not None:
        new_run.font.underline = is_underline
    if font_color:
        from docx.shared import RGBColor
        try:
            new_run.font.color.rgb = RGBColor(
                (font_color >> 16) & 0xFF,
                (font_color >> 8) & 0xFF,
                font_color & 0xFF
            )
        except:
            pass

def process_word_file(
    input_path: str, 
    target_lang: str = "ja", 
    api_client: Any = None,
    output_dir: Optional[str] = None,
    progress: Optional[Any] = None,
    log_callback: Optional[Callable[[str], None]] = None,
    skip_languages: Optional[list] = None,
    cancel_event: Optional[Any] = None
) -> Optional[str]:
    """
    Process Word file: read, translate and save with original format.
    
    Args:
        input_path: Path to the Word file
        target_lang: Target language code
        api_client: OpenAI client instance
        progress: Optional rich progress instance
        
    Returns:
        Optional[str]: Path to the translated file, or None if processing failed
    """
    try:
        # Import python-docx here to ensure it's loaded
        from docx import Document
        
        # Create output file path
        filename = os.path.basename(input_path)
        base_name, ext = os.path.splitext(filename)
        
        # Create timestamp for consistent naming
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Check if file is .doc (old format) - python-docx only supports .docx
        temp_docx_path = None
        actual_input_path = input_path
        
        if ext.lower() == '.doc':
            # .doc files need to be converted to .docx first
            if HAS_COM and os.name == 'nt':
                print_info(f"Converting .doc file to .docx format (python-docx requires .docx)...")
                if log_callback:
                    log_callback(f"🔄 Converting .doc to .docx format...")
                
                try:
                    # Create temporary .docx file
                    import tempfile
                    import pythoncom
                    temp_dir = tempfile.gettempdir()
                    temp_docx_path = os.path.join(temp_dir, f"{base_name}_temp_{timestamp}.docx")
                    
                    # Initialize COM for this thread
                    pythoncom.CoInitialize()
                    
                    try:
                        # Use Word COM to convert .doc to .docx
                        word_app = win32com.client.Dispatch("Word.Application")
                        word_app.Visible = False
                        
                        try:
                            # Open .doc file
                            doc_com = word_app.Documents.Open(os.path.abspath(input_path))
                            
                            # Save as .docx
                            doc_com.SaveAs2(
                                FileName=os.path.abspath(temp_docx_path),
                                FileFormat=16  # wdFormatXMLDocument (.docx)
                            )
                            doc_com.Close()
                            
                            actual_input_path = temp_docx_path
                            print_success(f"Successfully converted .doc to .docx")
                            if log_callback:
                                log_callback(f"✅ File converted successfully")
                        finally:
                            word_app.Quit()
                    finally:
                        # Uninitialize COM
                        pythoncom.CoUninitialize()
                except Exception as convert_err:
                    print_error(f"Failed to convert .doc file to .docx: {str(convert_err)}")
                    if log_callback:
                        log_callback(f"❌ Conversion failed: {str(convert_err)}")
                    print_info("Note: python-docx only supports .docx format. Please convert .doc to .docx manually using Microsoft Word.")
                    return None
            else:
                print_error(f"File '{filename}' is in .doc format (old binary format).")
                print_info("python-docx only supports .docx format. Please convert the file to .docx using Microsoft Word.")
                print_info("Alternatively, install pywin32 on Windows to enable automatic conversion.")
                if log_callback:
                    log_callback(f"❌ .doc format not supported. Please convert to .docx first.")
                return None

        # Use provided output_dir or create default
        if output_dir is None:
            # Create output directory at the same level as the script
            project_dir = os.path.dirname(os.path.abspath(__file__))
            output_dir = os.path.join(project_dir, "output")
        os.makedirs(output_dir, exist_ok=True)
        
        # If file was converted from .doc to .docx, save output as .docx first
        output_ext = '.docx' if temp_docx_path else ext
        output_path = os.path.join(output_dir, f"{base_name}_TRANSLATED_{target_lang.upper()}_{timestamp}{output_ext}")

        print_info(f"Processing Word file: {filename}")

        # Task IDs for progress tracking
        scan_task = None
        file_task = None
        
        if progress:
            file_task = progress.add_task(f"[cyan]Processing {filename}", total=1.0)
            scan_task = progress.add_task("[green]Scanning document", total=1.0)

        # Load the document
        try:
            doc = Document(actual_input_path)
        except Exception as docx_err:
            error_msg = str(docx_err)
            if "is not a Word file" in error_msg or "not a zip file" in error_msg.lower():
                print_error(f"File '{filename}' is not a valid Word file (.docx format required).")
                print_info(f"Error details: {error_msg}")
                if log_callback:
                    log_callback(f"❌ Invalid Word file format. Please ensure the file is a valid .docx file.")
                # Clean up temp file if exists
                if temp_docx_path and os.path.exists(temp_docx_path):
                    try:
                        os.remove(temp_docx_path)
                    except:
                        pass
                return None
            else:
                raise  # Re-raise if it's a different error
        
        if progress:
            # Update progress: file opened
            progress.update(file_task, completed=0.2, description=f"[cyan]Processing {filename} - File opened")
            # Update scanning task: starting scan
            progress.update(scan_task, completed=0.1, description="[green]Scanning document content")
        
        # Collect all text elements that need translation
        texts_to_translate = []
        text_references = []
        
        # Initialize dictionaries for storing shape and inline shape translations
        # These will be updated via COM after the document is saved
        shape_updates = {}
        inline_shape_updates = {}
        
        # Process paragraphs (including bullet points and TOC)
        para_count = len(doc.paragraphs)
        for para_idx, para in enumerate(doc.paragraphs):
            # Check for cancellation
            if cancel_event and cancel_event.is_set():
                print_info("Translation cancelled - closing document")
                try:
                    doc.save(output_path)  # Save partial progress if needed
                except:
                    pass
                return None
            if progress:
                scan_progress = 0.1 + (0.3 * ((para_idx + 1) / para_count))
                progress.update(scan_task, completed=scan_progress, 
                               description=f"[green]Scanning paragraphs {para_idx+1}/{para_count}")
            
            # Extract text from paragraph - handle hyperlinks (for TOC) and runs
            para_text = None
            
            # Method 1: Try to get text from runs (better for hyperlinks/TOC)
            if para.runs:
                # Collect text from all runs (including hyperlinks)
                run_texts = []
                for run in para.runs:
                    if run.text and run.text.strip():
                        run_texts.append(run.text.strip())
                if run_texts:
                    para_text = ' '.join(run_texts)
            
            # Method 2: Fallback to para.text if no runs or runs empty
            if not para_text or not para_text.strip():
                para_text = para.text
            
            # Process the text if it exists and should be translated
            if para_text and para_text.strip() and should_translate(para_text, skip_languages):
                clean_text_value = clean_text(para_text)
                texts_to_translate.append(clean_text_value)
                # Store reference as ("paragraph", paragraph index)
                text_references.append(("paragraph", para_idx))
                if IS_DEBUGGING:
                    print_info(f"Found text in paragraph {para_idx + 1} ({len(clean_text_value)} chars)")
        
        # Process tables
        table_count = len(doc.tables)
        for table_idx, table in enumerate(doc.tables):
            if progress:
                scan_progress = 0.4 + (0.3 * ((table_idx + 1) / (table_count or 1)))
                progress.update(scan_task, completed=scan_progress, 
                               description=f"[green]Scanning tables {table_idx+1}/{table_count}")
                
            for row_idx, row in enumerate(table.rows):
                for cell_idx, cell in enumerate(row.cells):
                    # Check cell paragraphs (each paragraph can be a bullet point)
                    for para_idx, para in enumerate(cell.paragraphs):
                        # Extract text from runs (for hyperlinks) or para.text
                        cell_para_text = None
                        if para.runs:
                            run_texts = []
                            for run in para.runs:
                                if run.text and run.text.strip():
                                    run_texts.append(run.text.strip())
                            if run_texts:
                                cell_para_text = ' '.join(run_texts)
                        if not cell_para_text or not cell_para_text.strip():
                            cell_para_text = para.text
                        
                        if cell_para_text and cell_para_text.strip() and should_translate(cell_para_text, skip_languages):
                            clean_text_value = clean_text(cell_para_text)
                            texts_to_translate.append(clean_text_value)
                            # Store reference as ("table", table index, row index, cell index, paragraph index)
                            text_references.append(("table", table_idx, row_idx, cell_idx, para_idx))
                            if IS_DEBUGGING:
                                preview = clean_text_value[:30] + "..." if len(clean_text_value) > 30 else clean_text_value
                                print_info(f"Found text in table {table_idx + 1}, cell [{row_idx + 1}, {cell_idx + 1}], paragraph {para_idx + 1} ({len(clean_text_value)} chars)")
        
        # Process headers and footers
        section_count = len(doc.sections)
        for section_idx, section in enumerate(doc.sections):
            if progress:
                scan_progress = 0.7 + (0.25 * ((section_idx + 1) / (section_count or 1)))
                progress.update(scan_task, completed=scan_progress, 
                               description=f"[green]Scanning sections {section_idx+1}/{section_count}")
                
            # Process headers
            for header_type in ['header', 'first_page_header', 'even_page_header']:
                header = getattr(section, header_type)
                if header:
                    for para_idx, para in enumerate(header.paragraphs):
                        # Extract text from runs (for hyperlinks) or para.text
                        header_text = None
                        if para.runs:
                            run_texts = []
                            for run in para.runs:
                                if run.text and run.text.strip():
                                    run_texts.append(run.text.strip())
                            if run_texts:
                                header_text = ' '.join(run_texts)
                        if not header_text or not header_text.strip():
                            header_text = para.text
                        
                        if header_text and header_text.strip() and should_translate(header_text, skip_languages):
                            clean_text_value = clean_text(header_text)
                            texts_to_translate.append(clean_text_value)
                            # Store reference as ("header", section index, header type, paragraph index)
                            text_references.append(("header", section_idx, header_type, para_idx))
                            if IS_DEBUGGING:
                                preview = clean_text_value[:30] + "..." if len(clean_text_value) > 30 else clean_text_value
                                print_info(f"Found text in section {section_idx + 1}, {header_type}, paragraph {para_idx + 1} ({len(clean_text_value)} chars)")
            
            # Process footers
            for footer_type in ['footer', 'first_page_footer', 'even_page_footer']:
                footer = getattr(section, footer_type)
                if footer:
                    for para_idx, para in enumerate(footer.paragraphs):
                        # Extract text from runs (for hyperlinks) or para.text
                        footer_text = None
                        if para.runs:
                            run_texts = []
                            for run in para.runs:
                                if run.text and run.text.strip():
                                    run_texts.append(run.text.strip())
                            if run_texts:
                                footer_text = ' '.join(run_texts)
                        if not footer_text or not footer_text.strip():
                            footer_text = para.text
                        
                        if footer_text and footer_text.strip() and should_translate(footer_text, skip_languages):
                            clean_text_value = clean_text(footer_text)
                            texts_to_translate.append(clean_text_value)
                            # Store reference as ("footer", section index, footer type, paragraph index)
                            text_references.append(("footer", section_idx, footer_type, para_idx))
                            if IS_DEBUGGING:
                                preview = clean_text_value[:30] + "..." if len(clean_text_value) > 30 else clean_text_value
                                print_info(f"Found text in section {section_idx + 1}, {footer_type}, paragraph {para_idx + 1} ({len(clean_text_value)} chars)")
        
        # Process inline shapes (text boxes, shapes with text)
        if log_callback:
            log_callback(f"🔍 Checking inline shapes (text boxes)...")
        try:
            # Process inline shapes in document body
            for para_idx, para in enumerate(doc.paragraphs):
                if hasattr(para, '_element') and para._element:
                    # Check for inline shapes in paragraph
                    try:
                        # Access inline shapes through XML
                        inline_shapes = para._element.xpath('.//w:drawing | .//w:pict | .//w:object', 
                                                           namespaces={'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
                                                                      'v': 'urn:schemas-microsoft-com:vml'})
                        if inline_shapes:
                            if IS_DEBUGGING:
                                print_info(f"Found {len(inline_shapes)} inline shape(s) in paragraph {para_idx + 1}")
                    except:
                        pass
        except Exception as shape_err:
            if IS_DEBUGGING:
                print_warning(f"Error processing inline shapes: {str(shape_err)}")
        
        # Process inline shapes using python-docx API (if available)
        try:
            shape_count = 0
            for para_idx, para in enumerate(doc.paragraphs):
                # Check for inline shapes in paragraph
                if hasattr(para, 'runs'):
                    for run_idx, run in enumerate(para.runs):
                        # Check if run has inline shapes
                        if hasattr(run, '_element'):
                            try:
                                # Look for drawing elements (text boxes, shapes)
                                drawings = run._element.xpath('.//w:drawing', 
                                                              namespaces={'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'})
                                if drawings:
                                    shape_count += len(drawings)
                                    if IS_DEBUGGING:
                                        print_info(f"Found drawing in paragraph {para_idx + 1}, run {run_idx + 1}")
                            except:
                                pass
        except Exception as shape_err2:
            if IS_DEBUGGING:
                print_warning(f"Error checking inline shapes via runs: {str(shape_err2)}")
        
        # Process shapes using COM automation (Windows only) - for text boxes and complex shapes
        if HAS_COM and os.name == 'nt':
            try:
                if log_callback:
                    log_callback(f"🔍 Checking shapes using COM automation...")
                
                import pythoncom
                pythoncom.CoInitialize()
                
                try:
                    # Use Word COM to access shapes
                    word_app = win32com.client.Dispatch("Word.Application")
                    word_app.Visible = False
                    
                    try:
                        # Open document
                        word_doc = word_app.Documents.Open(os.path.abspath(actual_input_path))
                        
                        # Process shapes in document
                        shape_count_com = word_doc.Shapes.Count
                        if shape_count_com > 0:
                            if log_callback:
                                log_callback(f"📐 Found {shape_count_com} shape(s) in document")
                            
                            for shape_idx in range(1, shape_count_com + 1):
                                try:
                                    shape = word_doc.Shapes(shape_idx)
                                    
                                    # Get text from shape
                                    shape_text = None
                                    
                                    # Method 1: TextFrame
                                    try:
                                        if hasattr(shape, 'TextFrame') and shape.TextFrame.HasText:
                                            shape_text = shape.TextFrame.TextRange.Text
                                    except:
                                        pass
                                    
                                    # Method 2: AlternativeText
                                    if not shape_text:
                                        try:
                                            if hasattr(shape, 'AlternativeText') and shape.AlternativeText:
                                                shape_text = shape.AlternativeText
                                        except:
                                            pass
                                    
                                    # Method 3: Name (if it contains text)
                                    if not shape_text:
                                        try:
                                            if hasattr(shape, 'Name') and shape.Name:
                                                # Only use name if it looks like actual text (not just a shape name)
                                                name = shape.Name
                                                if len(name) > 3 and not name.startswith('Shape'):
                                                    shape_text = name
                                        except:
                                            pass
                                    
                                    if shape_text and shape_text.strip() and should_translate(shape_text, skip_languages):
                                        clean_text_value = clean_text(shape_text)
                                        texts_to_translate.append(clean_text_value)
                                        # Store reference as ("shape", shape index, "com")
                                        text_references.append(("shape", shape_idx, "com"))
                                        if IS_DEBUGGING:
                                            print_info(f"Found text in shape {shape_idx}: {clean_text_value[:50]}...")
                                except Exception as shape_process_err:
                                    if IS_DEBUGGING:
                                        print_warning(f"Error processing shape {shape_idx}: {str(shape_process_err)}")
                                    continue
                        
                        # Process text boxes (inline shapes)
                        # Text boxes are accessed through the document's inline shapes
                        try:
                            # Get all inline shapes
                            for inline_idx in range(1, word_doc.InlineShapes.Count + 1):
                                try:
                                    inline_shape = word_doc.InlineShapes(inline_idx)
                                    
                                    # Get text from inline shape
                                    inline_text = None
                                    
                                    # Method 1: TextFrame
                                    try:
                                        if hasattr(inline_shape, 'TextFrame') and inline_shape.TextFrame.HasText:
                                            inline_text = inline_shape.TextFrame.TextRange.Text
                                    except:
                                        pass
                                    
                                    # Method 2: AlternativeText
                                    if not inline_text:
                                        try:
                                            if hasattr(inline_shape, 'AlternativeText') and inline_shape.AlternativeText:
                                                inline_text = inline_shape.AlternativeText
                                        except:
                                            pass
                                    
                                    if inline_text and inline_text.strip() and should_translate(inline_text, skip_languages):
                                        clean_text_value = clean_text(inline_text)
                                        texts_to_translate.append(clean_text_value)
                                        # Store reference as ("inline_shape", inline shape index, "com")
                                        text_references.append(("inline_shape", inline_idx, "com"))
                                        if IS_DEBUGGING:
                                            print_info(f"Found text in inline shape {inline_idx}: {clean_text_value[:50]}...")
                                except:
                                    continue
                        except Exception as inline_err:
                            if IS_DEBUGGING:
                                print_warning(f"Error processing inline shapes: {str(inline_err)}")
                        
                        word_doc.Close(SaveChanges=False)
                    finally:
                        word_app.Quit()
                finally:
                    pythoncom.CoUninitialize()
            except Exception as com_err:
                if IS_DEBUGGING:
                    print_warning(f"COM automation for shapes failed: {str(com_err)}")
                if log_callback:
                    log_callback(f"⚠️ Could not process shapes via COM: {str(com_err)}")
        
        # TOC processing removed - Table of Contents will not be translated
        
        # Finish scanning phase
        if progress:
            progress.update(scan_task, completed=1.0, description="[green]Scanning complete")
        
        # Skip if no text to translate
        if not texts_to_translate:
            print_success(f"No text to translate in document '{filename}'.")
            if progress:
                progress.update(file_task, completed=1.0, description=f"[cyan]Processing {filename} - No translation needed")
            # Still save a copy in the output directory
            doc.save(output_path)
            print_success(f"File saved at: {output_path}")
            return output_path
        
        # Add translation task
        total_elements = len(texts_to_translate)
        if progress:
            trans_task = progress.add_task("[yellow]Translating content", total=total_elements)
            progress.update(file_task, completed=0.4, description=f"[cyan]Processing {filename} - Translation in progress")
            
        # Split into batches for processing
        batch_size = 50  # Smaller batch size for better progress tracking
        total_batches = (len(texts_to_translate) - 1) // batch_size + 1
        processed_count = 0
        
        print_info(f"Preparing to translate {len(texts_to_translate)} text segments in {total_batches} batches.")
        
        for i in range(0, len(texts_to_translate), batch_size):
            # Check for cancellation before each batch
            if cancel_event and cancel_event.is_set():
                print_info("Translation cancelled - closing document")
                try:
                    doc.save(output_path)  # Save partial progress if needed
                except:
                    pass
                return None
            
            batch_texts = texts_to_translate[i:i+batch_size]
            batch_refs = text_references[i:i+batch_size]
            current_batch_num = i // batch_size + 1
            
            if IS_DEBUGGING:
                print_info(f"Translating batch {current_batch_num}/{total_batches} ({len(batch_texts)} texts)")
            
            # Define a progress callback for translation
            def update_translation_progress(current: int, total: int) -> None:
                if progress:
                    progress.update(trans_task, 
                                   description=f"[yellow]Translating batch {current_batch_num}/{total_batches} (Attempt {current+1}/{total+1})")
            
            # Translate batch
            translated_batch = translate_batch(
                batch_texts, 
                target_lang,
                api_client, 
                progress_callback=update_translation_progress,
                log_callback=log_callback,
                translation_context=get_translation_context()
            )
            
            # Check for cancellation after batch translation
            if cancel_event and cancel_event.is_set():
                print_info("Translation cancelled - closing document")
                try:
                    doc.save(output_path)  # Save partial progress if needed
                except:
                    pass
                return None
            
            # Debug: Check if translation actually happened (only in debug mode)
            if IS_DEBUGGING and translated_batch and len(translated_batch) > 0:
                sample_original = batch_texts[0][:50] if batch_texts else ""
                sample_translated = translated_batch[0][:50] if translated_batch[0] else ""
                if sample_original and sample_translated and sample_original == sample_translated:
                    print_warning(f"⚠️ WARNING: Translation may have failed - first text unchanged")
                else:
                    print_info(f"✅ Translation verified - text changed")
            
            # Update translated content
            if IS_DEBUGGING:
                print_info(f"Updating content for batch {current_batch_num} ({len(batch_refs)} items)...")
            update_count = 0
            skip_count = 0
            
            for j, ref in enumerate(batch_refs):
                # Update progress
                if progress:
                    processed_count += 1
                    progress.update(trans_task, completed=processed_count)
                    
                if j < len(translated_batch) and translated_batch[j] and translated_batch[j].strip():
                    # Verify translation actually changed the text
                    original_text = batch_texts[j] if j < len(batch_texts) else ""
                    translated_text = translated_batch[j]
                    
                    # Skip if translation is same as original (translation may have failed)
                    if original_text and translated_text and original_text.strip() == translated_text.strip():
                        skip_count += 1
                        print_warning(f"⚠️ Skipping update for item {j}: translation unchanged (may indicate API failure)")
                        continue
                    
                    update_count += 1
                    try:
                        # Paragraph - preserve formatting
                        if ref[0] == "paragraph":
                            _, para_idx = ref
                            para = doc.paragraphs[para_idx]
                            _update_paragraph_text_preserve_formatting(para, translated_batch[j])
                            print_success(f"Updated text in paragraph {para_idx + 1}")
                        
                        # Table cell - preserve formatting
                        elif ref[0] == "table":
                            _, table_idx, row_idx, cell_idx, para_idx = ref
                            para = doc.tables[table_idx].rows[row_idx].cells[cell_idx].paragraphs[para_idx]
                            _update_paragraph_text_preserve_formatting(para, translated_batch[j])
                            print_success(f"Updated text in table {table_idx + 1}, cell [{row_idx + 1}, {cell_idx + 1}]")
                        
                        # Header - preserve formatting
                        elif ref[0] == "header":
                            _, section_idx, header_type, para_idx = ref
                            header = getattr(doc.sections[section_idx], header_type)
                            para = header.paragraphs[para_idx]
                            _update_paragraph_text_preserve_formatting(para, translated_batch[j])
                            print_success(f"Updated text in section {section_idx + 1}, {header_type}")
                        
                        # Footer - preserve formatting
                        elif ref[0] == "footer":
                            _, section_idx, footer_type, para_idx = ref
                            footer = getattr(doc.sections[section_idx], footer_type)
                            para = footer.paragraphs[para_idx]
                            _update_paragraph_text_preserve_formatting(para, translated_batch[j])
                            print_success(f"Updated text in section {section_idx + 1}, {footer_type}")
                        
                        # Shape (via COM) - store for later COM update
                        elif ref[0] == "shape" and len(ref) >= 3:
                            shape_idx = ref[1]
                            shape_updates[shape_idx] = translated_batch[j]
                            if IS_DEBUGGING:
                                print_info(f"Shape {shape_idx} translation ready (will update via COM)")
                        
                        # Inline shape (via COM) - store for later COM update
                        elif ref[0] == "inline_shape" and len(ref) >= 3:
                            inline_idx = ref[1]
                            inline_shape_updates[inline_idx] = translated_batch[j]
                            if IS_DEBUGGING:
                                print_info(f"Inline shape {inline_idx} translation ready (will update via COM)")
                        
                        else:
                            print_warning(f"Unknown reference type: {ref[0]}")
                            
                    except Exception as update_err:
                        print_warning(f"Error updating content: {str(update_err)}")
        
        # Update file task
        if progress:
            progress.update(file_task, completed=0.8, description=f"[cyan]Processing {filename} - Saving file")
            progress.update(trans_task, completed=total_elements, description="[yellow]Translation complete")
            
        # Save the translated document first
        print_info(f"Saving translated Word document to: {output_path}")
        doc.save(output_path)
        
        # Update shapes and inline shapes using COM (if available and needed)
        if HAS_COM and os.name == 'nt' and (shape_updates or inline_shape_updates):
            try:
                if log_callback:
                    log_callback(f"🔄 Updating shapes and text boxes...")
                
                import pythoncom
                pythoncom.CoInitialize()
                
                try:
                    word_app = win32com.client.Dispatch("Word.Application")
                    word_app.Visible = False
                    
                    try:
                        word_doc = word_app.Documents.Open(os.path.abspath(output_path))
                        
                        try:
                            # Update shapes
                            for shape_idx, translated_text in shape_updates.items():
                                try:
                                    shape = word_doc.Shapes(shape_idx)
                                    if hasattr(shape, 'TextFrame') and shape.TextFrame.HasText:
                                        shape.TextFrame.TextRange.Text = translated_text
                                        if IS_DEBUGGING:
                                            print_success(f"Updated shape {shape_idx}")
                                except Exception as shape_update_err:
                                    if IS_DEBUGGING:
                                        print_warning(f"Could not update shape {shape_idx}: {str(shape_update_err)}")
                            
                            # Update inline shapes
                            for inline_idx, translated_text in inline_shape_updates.items():
                                try:
                                    inline_shape = word_doc.InlineShapes(inline_idx)
                                    if hasattr(inline_shape, 'TextFrame') and inline_shape.TextFrame.HasText:
                                        inline_shape.TextFrame.TextRange.Text = translated_text
                                        if IS_DEBUGGING:
                                            print_success(f"Updated inline shape {inline_idx}")
                                except Exception as inline_update_err:
                                    if IS_DEBUGGING:
                                        print_warning(f"Could not update inline shape {inline_idx}: {str(inline_update_err)}")
                            
                            word_doc.Save()
                        finally:
                            if 'word_doc' in locals():
                                try:
                                    word_doc.Close()
                                except:
                                    pass
                    finally:
                        if 'word_app' in locals():
                            try:
                                word_app.Quit()
                            except:
                                pass
                finally:
                    pythoncom.CoUninitialize()
                    
                if shape_updates or inline_shape_updates:
                    if log_callback:
                        log_callback(f"✅ Updated {len(shape_updates)} shape(s) and {len(inline_shape_updates)} inline shape(s)")
            except Exception as com_shape_update_err:
                if IS_DEBUGGING:
                    print_warning(f"COM update for shapes failed: {str(com_shape_update_err)}")
                if log_callback:
                    log_callback(f"⚠️ Could not update shapes via COM: {str(com_shape_update_err)}")
        
        # TOC update removed - Table of Contents will not be translated
        
        # If original was .doc, we need to convert the translated .docx back to .doc format
        if ext.lower() == '.doc' and temp_docx_path:
            try:
                print_info(f"Converting translated .docx back to .doc format...")
                if log_callback:
                    log_callback(f"🔄 Converting translated file back to .doc format...")
                
                # Create final .doc output path
                final_output_path = os.path.join(output_dir, f"{base_name}_TRANSLATED_{target_lang.upper()}_{timestamp}.doc")
                
                # Initialize COM for this thread
                import pythoncom
                pythoncom.CoInitialize()
                
                try:
                    # Use Word COM to convert .docx back to .doc
                    word_app = win32com.client.Dispatch("Word.Application")
                    word_app.Visible = False
                    
                    try:
                        # Open translated .docx file
                        doc_com = word_app.Documents.Open(os.path.abspath(output_path))
                        
                        # Save as .doc (format 0 = wdFormatDocument)
                        doc_com.SaveAs2(
                            FileName=os.path.abspath(final_output_path),
                            FileFormat=0  # wdFormatDocument (.doc)
                        )
                        doc_com.Close()
                        
                        # Remove temporary .docx output
                        try:
                            os.remove(output_path)
                        except:
                            pass
                        
                        output_path = final_output_path
                        print_success(f"Successfully converted translated file to .doc format")
                        if log_callback:
                            log_callback(f"✅ File converted to .doc format successfully")
                    finally:
                        word_app.Quit()
                finally:
                    # Uninitialize COM
                    pythoncom.CoUninitialize()
            except Exception as convert_back_err:
                print_warning(f"Could not convert translated file back to .doc format: {str(convert_back_err)}")
                print_info(f"Translated file saved as .docx instead: {output_path}")
                if log_callback:
                    log_callback(f"⚠️ Could not convert to .doc, saved as .docx instead")
        
        print_success(f"File saved successfully: {output_path}")
        
        # Clean up temporary .docx file if it was created
        if temp_docx_path and os.path.exists(temp_docx_path):
            try:
                os.remove(temp_docx_path)
                if IS_DEBUGGING:
                    print_info(f"Cleaned up temporary .docx file: {temp_docx_path}")
            except Exception as cleanup_err:
                print_warning(f"Could not delete temporary file: {cleanup_err}")
        
        if progress:
            progress.update(file_task, completed=1.0, description=f"[cyan]Processing {filename} - Complete")
            
        return output_path
        
    except Exception as e:
        print_error(f"Error processing Word file '{input_path}': {str(e)}")
        if progress and file_task:
            progress.update(file_task, completed=1.0, description=f"[red]Processing {filename} - Failed")
        
        # Clean up temporary .docx file if it was created
        if 'temp_docx_path' in locals() and temp_docx_path and os.path.exists(temp_docx_path):
            try:
                os.remove(temp_docx_path)
            except:
                pass
        
        return None 


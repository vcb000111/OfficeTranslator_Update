# -*- coding: utf-8 -*-
"""
Update Checker Module
====================
Handles checking for application updates from remote server.
"""

import sys
import os
import json
from typing import Optional, Dict
from urllib.parse import quote

# Import requests for update check
try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

# ============================================================================
# UPDATE CHECK CONFIGURATION
# ============================================================================
# URLs are loaded from .env file only (no hardcoded fallback)
# Required variables in .env.dev (development):
#   - VERSION_DEVELOPMENT
#   - UPDATE_LINK_DEVELOPMENT
# Required variables in .env.pro (production):
#   - VERSION_PRODUCTION
#   - UPDATE_LINK_PRODUCTION

# Timeout for update check (seconds)
UPDATE_CHECK_TIMEOUT = 5

# Enable/disable auto update check
AUTO_CHECK_UPDATES = True
# ============================================================================

# Proxy configuration
# Note: File is now stored in AppData directory, not in source directory
PROXY_SETTINGS_FILE = "proxy_settings.json"


def get_current_version() -> str:
    """
    Get current version from version.txt file
    Tries multiple locations:
    1. Same directory as executable (when running as exe)
    2. _internal directory (onedir mode - files are in _internal/)
    3. Same directory as this file (src/version.txt) - when running as script
    4. Parent directory (version.txt) - when running as script
    
    Returns:
        str: Current version string, or "3.1" as fallback
    """
    fallback_version = "3.1"
    
    # Try to find version.txt file
    possible_paths = []
    
    if getattr(sys, 'frozen', False):
        # Running as exe
        exe_dir = os.path.dirname(sys.executable)
        # Try same directory as exe
        possible_paths.append(os.path.join(exe_dir, "version.txt"))
        # Try _internal directory (onedir mode)
        internal_dir = os.path.join(exe_dir, "_internal")
        possible_paths.append(os.path.join(internal_dir, "version.txt"))
    else:
        # Running as script
        # Try src/version.txt (same directory as this file)
        this_file_dir = os.path.dirname(os.path.abspath(__file__))
        possible_paths.append(os.path.join(this_file_dir, "version.txt"))
        
        # Try parent directory version.txt
        parent_dir = os.path.dirname(this_file_dir)
        possible_paths.append(os.path.join(parent_dir, "version.txt"))
    
    # Try to read version from file
    for version_path in possible_paths:
        try:
            if os.path.exists(version_path):
                with open(version_path, 'r', encoding='utf-8') as f:
                    version = f.read().strip()
                    if version:
                        # Log for debugging (only in development)
                        if not getattr(sys, 'frozen', False):
                            print(f"[Update Check] Loaded version from: {version_path} -> {version}")
                        return version
        except Exception as e:
            # Log for debugging (only in development)
            if not getattr(sys, 'frozen', False):
                print(f"[Update Check] Error reading {version_path}: {str(e)}")
            continue
    
    # Fallback to default version
    if not getattr(sys, 'frozen', False):
        print(f"[Update Check] Could not find version.txt, using fallback: {fallback_version}")
    return fallback_version


# Get current version (will be read from file)
CURRENT_VERSION = get_current_version()


def get_env_file_path() -> str:
    """
    Get the correct .env file path based on environment (dev vs production).
    Imported from translator module or defined here if not available.
    
    Returns:
        str: Path to .env file to use
    """
    try:
        # Try to import from translator module
        from translator import get_env_file_path as translator_get_env_file_path
        return translator_get_env_file_path()
    except ImportError:
        # Fallback: define here if translator module not available
        if getattr(sys, 'frozen', False):
            # Running as compiled exe (production)
            app_dir = os.path.dirname(sys.executable)
            env_file_pro = os.path.join(app_dir, ".env.pro")
            env_file = os.path.join(app_dir, ".env")
            
            if os.path.exists(env_file_pro):
                return env_file_pro
            else:
                return env_file
        else:
            # Running as script (development)
            this_file_dir = os.path.dirname(os.path.abspath(__file__))
            parent_dir = os.path.dirname(this_file_dir)
            env_file_dev = os.path.join(parent_dir, ".env.dev")
            env_file = os.path.join(parent_dir, ".env")
            
            if os.path.exists(env_file_dev):
                return env_file_dev
            else:
                return env_file


def load_env_variable(key: str, default: str = "") -> str:
    """
    Load environment variable from .env file or .env.enc (encrypted) file.
    Tries .env file first, then decrypts .env.enc if not found.
    This ensures we always read the latest value from file, not from cached environment.
    
    Args:
        key: Environment variable name
        default: Default value if not found
        
    Returns:
        str: Value from .env/.env.enc file or default
    """
    env_file = get_env_file_path()
    
    # Try to read from .env file first
    try:
        if os.path.exists(env_file):
            # Read directly from file (don't use dotenv cache)
            with open(env_file, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    # Skip comments and empty lines
                    if not line or line.startswith('#'):
                        continue
                    # Parse key=value
                    if '=' in line:
                        k, v = line.split('=', 1)
                        k = k.strip()
                        v = v.strip().strip('"').strip("'")
                        # Remove BOM if present
                        if v.startswith('\ufeff'):
                            v = v[1:]
                        # Check if this is the key we're looking for
                        if k == key:
                            if not getattr(sys, 'frozen', False):
                                print(f"[Update Check] Found {key} in {env_file}: {v[:50]}..." if len(v) > 50 else f"[Update Check] Found {key} in {env_file}: {v}")
                            return v
    except Exception as e:
        if not getattr(sys, 'frozen', False):
            print(f"[Update Check] Error reading .env file {env_file}: {str(e)}")
    
    # If not found in .env file, try to read from .env.enc (encrypted file)
    try:
        # Import decrypt functions from translator module
        find_env_enc_file_func = None
        decrypt_env_file_func = None
        
        try:
            from translator import find_env_enc_file, decrypt_env_file
            find_env_enc_file_func = find_env_enc_file
            decrypt_env_file_func = decrypt_env_file
        except ImportError:
            # Fallback: define here if translator module not available
            def find_env_enc_file_local(env_file: str):
                """Find .env.enc file"""
                if getattr(sys, 'frozen', False):
                    exe_dir = os.path.dirname(sys.executable)
                    internal_dir = os.path.join(exe_dir, "_internal")
                    internal_enc_file = os.path.join(internal_dir, ".env.enc")
                    if os.path.exists(internal_enc_file):
                        return internal_enc_file
                enc_file = env_file + ".enc"
                if os.path.exists(enc_file):
                    return enc_file
                return None
            
            def decrypt_env_file_local(enc_file_path: str):
                """Decrypt .env.enc file"""
                try:
                    import base64
                    import hashlib
                    # Read encrypted file
                    with open(enc_file_path, 'rb') as f:
                        encoded = f.read()
                    
                    if not encoded:
                        if not getattr(sys, 'frozen', False):
                            print(f"[Update Check] Error decrypting .env.enc: File is empty")
                        return None
                    
                    # Decode from base64
                    try:
                        encrypted = base64.b64decode(encoded, validate=True)
                    except Exception as e:
                        if not getattr(sys, 'frozen', False):
                            print(f"[Update Check] Error decrypting .env.enc: Invalid base64 encoding - {str(e)}")
                        return None
                    
                    # Get decryption key
                    # Note: Seed should remain constant across versions to ensure .env.enc files
                    # created with older versions can still be decrypted by newer versions
                    seed = "OfficeTranslator_DPIT"
                    key = hashlib.sha256(seed.encode('utf-8')).digest()
                    # XOR decryption
                    decrypted = bytearray()
                    for i, byte in enumerate(encrypted):
                        decrypted.append(byte ^ key[i % len(key)])
                    # Convert to string with error handling
                    try:
                        return decrypted.decode('utf-8')
                    except UnicodeDecodeError as e:
                        if not getattr(sys, 'frozen', False):
                            print(f"[Update Check] Error decrypting .env.enc: Invalid UTF-8 after decryption (wrong encryption key?) - {str(e)}")
                        return None
                except FileNotFoundError:
                    if not getattr(sys, 'frozen', False):
                        print(f"[Update Check] Error decrypting .env.enc: File not found - {enc_file_path}")
                    return None
                except Exception as e:
                    if not getattr(sys, 'frozen', False):
                        print(f"[Update Check] Error decrypting .env.enc: {str(e)}")
                    return None
            
            find_env_enc_file_func = find_env_enc_file_local
            decrypt_env_file_func = decrypt_env_file_local
        
        # Try to find and decrypt .env.enc file
        if find_env_enc_file_func and decrypt_env_file_func:
            enc_file = find_env_enc_file_func(env_file)
            if enc_file and os.path.exists(enc_file):
                decrypted_content = decrypt_env_file_func(enc_file)
                if decrypted_content:
                    # Parse decrypted content
                    for line in decrypted_content.split('\n'):
                        line = line.strip()
                        # Skip comments and empty lines
                        if not line or line.startswith('#'):
                            continue
                        # Parse key=value
                        if '=' in line:
                            k, v = line.split('=', 1)
                            k = k.strip()
                            v = v.strip().strip('"').strip("'")
                            # Remove BOM if present
                            if v.startswith('\ufeff'):
                                v = v[1:]
                            # Check if this is the key we're looking for
                            if k == key:
                                if not getattr(sys, 'frozen', False):
                                    print(f"[Update Check] Found {key} in encrypted .env.enc: {v[:50]}..." if len(v) > 50 else f"[Update Check] Found {key} in encrypted .env.enc: {v}")
                                return v
    except Exception as e:
        if not getattr(sys, 'frozen', False):
            print(f"[Update Check] Error reading .env.enc file: {str(e)}")
    
    # Not found in both .env and .env.enc - debug info
    if not getattr(sys, 'frozen', False):
        print(f"[Update Check] Variable {key} not found in .env or .env.enc file")
        print(f"[Update Check] Checked .env file: {env_file}")
        if os.path.exists(env_file):
            print(f"[Update Check] .env file exists, listing keys...")
            try:
                with open(env_file, 'r', encoding='utf-8') as f:
                    keys_found = []
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith('#') and '=' in line:
                            k = line.split('=', 1)[0].strip()
                            keys_found.append(k)
                    if keys_found:
                        print(f"[Update Check] Keys found in .env: {', '.join(keys_found)}")
            except:
                pass
        
        # Also check .env.enc
        try:
            if find_env_enc_file_func and decrypt_env_file_func:
                enc_file = find_env_enc_file_func(env_file)
                if enc_file and os.path.exists(enc_file):
                    print(f"[Update Check] .env.enc file exists: {enc_file}")
                    try:
                        decrypted = decrypt_env_file_func(enc_file)
                        if decrypted:
                            keys_found = []
                            for line in decrypted.split('\n'):
                                line = line.strip()
                                if line and not line.startswith('#') and '=' in line:
                                    k = line.split('=', 1)[0].strip()
                                    keys_found.append(k)
                            if keys_found:
                                print(f"[Update Check] Keys found in .env.enc: {', '.join(keys_found)}")
                    except:
                        pass
        except:
            pass
    
    return default


def get_version_check_url() -> str:
    """
    Get version check URL from .env file only (no fallback).
    Uses DEV URL if running as script, PRO URL if running as exe.
    
    Returns:
        str: URL to check version, or empty string if not found in .env
    """
    if getattr(sys, 'frozen', False):
        # Production mode
        url = load_env_variable("VERSION_PRODUCTION", "")
    else:
        # Development mode
        url = load_env_variable("VERSION_DEVELOPMENT", "")
    
    return url


def get_update_link_url() -> str:
    """
    Get update link URL from .env file only (no fallback).
    Uses DEV URL if running as script, PRO URL if running as exe.
    
    Returns:
        str: URL to get update link, or empty string if not found in .env
    """
    if getattr(sys, 'frozen', False):
        # Production mode
        url = load_env_variable("UPDATE_LINK_PRODUCTION", "")
    else:
        # Development mode
        url = load_env_variable("UPDATE_LINK_DEVELOPMENT", "")
    
    return url


def get_appdata_directory() -> str:
    """
    Get the AppData directory for storing user settings.
    Settings are stored in %APPDATA%\OfficeDocumentTranslator\ to persist across updates.
    
    Returns:
        str: Path to AppData directory for this application
    """
    app_name = "OfficeDocumentTranslator"
    
    if sys.platform == "win32":
        # Windows: Use %APPDATA%
        appdata = os.getenv('APPDATA')
        if appdata:
            appdata_dir = os.path.join(appdata, app_name)
            # Create directory if it doesn't exist
            os.makedirs(appdata_dir, exist_ok=True)
            return appdata_dir
    else:
        # Linux/Mac: Use ~/.config or ~/.local/share
        home = os.path.expanduser("~")
        if sys.platform == "darwin":  # macOS
            appdata_dir = os.path.join(home, "Library", "Application Support", app_name)
        else:  # Linux
            appdata_dir = os.path.join(home, ".config", app_name)
        
        # Create directory if it doesn't exist
        os.makedirs(appdata_dir, exist_ok=True)
        return appdata_dir
    
    # Fallback to app directory if AppData is not available
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        return os.path.dirname(script_dir)

def get_proxy_settings_file() -> str:
    """Get path to proxy settings file (stored in AppData to persist across updates)"""
    appdata_dir = get_appdata_directory()
    return os.path.join(appdata_dir, "proxy_settings.json")

def load_proxy_settings() -> Optional[Dict[str, str]]:
    """
    Load proxy settings from file (migrates from old location if needed)
    
    Returns:
        Optional[Dict]: Dictionary with 'http', 'https' proxy URLs and optional 'username', 'password', or None
    """
    proxy_file = get_proxy_settings_file()
    
    # Try to load from new location (AppData)
    try:
        if os.path.exists(proxy_file):
            with open(proxy_file, 'r', encoding='utf-8') as f:
                settings = json.load(f)
                if settings.get('http') or settings.get('https'):
                    return settings
    except Exception as e:
        if not getattr(sys, 'frozen', False):
            print(f"[Update Check] Error loading proxy settings: {str(e)}")
    
    # Try to migrate from old location (app directory)
    try:
        if getattr(sys, 'frozen', False):
            exe_dir = os.path.dirname(sys.executable)
            old_proxy_file = os.path.join(exe_dir, ".proxy_settings.json")
        else:
            script_dir = os.path.dirname(os.path.abspath(__file__))
            parent_dir = os.path.dirname(script_dir)
            old_proxy_file = os.path.join(parent_dir, ".proxy_settings.json")
        
        if os.path.exists(old_proxy_file):
            try:
                with open(old_proxy_file, 'r', encoding='utf-8') as f:
                    old_settings = json.load(f)
                    if old_settings.get('http') or old_settings.get('https'):
                        # Migrate to new location
                        save_proxy_settings(old_settings)
                        # Optionally remove old file (commented out for safety)
                        # os.remove(old_proxy_file)
                        return old_settings
            except Exception:
                pass
    except Exception:
        pass
    
    return None

def save_proxy_settings(proxy_dict: Dict[str, str]) -> bool:
    """
    Save proxy settings to file
    
    Args:
        proxy_dict: Dictionary with 'http' and/or 'https' proxy URLs
        
    Returns:
        bool: True if saved successfully, False otherwise
    """
    proxy_file = get_proxy_settings_file()
    try:
        with open(proxy_file, 'w', encoding='utf-8') as f:
            json.dump(proxy_dict, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        if not getattr(sys, 'frozen', False):
            print(f"[Update Check] Error saving proxy settings: {str(e)}")
        return False

def normalize_proxy_url(url: str) -> str:
    """
    Normalize proxy URL - ensure it has proper format
    
    Args:
        url: Proxy URL (may or may not have http:// prefix)
        
    Returns:
        str: Normalized proxy URL with http:// prefix
    """
    if not url:
        return url
    
    url = url.strip()
    
    # Remove all duplicate http:// or https:// prefixes
    while url.startswith('http://http://') or url.startswith('https://http://') or url.startswith('http://https://'):
        if url.startswith('http://http://'):
            url = url[7:]  # Remove first "http://"
        elif url.startswith('https://http://'):
            url = url[8:]  # Remove "https://"
        elif url.startswith('http://https://'):
            url = url[7:]  # Remove "http://"
    
    # If URL already has http:// or https://, return as is
    if url.startswith('http://') or url.startswith('https://'):
        return url
    
    # Add http:// if not present
    url = f"http://{url}"
    
    return url

def detect_system_proxy() -> Optional[Dict[str, str]]:
    """
    Detect proxy settings from system environment variables and Windows registry.
    This function only reads proxy configuration, it does NOT test if proxy server is reachable.
    To check if proxy is reachable, use check_proxy_server_status() separately.
    
    Returns:
        Optional[Dict]: Dictionary with 'http' and 'https' proxy URLs, or None
    """
    proxy_dict = {}
    debug_mode = not getattr(sys, 'frozen', False)
    
    # Check environment variables
    http_proxy = os.environ.get('HTTP_PROXY') or os.environ.get('http_proxy')
    https_proxy = os.environ.get('HTTPS_PROXY') or os.environ.get('https_proxy')
    
    if http_proxy:
        proxy_dict['http'] = normalize_proxy_url(http_proxy)
    if https_proxy:
        proxy_dict['https'] = normalize_proxy_url(https_proxy)
    
    # Check Windows registry for proxy (if on Windows)
    if sys.platform == "win32":
        try:
            import winreg
            # Check Internet Settings proxy (try both HKEY_CURRENT_USER and HKEY_LOCAL_MACHINE)
            registry_paths = [
                (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"),
                (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Internet Settings")
            ]
            
            for hkey, path in registry_paths:
                try:
                    key = winreg.OpenKey(hkey, path)
                    try:
                        # Read ProxyEnable value (1 = enabled, 0 = disabled)
                        try:
                            proxy_enable, _ = winreg.QueryValueEx(key, "ProxyEnable")
                        except FileNotFoundError:
                            # ProxyEnable key doesn't exist - proxy is disabled
                            proxy_enable = 0
                            continue
                
                        # Only read ProxyServer if proxy is enabled
                        if proxy_enable == 1:
                            try:
                                proxy_server, _ = winreg.QueryValueEx(key, "ProxyServer")
                                if proxy_server:
                                    # Format: "proxy:port" or "http=proxy:port;https=proxy:port"
                                    if '=' in proxy_server:
                                        # Multiple proxies
                                        for part in proxy_server.split(';'):
                                            if '=' in part:
                                                proto, addr = part.split('=', 1)
                                                # Normalize to avoid duplicate http://
                                                normalized = normalize_proxy_url(addr)
                                                proxy_dict[proto.lower()] = normalized
                                    else:
                                        # Single proxy for both
                                        normalized = normalize_proxy_url(proxy_server)
                                        if 'http' not in proxy_dict:
                                            proxy_dict['http'] = normalized
                                        if 'https' not in proxy_dict:
                                            proxy_dict['https'] = normalized
                                    # Found proxy, break out of loop
                                    break
                            except FileNotFoundError:
                                # ProxyServer key doesn't exist even though ProxyEnable=1
                                # This shouldn't happen, but handle it gracefully
                                pass
                    finally:
                        winreg.CloseKey(key)
                except Exception:
                    continue
        except Exception:
            pass  # Ignore registry errors
    
    return proxy_dict if proxy_dict else None

def check_proxy_server_status(proxy_config: Optional[Dict[str, str]], timeout: int = 3) -> str:
    """
    Check if proxy server is available and what status it has.
    
    Args:
        proxy_config: Proxy configuration dictionary
        timeout: Connection timeout in seconds
        
    Returns:
        str: Status string - "offline" (proxy server not running), 
             "needs_auth" (proxy server running but needs authentication),
             "working" (proxy connection works),
             "unknown" (cannot determine)
    """
    if not proxy_config or not REQUESTS_AVAILABLE:
        return "unknown"
    
    try:
        # First, try to connect through proxy WITHOUT authentication
        # to see if proxy server is running
        proxy_url = proxy_config.get('http') or proxy_config.get('https', '')
        if not proxy_url:
            return "unknown"
        
        # Normalize proxy URL (remove any existing auth)
        proxy_url = normalize_proxy_url(proxy_url)
        # Remove existing auth if present
        if '@' in proxy_url:
            if '://' in proxy_url:
                scheme, rest = proxy_url.split('://', 1)
                if '@' in rest:
                    rest = rest.split('@', 1)[1]  # Remove existing auth
                proxy_url = f"{scheme}://{rest}"
            else:
                proxy_url = proxy_url.split('@', 1)[1]
        
        # Test with proxy but no auth - if we get 407, proxy is running but needs auth
        test_url = "http://www.google.com"
        test_proxies = {'http': proxy_url, 'https': proxy_url}
        
        try:
            response = requests.get(
                test_url,
                timeout=timeout,
                proxies=test_proxies,
                verify=False
            )
            # If we get a response, proxy is working (even without auth, some proxies allow it)
            return "working"
        except requests.exceptions.ProxyError as e:
            error_str = str(e).lower()
            # Check if proxy server cannot be reached (offline/unresolvable)
            if 'unable to connect to proxy' in error_str or 'failed to resolve' in error_str or 'name resolution' in error_str or 'getaddrinfo failed' in error_str:
                return "offline"
            # 407 Proxy Authentication Required means proxy is running but needs auth
            if '407' in error_str or 'authentication' in error_str or 'proxy authentication' in error_str:
                return "needs_auth"
            # Other proxy errors - assume offline if connection-related
            if 'connection' in error_str or 'connect' in error_str:
                return "offline"
            # Other proxy errors
            return "unknown"
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
            error_str = str(e).lower()
            # Check if it's a proxy connection error
            if 'proxy' in error_str or 'failed to resolve' in error_str or 'name resolution' in error_str or 'getaddrinfo failed' in error_str:
                return "offline"
            # Cannot connect to proxy server - it's probably offline
            return "offline"
        except Exception as e:
            error_str = str(e).lower()
            # Check for DNS resolution errors
            if 'failed to resolve' in error_str or 'name resolution' in error_str or 'getaddrinfo failed' in error_str:
                return "offline"
            return "unknown"
            
    except Exception:
        return "unknown"


def test_proxy_connection(proxy_config: Optional[Dict[str, str]], timeout: int = 5) -> bool:
    """
    Test if proxy connection works by trying to fetch a simple URL.
    
    Args:
        proxy_config: Proxy configuration dictionary
        timeout: Connection timeout in seconds
        
    Returns:
        bool: True if proxy connection works, False otherwise
    """
    if not proxy_config or not REQUESTS_AVAILABLE:
        return False
    
    try:
        # Build proxy URLs with authentication
        proxies = build_proxy_url(proxy_config)
        
        # Test with a simple URL (Google's public DNS)
        test_url = "http://www.google.com"
        
        response = requests.get(
            test_url,
            timeout=timeout,
            proxies=proxies,
            verify=False  # Disable SSL for proxy testing
        )
        
        # If we get any response (even error), proxy is working
        return response.status_code is not None
    except requests.exceptions.ProxyError:
        # Proxy authentication failed or proxy error
        return False
    except requests.exceptions.ConnectionError:
        # Connection failed
        return False
    except Exception:
        # Other errors
        return False


def is_proxy_enabled_in_windows() -> Optional[bool]:
    """
    Check if proxy is enabled in Windows registry.
    
    Returns:
        Optional[bool]: True if proxy is enabled, False if disabled, None if cannot determine
    """
    if sys.platform != "win32":
        return None
    
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"
        )
        try:
            try:
                proxy_enable, _ = winreg.QueryValueEx(key, "ProxyEnable")
                return proxy_enable == 1
            except FileNotFoundError:
                # ProxyEnable key doesn't exist - proxy is disabled
                return False
        finally:
            winreg.CloseKey(key)
    except Exception:
        return None

def get_proxy_config() -> Optional[Dict[str, str]]:
    """
    Get proxy configuration from multiple sources (priority order):
    1. Windows registry (if Windows) - check if proxy is enabled first
    2. Saved proxy settings file (only if Windows registry shows proxy is enabled)
    3. System environment variables
    4. Windows registry detection (if not already checked)
    
    Note: This function does NOT test connection. Use test_proxy_connection() separately.
    
    Returns:
        Optional[Dict]: Dictionary with 'http' and 'https' proxy URLs, or None
    """
    debug_mode = not getattr(sys, 'frozen', False)
    
    # First, check Windows registry to see if proxy is enabled
    proxy_enabled = is_proxy_enabled_in_windows()
    if proxy_enabled is False:
        # Proxy is explicitly disabled in Windows settings - don't use saved settings
        # Don't use saved settings if proxy is disabled in Windows
        # (We don't delete saved settings in case user re-enables proxy later)
        return None
    
    # Try system detection first (Windows registry or environment variables)
    system_proxy = detect_system_proxy()
    if system_proxy:
        # Merge with saved settings to preserve username/password if they exist
        saved_proxy = load_proxy_settings()
        if saved_proxy:
            # Preserve username and password from saved settings
            if 'username' in saved_proxy:
                system_proxy['username'] = saved_proxy['username']
            if 'password' in saved_proxy:
                system_proxy['password'] = saved_proxy['password']
            # Only save if proxy URLs changed
            if (saved_proxy.get('http') != system_proxy.get('http') or 
                saved_proxy.get('https') != system_proxy.get('https')):
                save_proxy_settings(system_proxy)
        else:
            # No saved settings, save system proxy
            save_proxy_settings(system_proxy)
        return system_proxy
    
    # If no system proxy detected, try saved settings (only if proxy is enabled or unknown)
    if proxy_enabled is not False:  # True or None
        saved_proxy = load_proxy_settings()
        if saved_proxy:
            return saved_proxy
    
    return None


def get_proxy_config_if_available() -> Optional[Dict[str, str]]:
    """
    Get proxy configuration only if proxy server is available (online).
    If proxy server is offline, returns None so app won't use proxy.
    
    Returns:
        Optional[Dict]: Dictionary with 'http' and 'https' proxy URLs, or None
    """
    proxy_config = get_proxy_config()
    if not proxy_config:
        return None
    
    # Check if proxy server is available
    status = check_proxy_server_status(proxy_config, timeout=2)
    if status == "offline":
        # Proxy server is offline - don't use proxy
        return None
    
    # Proxy server is online (needs_auth, working, or unknown)
    return proxy_config

def compare_versions(current: str, latest: str) -> bool:
    """
    Compare version strings
    Returns True if latest > current
    Format: "3.1" or "3.1.1"
    
    Args:
        current: Current version string
        latest: Latest version string from server
        
    Returns:
        bool: True if latest > current, False otherwise
    """
    try:
        # Split version strings into parts
        current_parts = [int(x) for x in current.split('.')]
        latest_parts = [int(x) for x in latest.split('.')]
        
        # Pad with zeros to make same length
        max_len = max(len(current_parts), len(latest_parts))
        current_parts += [0] * (max_len - len(current_parts))
        latest_parts += [0] * (max_len - len(latest_parts))
        
        # Compare each part
        for i in range(max_len):
            if latest_parts[i] > current_parts[i]:
                return True
            elif latest_parts[i] < current_parts[i]:
                return False
        return False  # Versions are equal
    except Exception:
        # If parsing fails, do string comparison
        return latest > current


def build_proxy_url(proxy_config: Dict[str, str]) -> Dict[str, str]:
    """
    Build proxy URL with authentication if username/password provided
    
    Args:
        proxy_config: Dictionary with 'http', 'https', optional 'username', 'password'
        
    Returns:
        Dict[str, str]: Dictionary with 'http' and 'https' proxy URLs with auth
    """
    proxies = {}
    username = proxy_config.get('username', '').strip()
    password = proxy_config.get('password', '').strip()
    
    for proto in ['http', 'https']:
        if proto in proxy_config:
            proxy_url = proxy_config[proto].strip()
            
            # Normalize proxy URL first (remove any duplicate http://)
            proxy_url = normalize_proxy_url(proxy_url)
            
            # Add authentication if provided
            if username and password:
                # URL encode username and password to handle special characters
                encoded_username = quote(username, safe='')
                encoded_password = quote(password, safe='')
                
                # Check if URL already has authentication
                if '@' in proxy_url:
                    # Remove existing auth if present
                    if '://' in proxy_url:
                        scheme, rest = proxy_url.split('://', 1)
                        if '@' in rest:
                            rest = rest.split('@', 1)[1]  # Remove existing auth
                        proxy_url = f"{scheme}://{encoded_username}:{encoded_password}@{rest}"
                else:
                    # Add authentication
                    if proxy_url.startswith('http://'):
                        proxy_url = proxy_url.replace('http://', f'http://{encoded_username}:{encoded_password}@', 1)
                    elif proxy_url.startswith('https://'):
                        proxy_url = proxy_url.replace('https://', f'https://{encoded_username}:{encoded_password}@', 1)
                    else:
                        proxy_url = f'http://{encoded_username}:{encoded_password}@{proxy_url}'
            
            proxies[proto] = proxy_url
    
    return proxies

def get_latest_version(proxy_config: Optional[Dict[str, str]] = None, log_callback=None, auto_load_proxy: bool = True) -> Optional[str]:
    """
    Get latest version from server
    
    Args:
        proxy_config: Optional proxy configuration dictionary (may include username/password).
                     If None and auto_load_proxy=True, will try to get proxy config automatically.
                     If None and auto_load_proxy=False, will not use proxy.
        log_callback: Optional callback function to log messages (for GUI logging)
        auto_load_proxy: If True and proxy_config is None, will auto-load proxy config.
                        If False, will not use proxy if proxy_config is None.
        
    Returns:
        Optional[str]: Latest version string, or None if error
    """
    def log_msg(msg: str):
        """Log message to both console and callback"""
        if not getattr(sys, 'frozen', False):
            print(f"[Update Check] {msg}")
        if log_callback:
            log_callback(f"[Update Check] {msg}")
    
    if not REQUESTS_AVAILABLE:
        log_msg("requests module not available")
        return None
    
    # Get proxy config if not provided and auto_load_proxy is True
    if proxy_config is None and auto_load_proxy:
        proxy_config = get_proxy_config()
    
    # Log proxy configuration (without password)
    if proxy_config:
        safe_config = {k: v for k, v in proxy_config.items() if k != 'password'}
        log_msg(f"Proxy config: {safe_config}")
    else:
        log_msg("No proxy configuration")
    
    # Build proxy URLs with authentication
    proxies = None
    if proxy_config:
        proxies = build_proxy_url(proxy_config)
        # Don't log password, but log proxy URLs (without showing password)
        safe_proxies = {}
        for k, v in proxies.items():
            # Hide password in logged URL
            if '@' in v:
                parts = v.split('@')
                if len(parts) == 2:
                    auth_part = parts[0]
                    if '://' in auth_part:
                        scheme = auth_part.split('://')[0]
                        auth_rest = auth_part.split('://')[1]
                        if ':' in auth_rest:
                            user_part = auth_rest.split(':')[0]
                            server_part = parts[1]
                            safe_proxies[k] = f"{scheme}://{user_part}:***@{server_part}"
                        else:
                            safe_proxies[k] = v
                    elif ':' in auth_part:
                        user_part = auth_part.split(':')[0]
                        safe_proxies[k] = f"{user_part}:***@{parts[1]}"
                    else:
                        safe_proxies[k] = v
                else:
                    safe_proxies[k] = v
            else:
                safe_proxies[k] = v
        
        log_msg(f"Proxy URLs (built): {safe_proxies}")
    
    try:
        version_check_url = get_version_check_url()
        if not version_check_url:
            # Show which key was being looked for
            key_name = "VERSION_PRODUCTION" if getattr(sys, 'frozen', False) else "VERSION_DEVELOPMENT"
            log_msg(f"✗ {key_name} not found in .env file")
            return None
        
        log_msg(f"Fetching version from: {version_check_url}")
        log_msg(f"Timeout: {UPDATE_CHECK_TIMEOUT}s")
        
        # Disable SSL verification when using proxy (many corporate proxies use self-signed certs)
        # Always disable SSL verify when using proxy to avoid certificate issues
        verify_ssl = False if proxies else True
        
        if proxies:
            log_msg("SSL verification disabled (proxy may use self-signed certificate)")
        
        response = requests.get(
            version_check_url, 
            timeout=UPDATE_CHECK_TIMEOUT,
            proxies=proxies,
            verify=verify_ssl
        )
        
        log_msg(f"Response status: {response.status_code}")
        response.raise_for_status()
        version = response.text.strip()
        
        log_msg(f"Fetched version from server: '{version}'")
        return version if version else None
        
    except requests.exceptions.ProxyError as e:
        error_detail = str(e)
        error_str_lower = error_detail.lower()
        log_msg(f"✗ ProxyError: {error_detail}")
        
        # Check if it's 407 Proxy Authentication Required
        is_407_auth_error = ('407' in error_str_lower or 
                           'authentication' in error_str_lower or 
                           'proxy authentication required' in error_str_lower)
        
        # Log proxy URL format for debugging (without password)
        if proxies:
            safe_proxies = {}
            for k, v in proxies.items():
                if '@' in v:
                    parts = v.split('@')
                    if len(parts) == 2:
                        auth_part = parts[0]
                        if '://' in auth_part:
                            scheme = auth_part.split('://')[0]
                            auth_rest = auth_part.split('://')[1]
                            if ':' in auth_rest:
                                user_part = auth_rest.split(':')[0]
                                server_part = parts[1]
                                safe_proxies[k] = f"{scheme}://{user_part}:***@{server_part}"
                            else:
                                safe_proxies[k] = v
                        elif ':' in auth_part:
                            user_part = auth_part.split(':')[0]
                            safe_proxies[k] = f"{user_part}:***@{parts[1]}"
                        else:
                            safe_proxies[k] = v
                    else:
                        safe_proxies[k] = v
                else:
                    safe_proxies[k] = v
            log_msg(f"Proxy URLs used: {safe_proxies}")
        
        # Return special value to indicate 407 auth error
        if is_407_auth_error:
            # Return a tuple to indicate auth error (will be handled by caller)
            return ("NEEDS_AUTH", proxy_config)
        
        return None
    except requests.exceptions.Timeout as e:
        error_detail = f"Timeout khi kết nối đến server (>{UPDATE_CHECK_TIMEOUT}s): {str(e)}"
        log_msg(f"✗ {error_detail}")
        return None
    except requests.exceptions.ConnectionError as e:
        error_detail = str(e)
        # Check if it's SSL certificate error
        if 'CERTIFICATE_VERIFY_FAILED' in error_detail or 'SSL' in error_detail:
            log_msg(f"✗ SSL Certificate Error: {error_detail}")
            log_msg("Proxy đang sử dụng self-signed certificate")
            log_msg("Đang thử lại với SSL verification disabled...")
            
            # Retry with SSL verification disabled
            try:
                version_check_url = get_version_check_url()
                response = requests.get(
                    version_check_url, 
                    timeout=UPDATE_CHECK_TIMEOUT,
                    proxies=proxies,
                    verify=False
                )
                log_msg(f"Response status (retry): {response.status_code}")
                response.raise_for_status()
                version = response.text.strip()
                log_msg(f"Fetched version from server (retry): '{version}'")
                return version if version else None
            except Exception as retry_e:
                log_msg(f"✗ Retry failed: {str(retry_e)}")
                return None
        else:
            log_msg(f"✗ ConnectionError: {error_detail}")
            if proxy_config:
                log_msg("Kiểm tra: Proxy có yêu cầu authentication không?")
        return None
    except requests.exceptions.RequestException as e:
        error_detail = f"RequestException: {str(e)}"
        log_msg(f"✗ {error_detail}")
        return None
    except Exception as e:
        error_detail = f"Unexpected error: {type(e).__name__}: {str(e)}"
        log_msg(f"✗ {error_detail}")
        if not getattr(sys, 'frozen', False):
            import traceback
            traceback.print_exc()
        return None


def get_update_link(proxy_config: Optional[Dict[str, str]] = None, log_callback=None, auto_load_proxy: bool = True) -> Optional[str]:
    """
    Get update link from server
    
    Args:
        proxy_config: Optional proxy configuration dictionary (may include username/password).
                     If None and auto_load_proxy=True, will try to get proxy config automatically.
                     If None and auto_load_proxy=False, will not use proxy.
        log_callback: Optional callback function to log messages (for GUI logging)
        auto_load_proxy: If True and proxy_config is None, will auto-load proxy config.
                        If False, will not use proxy if proxy_config is None.
        
    Returns:
        Optional[str]: Update link string, or None if error
    """
    def log_msg(msg: str):
        """Log message to both console and callback"""
        if not getattr(sys, 'frozen', False):
            print(f"[Update Check] {msg}")
        if log_callback:
            log_callback(f"[Update Check] {msg}")
    
    if not REQUESTS_AVAILABLE:
        log_msg("requests module not available")
        return None
    
    # Get proxy config if not provided and auto_load_proxy is True
    if proxy_config is None and auto_load_proxy:
        proxy_config = get_proxy_config()
    
    # Build proxy URLs with authentication
    proxies = None
    if proxy_config:
        proxies = build_proxy_url(proxy_config)
        safe_proxies = {}
        for k, v in proxies.items():
            if '@' in v:
                parts = v.split('@')
                if len(parts) == 2:
                    auth_part = parts[0]
                    if '://' in auth_part:
                        scheme = auth_part.split('://')[0]
                        auth_rest = auth_part.split('://')[1]
                        if ':' in auth_rest:
                            user_part = auth_rest.split(':')[0]
                            server_part = parts[1]
                            safe_proxies[k] = f"{scheme}://{user_part}:***@{server_part}"
                        else:
                            safe_proxies[k] = v
                    elif ':' in auth_part:
                        user_part = auth_part.split(':')[0]
                        safe_proxies[k] = f"{user_part}:***@{parts[1]}"
                    else:
                        safe_proxies[k] = v
                else:
                    safe_proxies[k] = v
            else:
                safe_proxies[k] = v
        log_msg(f"Using proxy URLs for update link: {safe_proxies}")
    
    try:
        update_link_url = get_update_link_url()
        if not update_link_url:
            # Show which key was being looked for
            key_name = "UPDATE_LINK_PRODUCTION" if getattr(sys, 'frozen', False) else "UPDATE_LINK_DEVELOPMENT"
            log_msg(f"✗ {key_name} not found in .env file")
            return None
        
        log_msg(f"Fetching update link from: {update_link_url}")
        # Disable SSL verification when using proxy (many corporate proxies use self-signed certs)
        # Always disable SSL verify when using proxy to avoid certificate issues
        verify_ssl = False if proxies else True
        
        if proxies:
            log_msg("SSL verification disabled (proxy may use self-signed certificate)")
        
        response = requests.get(
            update_link_url, 
            timeout=UPDATE_CHECK_TIMEOUT,
            proxies=proxies,
            verify=verify_ssl
        )
        log_msg(f"Response status: {response.status_code}")
        response.raise_for_status()
        link = response.text.strip()
        log_msg(f"Fetched update link: {link}")
        return link if link else None
    except requests.exceptions.ConnectionError as e:
        error_detail = str(e)
        # Check if it's SSL certificate error
        if 'CERTIFICATE_VERIFY_FAILED' in error_detail or 'SSL' in error_detail:
            log_msg(f"✗ SSL Certificate Error: {error_detail}")
            log_msg("Đang thử lại với SSL verification disabled...")
            try:
                response = requests.get(
                    update_link_url, 
                    timeout=UPDATE_CHECK_TIMEOUT,
                    proxies=proxies,
                    verify=False
                )
                log_msg(f"Response status (retry): {response.status_code}")
                response.raise_for_status()
                link = response.text.strip()
                log_msg(f"Fetched update link (retry): {link}")
                return link if link else None
            except Exception as retry_e:
                log_msg(f"✗ Retry failed: {str(retry_e)}")
                return None
        else:
            error_detail = f"Error fetching update link: {type(e).__name__}: {str(e)}"
            log_msg(f"✗ {error_detail}")
            return None
    except Exception as e:
        error_detail = f"Error fetching update link: {type(e).__name__}: {str(e)}"
        log_msg(f"✗ {error_detail}")
        return None


def check_for_update(proxy_config: Optional[Dict[str, str]] = None, log_callback=None, auto_load_proxy: bool = True) -> Optional[dict]:
    """
    Check if there's an update available
    
    Args:
        proxy_config: Optional proxy configuration dictionary.
                     If None and auto_load_proxy=True, will try to get proxy config automatically.
                     If None and auto_load_proxy=False, will not use proxy.
        log_callback: Optional callback function to log messages (for GUI logging)
        auto_load_proxy: If True and proxy_config is None, will auto-load proxy config.
                        If False, will not use proxy if proxy_config is None.
        
    Returns:
        Optional[dict]: Dictionary with 'latest_version' and 'update_link' if update available,
                       None if no update or error
    """
    def log_msg(msg: str):
        """Log message to both console and callback"""
        if not getattr(sys, 'frozen', False):
            print(f"[Update Check] {msg}")
        if log_callback:
            log_callback(f"[Update Check] {msg}")
    
    try:
        log_msg(f"Current version: {CURRENT_VERSION}")
        
        # Get proxy config if not provided and auto_load_proxy is True
        if proxy_config is None and auto_load_proxy:
            proxy_config = get_proxy_config()
        
        # Log current version and proxy info
        if proxy_config:
            safe_config = {k: v for k, v in proxy_config.items() if k != 'password'}
            log_msg(f"Using proxy config: {safe_config}")
        else:
            log_msg("No proxy configured")
        
        latest_version = get_latest_version(proxy_config, log_callback, auto_load_proxy=auto_load_proxy)
        if not latest_version:
            log_msg("Could not get latest version from server")
            return None
        
        log_msg(f"Current: {CURRENT_VERSION}, Latest: {latest_version}")
        
        is_newer = compare_versions(CURRENT_VERSION, latest_version)
        
        log_msg(f"Compare result: {is_newer} (Latest > Current: {is_newer})")
        
        if is_newer:
            # Get update link
            update_link_url = get_update_link_url()
            log_msg(f"Fetching update link from: {update_link_url}")
            
            update_link = get_update_link(proxy_config, log_callback, auto_load_proxy=auto_load_proxy)
            if not update_link:
                # Fallback to default network path
                update_link = r"\\172.25.191.52\ShareFile\Dp-it\05. Public Soft DP\22.OfficeTranslator\2. Publish"
                log_msg(f"Using fallback update link: {update_link}")
            
            log_msg(f"Update available! Latest: {latest_version}, Link: {update_link}")
            
            return {
                'latest_version': latest_version,
                'update_link': update_link
            }
        else:
            log_msg(f"No update available (current: {CURRENT_VERSION}, latest: {latest_version})")
            return None
    except Exception as e:
        error_detail = f"Error: {type(e).__name__}: {str(e)}"
        log_msg(f"✗ {error_detail}")
        if not getattr(sys, 'frozen', False):
            import traceback
            traceback.print_exc()
        return None


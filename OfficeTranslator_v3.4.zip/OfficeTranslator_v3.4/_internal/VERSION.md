# Lịch Sử Phiên Bản

Các cập nhật và cải tiến quan trọng của ứng dụng.

---

## Phiên Bản 3.4 - 01/12/2025

### ✨ Tính Năng Mới
- **Bỏ Qua Ngôn Ngữ Khi Dịch**: Thêm chức năng chọn ngôn ngữ cần giữ nguyên
  - Cho phép chọn một hoặc nhiều ngôn ngữ cần bỏ qua khi dịch
  - Văn bản ở các ngôn ngữ đã chọn sẽ không được dịch, giữ nguyên bản gốc
  - Hữu ích cho file đa ngôn ngữ (ví dụ: file có cả tiếng Anh và tiếng Nhật, chỉ muốn dịch tiếng Nhật)
  - Tự động phát hiện ngôn ngữ của từng đoạn văn bản
  - Hỗ trợ cho tất cả định dạng: Excel, Word, PowerPoint
- **Tự Động Phát Hiện Tốc Độ Mạng**: Ứng dụng tự động phát hiện tốc độ mạng và điều chỉnh timeout
  - Tự động test kết nối đến API endpoint khi khởi động
  - Phân loại tốc độ mạng: fast, normal, slow, very_slow (VPN)
  - Tự động đặt timeout phù hợp: 3 phút (fast), 5 phút (normal), 10 phút (slow), 15 phút (very_slow)
  - Thông tin được ghi vào log file để debug
- **Cải Thiện Menu Bar**: Tách menu Language ra menu riêng và thêm tính năng kiểm tra cập nhật
  - Menu Language nằm riêng, bên phải menu Help
  - Thêm menu item "Kiểm tra cập nhật" vào menu Help
  - Giao diện gọn gàng và dễ sử dụng hơn

### ⚡ Cải Tiến
- **Xử Lý Timeout Tốt Hơn**: Cải thiện xử lý timeout cho VPN và mạng chậm
  - Thêm timeout cho API calls (mặc định 5 phút, tự động điều chỉnh)
  - Retry với delay dài hơn cho timeout errors
  - Log chi tiết khi timeout xảy ra kèm network status hiện tại
  - Hướng dẫn người dùng tăng timeout nếu cần

### 🔧 Refactoring
- **Tách Logic Network**: Tách logic network detection và timeout ra file riêng
  - Tạo file `network_utils.py` chứa logic network detection
  - Code gọn hơn, dễ bảo trì hơn
  - Có thể tái sử dụng ở các module khác

---

## Phiên Bản 3.3 - 21/11/2025

### 🐛 Sửa Lỗi
- **Phát Hiện Text Trong Excel**: Sửa lỗi bỏ sót text trong file Excel
  - Cải thiện logic quét text để không bỏ sót dữ liệu ở các cột như K, L, M và các cột khác
  - Tăng ngưỡng kiểm tra từ 50 lên 100 cột để đảm bảo phát hiện đầy đủ
  - Với file có <= 100 cột: Kiểm tra tất cả các cột
  - Với file có > 100 cột: Sử dụng strategic sampling với nhiều điểm kiểm tra hơn
  - Cải thiện fallback method để xử lý các trường hợp đặc biệt

### ⚡ Cải Tiến
- **Hiệu Suất Xử Lý Excel**: Tối ưu quá trình quét và phát hiện text
  - Loại bỏ duplicate columns trong danh sách kiểm tra
  - Sắp xếp danh sách cột để tối ưu quá trình quét
  - Đảm bảo không bỏ sót dữ liệu ở bất kỳ cột nào

---

## Phiên Bản 3.2 - 20/11/2025

### ✨ Tính Năng Mới
- **Ngôn Ngữ Dịch Mới**: Thêm hỗ trợ ngôn ngữ dịch mới
  - Tiếng Pháp (fr)
  - Tiếng Đức (de)
  - Tiếng Nga (ru)
- **Dịch Đa Ngôn Ngữ**: Thêm hỗ trợ dịch đa ngôn ngữ
  - Có thể chọn nhiều ngôn ngữ dịch cùng lúc
  - Hiển thị danh sách ngôn ngữ đã chọn
  - Lưu danh sách ngôn ngữ đã chọn để sử dụng lại
- **Tự Động Cập Nhật Phiên Bản**: Hệ thống tự động cập nhật hoàn toàn mới
  - Tự động tải, giải nén và cài đặt phiên bản mới
  - Hiển thị tiến trình cập nhật (Downloading → Extracting → Preparing)
  - Tự động khởi động lại ứng dụng sau khi cập nhật
  - Bảo vệ dữ liệu: Các thư mục input, output, log được giữ nguyên hoàn toàn
  - Hỗ trợ proxy với xác thực cho quá trình tải cập nhật
  - Tương thích Windows 10 và Windows 11
- **Cải Thiện Chất Lượng Dịch Thuật**: Nâng cấp hệ thống prompt chuyên ngành
  - Bổ sung hàng trăm thuật ngữ chuyên ngành cho 7 lĩnh vực chính
  - Chuẩn hóa format và cấu trúc cho tất cả các prompt files
  - Cải thiện độ chính xác và nhất quán trong dịch thuật theo từng chuyên ngành
  - Hỗ trợ tốt hơn cho các tài liệu kỹ thuật, kế toán, nhân sự, IT, chất lượng, sản xuất, mua hàng, bảo trì

### 🔄 Thay Đổi
- **Long Paths Support**: Cải thiện hỗ trợ long paths trên Windows 10 và Windows 11
  - Tự động bật hoặc dùng workarounds (extended paths, short paths)
  - Tương thích Windows 10 và Windows 11
- **Lưu Trữ Cài Đặt**: Cài đặt và proxy settings được lưu trong AppData để không bị mất khi update
- **Kiểm Tra Proxy**: Tự động kiểm tra proxy server online/offline trước khi sử dụng
- **Dialog Cập Nhật**: Thêm button "Cập nhật thủ công" để mở link cập nhật cho user tự update
  - Tự động mở URL trong trình duyệt hoặc mở thư mục mạng trong Windows Explorer
  - Hỗ trợ cả URL (http/https) và network path (\\server\share)
- **Prompt Files**: Cập nhật và mở rộng các prompt files với hàng trăm thuật ngữ mới

### 🛡️ Bảo Vệ Dữ Liệu
- Các thư mục input, output, log được tự động bảo vệ khi cập nhật
- File cài đặt và danh sách file được giữ nguyên
- Settings được migrate tự động từ thư mục cũ sang AppData

---

## Phiên Bản 3.1 - 15/11/2025

### ✨ Tính Năng Mới
- **Chọn File Riêng Lẻ**: Thêm tùy chọn chọn file riêng lẻ thay vì chỉ chọn thư mục
  - Có thể chọn nhiều file cùng lúc để dịch
  - Hiển thị danh sách file đã chọn
  - Lưu danh sách file đã chọn để sử dụng lại
- **Xem Lịch Sử Phiên Bản**: Thêm nút "Phiên bản" để xem các cập nhật của ứng dụng
- **Tự Động Kiểm Tra Phiên Bản Mới**: Ứng dụng tự động kiểm tra phiên bản mới khi khởi động
  - Hiển thị thông báo nếu có phiên bản mới với link tải về
  - Kiểm tra ngầm trong background, không làm gián đoạn công việc
- **Hỗ Trợ Proxy với Xác Thực**: Tự động phát hiện và hỗ trợ proxy công ty
  - Tự động phát hiện proxy từ hệ thống Windows
  - Dialog nhập username/password proxy khi cần xác thực
  - Tự động xử lý SSL certificate cho proxy self-signed
  - Lưu thông tin proxy để sử dụng lại
- **Lưu Ý Về Hình Ảnh**: Thông báo rõ ràng về việc không hỗ trợ dịch văn bản trong hình ảnh

### 🔄 Thay Đổi
- **Dịch Lại File**: Giờ có thể dịch lại các file đã dịch trước đó (bỏ giới hạn bỏ qua file có "_TRANSLATED_")
- **Giao Diện**: Thêm radiobuttons để chuyển đổi giữa chế độ chọn thư mục và chọn file

---

## Phiên Bản 3.0 - 13/11/2025

### ✨ Tính Năng Mới
- **Lưu Cài Đặt Tự Động**: Ứng dụng tự động nhớ các cài đặt từ lần sử dụng trước (thư mục, ngôn ngữ dịch, ngôn ngữ giao diện)
- **Cảnh Báo Bảo Mật**: Thêm thông báo rõ ràng về bảo mật dữ liệu khi dịch

### 🔄 Thay Đổi
- **Giao Diện**: Tối ưu giao diện để hiển thị nhiều thông tin hơn

### ❌ Loại Bỏ
- **Liên Kết API Key**: Ẩn các liên kết không cần thiết khi chạy file thực thi

---

## Phiên Bản 2.0 - 05/2024

### ✨ Tính Năng Mới
- **Giao Diện Đồ Họa**: Thêm giao diện dễ sử dụng thay cho dòng lệnh
- **Hỗ Trợ Đa Định Dạng**: Thêm hỗ trợ Word và PowerPoint (trước đây chỉ có Excel)
- **Dịch Hàng Loạt**: Có thể dịch nhiều file cùng lúc
- **Theo Dõi Tiến Trình**: Hiển thị tiến trình dịch real-time

### 🔄 Cải Tiến
- Giữ nguyên định dạng file sau khi dịch
- Xử lý lỗi tốt hơn
- Trải nghiệm người dùng được cải thiện

---

## Phiên Bản 1.0 - 04/2024

### ✨ Phát Hành Đầu Tiên
- Hỗ trợ dịch file Excel
- Sử dụng Google Gemini API để dịch
- Giao diện dòng lệnh

---

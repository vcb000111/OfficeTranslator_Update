#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Network Utilities for Office Document Translator
------------------------------------------------
Provides network speed detection and timeout calculation functionality.
"""

import os
import time
import logging
from typing import Dict, Any, Optional, Callable

# Try to import requests for network speed detection
try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


def detect_network_speed(
    base_url: str, 
    test_timeout: float = 10.0,
    log_callback: Optional[Callable[[str, str], None]] = None
) -> Dict[str, Any]:
    """
    Detect network speed/latency by testing connection to API endpoint.
    
    Args:
        base_url: API base URL to test
        test_timeout: Maximum time to wait for test (seconds)
        log_callback: Optional callback function(level, message) for logging
                      level can be 'info', 'warning', 'error'
        
    Returns:
        Dict with keys: latency_ms, speed_category, recommended_timeout, test_successful
    """
    result = {
        "latency_ms": None,
        "speed_category": "unknown",
        "recommended_timeout": 300.0,  # Default 5 minutes
        "test_successful": False
    }
    
    if not HAS_REQUESTS:
        if log_callback:
            log_callback("warning", "requests library not available, cannot detect network speed")
        return result
    
    try:
        # Extract hostname from base_url
        # e.g., "https://generativelanguage.googleapis.com/v1beta/" -> "generativelanguage.googleapis.com"
        from urllib.parse import urlparse
        parsed = urlparse(base_url)
        hostname = parsed.hostname
        
        if not hostname:
            if log_callback:
                log_callback("warning", "Could not extract hostname from base_url for network test")
            return result
        
        # Test URL - use a simple endpoint or just the base URL
        test_url = f"{parsed.scheme}://{hostname}/"
        
        # Perform multiple tests and average the results
        latencies = []
        num_tests = 3  # Test 3 times for accuracy
        successful_tests = 0
        
        if log_callback:
            log_callback("info", "Testing network speed to API endpoint...")
        
        for i in range(num_tests):
            try:
                start_time = time.time()
                response = requests.get(
                    test_url,
                    timeout=test_timeout,
                    allow_redirects=True
                )
                elapsed = (time.time() - start_time) * 1000  # Convert to milliseconds
                latencies.append(elapsed)
                successful_tests += 1
                
                if i < num_tests - 1:  # Don't sleep after last test
                    time.sleep(0.5)  # Small delay between tests
                    
            except requests.exceptions.Timeout:
                msg = f"Network test {i+1}/{num_tests} timed out after {test_timeout}s"
                if log_callback:
                    log_callback("warning", msg)
                break
            except Exception as e:
                msg = f"Network test {i+1}/{num_tests} failed: {str(e)}"
                if log_callback:
                    log_callback("warning", msg)
                break
        
        if successful_tests > 0:
            avg_latency = sum(latencies) / len(latencies)
            result["latency_ms"] = avg_latency
            result["test_successful"] = True
            
            # Categorize network speed based on latency
            if avg_latency < 100:
                result["speed_category"] = "fast"
                result["recommended_timeout"] = 180.0  # 3 minutes for fast network
            elif avg_latency < 300:
                result["speed_category"] = "normal"
                result["recommended_timeout"] = 300.0  # 5 minutes for normal network
            elif avg_latency < 1000:
                result["speed_category"] = "slow"
                result["recommended_timeout"] = 600.0  # 10 minutes for slow network
            else:
                result["speed_category"] = "very_slow"
                result["recommended_timeout"] = 900.0  # 15 minutes for very slow network (VPN)
            
            # Log results
            speed_msg = f"Network speed detected: {result['speed_category']} (latency: {avg_latency:.0f}ms, recommended timeout: {result['recommended_timeout']:.0f}s)"
            if log_callback:
                log_callback("info", speed_msg)
        else:
            msg = "All network speed tests failed, using default timeout"
            if log_callback:
                log_callback("warning", msg)
            
    except Exception as e:
        msg = f"Error detecting network speed: {str(e)}"
        if log_callback:
            log_callback("warning", msg)
    
    return result


def calculate_optimal_timeout(
    base_url: str, 
    user_timeout: Optional[float] = None,
    log_callback: Optional[Callable[[str, str], None]] = None
) -> float:
    """
    Calculate optimal timeout based on network speed detection and user preference.
    
    Args:
        base_url: API base URL
        user_timeout: User-specified timeout (from environment variable), None to auto-detect
        log_callback: Optional callback function(level, message) for logging
                      level can be 'info', 'warning', 'error'
        
    Returns:
        float: Optimal timeout in seconds
    """
    # If user specified timeout, use it (but log that we're using it)
    if user_timeout is not None and user_timeout > 0:
        msg = f"Using user-specified timeout: {user_timeout}s (from API_TIMEOUT environment variable)"
        if log_callback:
            log_callback("info", msg)
        return user_timeout
    
    # Auto-detect network speed
    network_info = detect_network_speed(base_url, log_callback=log_callback)
    
    if network_info["test_successful"]:
        recommended = network_info["recommended_timeout"]
        latency = network_info["latency_ms"]
        category = network_info["speed_category"]
        
        msg = f"Auto-detected network: {category} (latency: {latency:.0f}ms) → Using timeout: {recommended}s"
        if log_callback:
            log_callback("info", msg)
        return recommended
    else:
        # Fallback to default if detection failed
        default_timeout = 300.0  # 5 minutes default
        msg = f"Network speed detection failed, using default timeout: {default_timeout}s"
        if log_callback:
            log_callback("info", msg)
        return default_timeout


def get_user_timeout_from_env() -> Optional[float]:
    """
    Get user-specified timeout from environment variable API_TIMEOUT.
    
    Returns:
        Optional[float]: Timeout in seconds if set, None otherwise
    """
    try:
        timeout_str = os.getenv("API_TIMEOUT", "")
        if timeout_str and timeout_str.strip():
            return float(timeout_str)
    except (ValueError, TypeError):
        pass
    return None

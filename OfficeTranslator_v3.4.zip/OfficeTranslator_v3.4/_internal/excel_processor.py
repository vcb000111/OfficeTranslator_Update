#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Excel File Processor
--------------------
Handles translation of Excel files (.xlsx, .xlsm, .xls)
"""

import os
import sys
import datetime
from typing import Optional, Callable, Any

# Import helper functions from translator
from translator import (
    print_info, print_success, print_warning, print_error,
    clean_text, should_translate, translate_batch, IS_DEBUGGING
)

# Import context holder for specialized translation
try:
    from context_holder import get_translation_context
except ImportError:
    def get_translation_context():
        return "general"

def _check_cell_text_for_translation(cell_text: str, skip_languages: Optional[list] = None) -> tuple:
    """
    Check if cell text should be translated, handling both multi-line and single-line cells with mixed languages.
    
    Args:
        cell_text: The cell text to check
        skip_languages: List of language codes to skip
        
    Returns:
        tuple: (lines_to_translate, lines_to_keep, cell_lines)
        - lines_to_translate: List of (line_idx, line_text) tuples for lines that need translation
        - lines_to_keep: List of (line_idx, line_text) tuples for lines that should be kept (skipped)
        - cell_lines: List of all lines in the cell
    """
    from translator import should_translate
    
    # Split cell text by newline first
    cell_lines = cell_text.split('\n')
    
    # Check each line separately
    lines_to_translate = []
    lines_to_keep = []
    
    for line_idx, line in enumerate(cell_lines):
        line_stripped = line.strip()
        if not line_stripped:
            # Empty line - keep as is
            lines_to_keep.append((line_idx, line))
            continue
        
        # If line has newline separator, check the whole line
        # If line doesn't have newline but might have mixed languages, try to split by common separators
        if '\n' in line:
            # Already split, check as is
            if should_translate(line_stripped, skip_languages):
                lines_to_translate.append((line_idx, line_stripped))
            else:
                lines_to_keep.append((line_idx, line))
        else:
            # Single line without newline - check if it might have mixed languages
            # Try to detect if text has mixed languages by checking segments
            has_translatable_segment = False
            has_skip_segment = False
            
            # Split by common separators (space, comma, period, semicolon, etc.) to check segments
            # But only if text is long enough and has multiple words
            if len(line_stripped) > 10 and (' ' in line_stripped or ',' in line_stripped or '。' in line_stripped or '.' in line_stripped):
                # Try splitting by spaces first (most common)
                segments = line_stripped.split()
                if len(segments) > 1:
                    # Check each segment
                    for seg in segments:
                        seg_stripped = seg.strip()
                        if not seg_stripped or len(seg_stripped) < 2:
                            continue
                        
                        if should_translate(seg_stripped, skip_languages):
                            has_translatable_segment = True
                        else:
                            has_skip_segment = True
                    
                    # If we found both types of segments, translate the whole line
                    # (because we can't accurately separate them in a single cell)
                    if has_translatable_segment:
                        lines_to_translate.append((line_idx, line_stripped))
                    elif has_skip_segment:
                        lines_to_keep.append((line_idx, line))
                    else:
                        # Couldn't determine - default to translate
                        lines_to_translate.append((line_idx, line_stripped))
                else:
                    # Single word or can't split - check whole line
                    if should_translate(line_stripped, skip_languages):
                        lines_to_translate.append((line_idx, line_stripped))
                    else:
                        lines_to_keep.append((line_idx, line))
            else:
                # Short text or no clear separators - check whole line
                if should_translate(line_stripped, skip_languages):
                    lines_to_translate.append((line_idx, line_stripped))
                else:
                    lines_to_keep.append((line_idx, line))
    
    return lines_to_translate, lines_to_keep, cell_lines


def process_excel_file(
    input_path: str, 
    target_lang: str = "ja", 
    api_client: Any = None,
    output_dir: Optional[str] = None,
    progress: Optional[Any] = None,
    log_callback: Optional[Callable[[str], None]] = None,
    skip_languages: Optional[list] = None,
    cancel_event: Optional[Any] = None
) -> Optional[str]:
    """
    Process Excel file: read, translate and save with original format.
    
    Args:
        input_path: Path to the Excel file
        target_lang: Target language code
        api_client: OpenAI client instance
        progress: Optional rich progress instance
        
    Returns:
        Optional[str]: Path to the translated file, or None if processing failed
    """
    try:
        # Import xlwings here to ensure it's loaded
        import xlwings as xw
        
        # Create output file path
        filename = os.path.basename(input_path)
        base_name, ext = os.path.splitext(filename)
        
        # Create timestamp for consistent naming
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

        # Use provided output_dir or create default
        if output_dir is None:
            # Create output directory at the same level as the script
            project_dir = os.path.dirname(os.path.abspath(__file__))
            output_dir = os.path.join(project_dir, "output")
        os.makedirs(output_dir, exist_ok=True)
        output_path = os.path.join(output_dir, f"{base_name}_TRANSLATED_{target_lang.upper()}_{timestamp}{ext}")

        print_info(f"Processing Excel file: {filename}")
        if log_callback:
            log_callback(f"📄 Processing file: {filename}")

        # Task IDs for progress tracking
        scan_task = None
        file_task = None
        
        if progress:
            file_task = progress.add_task(f"[cyan]Processing {filename}", total=1.0)
            scan_task = progress.add_task("[green]Scanning content", total=1.0)

        # Open workbook with xlwings to preserve formatting
        if log_callback:
            log_callback(f"🔓 Opening Excel file...")
        app = xw.App(visible=False)
        wb = None  # Initialize wb
        try:
            wb = app.books.open(input_path)
            
            if log_callback:
                log_callback(f"✅ File opened successfully")
            
            if progress:
                # Update progress: file opened
                progress.update(file_task, completed=0.2, description=f"[cyan]Processing {filename} - File opened")
                # Update scanning task: starting scan
                progress.update(scan_task, completed=0.1, description="[green]Scanning sheets")

            # Loop through each sheet
            sheet_count = len(wb.sheets)
            total_cells_to_translate = 0
            total_cells_translated = 0
            
            if log_callback:
                log_callback(f"📊 Found {sheet_count} sheet(s) in file")
            
            # First pass: count all elements to translate for better progress tracking
            sheet_translation_data = []
            
            for sheet_idx, sheet in enumerate(wb.sheets):
                # Check for cancellation
                if cancel_event and cancel_event.is_set():
                    print_info("Translation cancelled - closing workbook")
                    try:
                        wb.close()
                    except:
                        pass
                    return None
                if log_callback:
                    log_callback(f"🔍 Scanning sheet {sheet_idx+1}/{sheet_count}: '{sheet.name}'")
                
                if progress:
                    progress.update(scan_task, completed=0.1 + (0.4 * (sheet_idx / sheet_count)), 
                                    description=f"[green]Scanning sheet {sheet_idx+1}/{sheet_count}")
                
                # Collect data from cells that need translation
                texts_to_translate = []
                cell_references = []

                # Scan through used data range - optimized to skip empty cells
                try:
                    if log_callback:
                        log_callback(f"   📋 Scanning cells in sheet '{sheet.name}'...")
                    
                    # Use COM API to get actual used range dimensions (more efficient)
                    try:
                        used_range_api = sheet.api.UsedRange
                        if used_range_api is None:
                            print_info(f"Sheet '{sheet.name}' is empty or has no data.")
                            if log_callback:
                                log_callback(f"   ℹ️ Sheet '{sheet.name}' is empty or has no data")
                        else:
                            last_row = used_range_api.Rows.Count
                            last_col = used_range_api.Columns.Count
                            
                            # Ensure we scan at least a reasonable range even if UsedRange is small
                            # This handles cases where UsedRange might not detect all cells correctly
                            # Minimum: scan at least 100 rows x 50 columns, or the detected range (whichever is larger)
                            min_rows = max(last_row, 100)
                            min_cols = max(last_col, 50)
                            
                            # Limit to reasonable size (max 5,000 rows x 200 columns)
                            max_rows = min(min_rows, 5000)
                            max_cols = min(min_cols, 200)
                            
                            if log_callback:
                                log_callback(f"   📐 Range: {last_row} rows x {last_col} cols (expanded to: {max_rows} x {max_cols})")
                            
                            # Optimized scanning: use SpecialCells to find only cells with values
                            # This is much faster than iterating through all cells
                            cell_count = 0
                            cells_with_text = 0
                            
                            # Use row-by-row scanning with smart skipping of empty rows
                            # This is more reliable than SpecialCells which may not work in all cases
                            if log_callback:
                                log_callback(f"   🔄 Scanning row by row (skipping empty rows)...")
                            
                            for row in range(1, max_rows + 1):
                                # Quick check: skip rows that are likely empty
                                # Check across all columns in the range to ensure we don't miss text
                                # For small ranges (<= 100 cols), check all columns to ensure no data is missed
                                # For larger ranges, use strategic sampling with more check points
                                row_has_data = False
                                try:
                                    if max_cols <= 100:
                                        # Small to medium range: check all columns to ensure accuracy
                                        # This prevents missing data in any column (including column K and beyond)
                                        for check_col in range(1, max_cols + 1):
                                            cell_val = sheet.api.Cells(row, check_col).Value
                                            if cell_val is not None and str(cell_val).strip():
                                                row_has_data = True
                                                break
                                    else:
                                        # Large range: use strategic sampling with multiple check points
                                        # Check first 30 columns (to include column K and beyond), 
                                        # then sample every 20 columns, middle columns, and last 20
                                        check_cols = list(range(1, min(31, max_cols + 1)))  # First 30 columns
                                        
                                        # Sample every 20 columns to cover gaps (30, 50, 70, 90, etc.)
                                        sample_interval = 20
                                        for sample_col in range(30, max_cols + 1, sample_interval):
                                            if sample_col not in check_cols:
                                                check_cols.append(sample_col)
                                        
                                        # Add middle columns
                                        if max_cols > 60:
                                            mid_start = max_cols // 2 - 10
                                            mid_end = max_cols // 2 + 10
                                            check_cols.extend(range(mid_start, min(mid_end + 1, max_cols + 1)))
                                        
                                        # Add last 20 columns
                                        check_cols.extend(range(max(1, max_cols - 19), max_cols + 1))
                                        
                                        # Remove duplicates and sort for efficiency
                                        check_cols = sorted(set(check_cols))
                                        
                                        for check_col in check_cols:
                                            if check_col > max_cols:
                                                continue
                                            cell_val = sheet.api.Cells(row, check_col).Value
                                            if cell_val is not None and str(cell_val).strip():
                                                row_has_data = True
                                                break
                                except:
                                    row_has_data = True  # If error, assume has data to be safe
                                
                                if not row_has_data:
                                    # Skip this row entirely - it's likely empty
                                    continue
                                
                                # Row has data, scan all columns in this row
                                for col in range(1, max_cols + 1):
                                    cell_count += 1
                                    
                                    # Log progress every 5000 cells (only in debug mode)
                                    if IS_DEBUGGING and cell_count % 5000 == 0:
                                        if log_callback:
                                            log_callback(f"   ⏳ Scanned {cell_count:,} cells... (found {cells_with_text} cells to translate)")
                                    
                                    try:
                                        cell_val = sheet.api.Cells(row, col).Value
                                        
                                        # Skip None values
                                        if cell_val is None:
                                            continue
                                        
                                        cell_value_str = str(cell_val).strip()
                                        
                                        # Skip empty strings
                                        if not cell_value_str:
                                            continue
                                        
                                        # Skip pure numbers (but keep numbers with text like "Item 1")
                                        # Only skip if it's ONLY a number with no other characters
                                        is_pure_number = False
                                        try:
                                            # Try to convert to float, but only if it's ONLY digits, dots, commas, %, etc.
                                            test_str = cell_value_str.replace(',', '').replace('%', '').replace(' ', '')
                                            float(test_str)
                                            # If it's a pure number, check if original has any non-numeric chars
                                            if not any(c.isalpha() for c in cell_value_str):
                                                is_pure_number = True
                                        except (ValueError, AttributeError):
                                            pass
                                        
                                        if is_pure_number:
                                            continue
                                        
                                        # Check if should translate - handle multi-line and single-line cells with mixed languages
                                        lines_to_translate, lines_to_keep, cell_lines = _check_cell_text_for_translation(
                                            cell_value_str, skip_languages
                                        )
                                        
                                        # If there are lines to translate, add cell to translation list
                                        if lines_to_translate:
                                            # Store cell reference with line information
                                            # Format: (cell_ref, lines_to_translate, lines_to_keep, cell_lines)
                                            cell_ref = sheet.range((row, col))
                                            
                                            # Only translate the lines that need translation (join them for batch translation)
                                            lines_text_to_translate = '\n'.join([line for _, line in lines_to_translate])
                                            texts_to_translate.append(lines_text_to_translate)
                                            cell_references.append((cell_ref, lines_to_translate, lines_to_keep, cell_lines))
                                            cells_with_text += 1
                                            
                                    except Exception as cell_err:
                                        # Skip cells that cause errors
                                        continue
                            
                            if log_callback:
                                log_callback(f"   ✅ Completed scanning sheet '{sheet.name}': {cells_with_text} cells to translate (scanned {cell_count:,} cells)")
                    except Exception as api_err:
                        # Fallback to xlwings used_range but with limits
                        if log_callback:
                            log_callback(f"   ⚠️ COM API error, using fallback method")
                        used_rng = sheet.used_range
                        if used_rng and (used_rng.count > 1 or used_rng.value is not None):
                            max_cells = 50000  # Lower limit
                            cell_count = 0
                            cells_with_text = 0
                            for cell in used_rng:
                                cell_count += 1
                                if cell_count > max_cells:
                                    break
                                if cell_count % 5000 == 0:
                                    if log_callback:
                                        log_callback(f"   ⏳ Scanned {cell_count:,} cells... (found {cells_with_text} cells to translate)")
                                try:
                                    cell_value_str = str(cell.value) if cell.value is not None else ""
                                    if not cell_value_str:
                                        continue
                                    
                                    # Handle multi-line and single-line cells with mixed languages (same logic as main scanning)
                                    lines_to_translate, lines_to_keep, cell_lines = _check_cell_text_for_translation(
                                        cell_value_str, skip_languages
                                    )
                                    
                                    if lines_to_translate:
                                        lines_text_to_translate = '\n'.join([line for _, line in lines_to_translate])
                                        texts_to_translate.append(clean_text(lines_text_to_translate))
                                        cell_references.append((cell, lines_to_translate, lines_to_keep, cell_lines))
                                        cells_with_text += 1
                                except:
                                    continue
                            if log_callback:
                                log_callback(f"   ✅ Completed scanning sheet '{sheet.name}': {cells_with_text} cells to translate (scanned {cell_count:,} cells)")
                        else:
                            print_info(f"Sheet '{sheet.name}' is empty or has no data.")
                            if log_callback:
                                log_callback(f"   ℹ️ Sheet '{sheet.name}' is empty or has no data")
                except Exception as range_err:
                    print_warning(f"Error accessing used_range for sheet '{sheet.name}': {range_err}")
                    # Try alternative method: scan with expanded range to avoid missing data
                    # Use same limits as main method: 5000 rows x 200 columns
                    # Don't try to access UsedRange again since it already failed
                    try:
                        # Use safe default range (same as main method minimums)
                        alt_max_rows = 5001  # 5000 rows max
                        alt_max_cols = 201   # 200 columns max
                        
                        if log_callback:
                            log_callback(f"   ⚠️ Using fallback method: scanning {alt_max_rows-1} rows x {alt_max_cols-1} cols")
                        
                        for row in range(1, alt_max_rows):
                            for col in range(1, alt_max_cols):
                                try:
                                    cell = sheet.api.Cells(row, col)
                                    if cell.Value is not None:
                                        cell_value_str = str(cell.Value).strip()
                                        if not cell_value_str:
                                            continue
                                        
                                        # Handle multi-line and single-line cells with mixed languages (same logic as main scanning)
                                        lines_to_translate, lines_to_keep, cell_lines = _check_cell_text_for_translation(
                                            cell_value_str, skip_languages
                                        )
                                        
                                        if lines_to_translate:
                                            lines_text_to_translate = '\n'.join([line for _, line in lines_to_translate])
                                            texts_to_translate.append(clean_text(lines_text_to_translate))
                                            cell_ref = sheet.range((row, col))
                                            cell_references.append((cell_ref, lines_to_translate, lines_to_keep, cell_lines))
                                except:
                                    continue
                    except Exception as alt_err:
                        print_warning(f"Alternative scanning method also failed for sheet '{sheet.name}': {alt_err}")

                # Process shapes with text
                try:
                    if log_callback:
                        log_callback(f"   🔍 Checking shapes in sheet '{sheet.name}'...")
                    shapes_collection = sheet.api.Shapes
                    shapes_count = shapes_collection.Count

                    if shapes_count > 0:
                        print_info(f"Sheet '{sheet.name}' has {shapes_count} shapes to check")
                        if log_callback:
                            log_callback(f"   📐 Found {shapes_count} shape(s) in sheet '{sheet.name}'")

                        # Process each shape by index (Excel COM API indexes from 1)
                        for i in range(1, shapes_count + 1):
                            shape = None  # Initialize to avoid errors if .Item(i) fails
                            try:
                                shape = shapes_collection.Item(i)
                                shape_text = None

                                # --- Try multiple methods to get text from shape ---
                                
                                # Method 1: TextFrame
                                try:
                                    if hasattr(shape, 'TextFrame'):
                                        if shape.TextFrame.HasText:
                                            shape_text = shape.TextFrame.Characters().Text
                                except:
                                    pass
                                
                                # Method 2: TextFrame2
                                if not shape_text:
                                    try:
                                        if hasattr(shape, 'TextFrame2'):
                                            shape_text = shape.TextFrame2.TextRange.Text
                                    except:
                                        pass
                                
                                # Method 3: AlternativeText
                                if not shape_text:
                                    try:
                                        if hasattr(shape, 'AlternativeText') and shape.AlternativeText:
                                            shape_text = shape.AlternativeText
                                    except:
                                        pass
                                
                                # Method 4: OLEFormat (for OLE objects)
                                if not shape_text:
                                    try:
                                        if hasattr(shape, 'OLEFormat') and hasattr(shape.OLEFormat, 'Object'):
                                            if hasattr(shape.OLEFormat.Object, 'Text'):
                                                shape_text = shape.OLEFormat.Object.Text
                                    except:
                                        pass
                                
                                # Method 5: TextEffect (for WordArt)
                                if not shape_text:
                                    try:
                                        if hasattr(shape, 'TextEffect') and hasattr(shape.TextEffect, 'Text'):
                                            shape_text = shape.TextEffect.Text
                                    except:
                                        pass
                                
                                # If text is found, add to translation list
                                if shape_text and should_translate(shape_text, skip_languages):
                                    clean_shape_text = clean_text(shape_text)
                                    if IS_DEBUGGING:
                                        print_info(f"Shape {i}: Found text ({len(clean_shape_text)} chars)")
                                    texts_to_translate.append(clean_shape_text)
                                    
                                    # Save tuple with information for later updates
                                    cell_references.append(('shape', sheet, i))
                                
                                # Check if this is a group shape and process nested shapes
                                try:
                                    # In Excel COM API, group shapes have GroupItems property
                                    if hasattr(shape, 'GroupItems') and shape.GroupItems.Count > 0:
                                        if IS_DEBUGGING and log_callback:
                                            log_callback(f"   🔗 Found group shape {i} with {shape.GroupItems.Count} shapes inside")
                                        
                                        # Process each shape in the group
                                        for group_idx in range(1, shape.GroupItems.Count + 1):
                                            try:
                                                group_shape = shape.GroupItems.Item(group_idx)
                                                group_shape_text = None
                                                
                                                # Try to get text from group shape using same methods
                                                # Method 1: TextFrame
                                                try:
                                                    if hasattr(group_shape, 'TextFrame'):
                                                        if group_shape.TextFrame.HasText:
                                                            group_shape_text = group_shape.TextFrame.Characters().Text
                                                except:
                                                    pass
                                                
                                                # Method 2: TextFrame2
                                                if not group_shape_text:
                                                    try:
                                                        if hasattr(group_shape, 'TextFrame2'):
                                                            group_shape_text = group_shape.TextFrame2.TextRange.Text
                                                    except:
                                                        pass
                                                
                                                # Method 3: AlternativeText
                                                if not group_shape_text:
                                                    try:
                                                        if hasattr(group_shape, 'AlternativeText') and group_shape.AlternativeText:
                                                            group_shape_text = group_shape.AlternativeText
                                                    except:
                                                        pass
                                                
                                                # If text found in group shape, add to translation list
                                                if group_shape_text and group_shape_text.strip() and should_translate(group_shape_text, skip_languages):
                                                    clean_text_value = clean_text(group_shape_text)
                                                    texts_to_translate.append(clean_text_value)
                                                    # Store reference as ('group_shape', sheet object, parent shape index, group shape index)
                                                    cell_references.append(('group_shape', sheet, i, group_idx))
                                                    if IS_DEBUGGING:
                                                        preview = clean_text_value[:30] + "..." if len(clean_text_value) > 30 else clean_text_value
                                                        print_info(f"Found text in group shape {i}, nested shape {group_idx} on sheet '{sheet.name}': {preview} ({len(group_shape_text)} chars)")
                                                
                                                # Recursively check for nested groups
                                                if hasattr(group_shape, 'GroupItems') and group_shape.GroupItems.Count > 0:
                                                    # Process nested group (recursive)
                                                    for nested_idx in range(1, group_shape.GroupItems.Count + 1):
                                                        try:
                                                            nested_shape = group_shape.GroupItems.Item(nested_idx)
                                                            nested_text = None
                                                            
                                                            try:
                                                                if hasattr(nested_shape, 'TextFrame') and nested_shape.TextFrame.HasText:
                                                                    nested_text = nested_shape.TextFrame.Characters().Text
                                                            except:
                                                                pass
                                                            
                                                            if not nested_text:
                                                                try:
                                                                    if hasattr(nested_shape, 'TextFrame2'):
                                                                        nested_text = nested_shape.TextFrame2.TextRange.Text
                                                                except:
                                                                    pass
                                                            
                                                            if nested_text and nested_text.strip() and should_translate(nested_text, skip_languages):
                                                                clean_text_value = clean_text(nested_text)
                                                                texts_to_translate.append(clean_text_value)
                                                                # Store reference as ('nested_group_shape', sheet, parent shape index, group shape index, nested shape index)
                                                                cell_references.append(('nested_group_shape', sheet, i, group_idx, nested_idx))
                                                                if IS_DEBUGGING:
                                                                    preview = clean_text_value[:30] + "..." if len(clean_text_value) > 30 else clean_text_value
                                                                    print_info(f"Found text in nested group shape {i}/{group_idx}/{nested_idx} on sheet '{sheet.name}': {preview} ({len(nested_text)} chars)")
                                                        except:
                                                            continue
                                            except Exception as group_err:
                                                # Skip group shapes that cause errors
                                                continue
                                except Exception as group_check_err:
                                    # Not a group shape or error checking, continue
                                    pass

                            except Exception as outer_e:
                                # General error when processing shape
                                print_warning(f"Error processing shape {i}: {str(outer_e)}")
                                continue

                except Exception as e:
                    print_warning(f"Error processing shapes on sheet '{sheet.name}': {str(e)}")

                # Save the sheet data for translation phase
                sheet_translation_data.append((sheet, texts_to_translate, cell_references))
                total_cells_to_translate += len(texts_to_translate)
                
                if log_callback and len(texts_to_translate) > 0:
                    log_callback(f"   ✅ Sheet '{sheet.name}': {len(texts_to_translate)} items to translate")
            
            # Finish scanning phase
            if log_callback:
                log_callback(f"📊 Total: {total_cells_to_translate} items to translate in {sheet_count} sheet(s)")
            
            if progress:
                progress.update(scan_task, completed=1.0, description="[green]Scanning complete")
                
                # Create a new task for translation
                trans_task = progress.add_task("[yellow]Translating content", total=total_cells_to_translate)
                # Update file task
                progress.update(file_task, completed=0.4, description=f"[cyan]Processing {filename} - Translation in progress")
            
            # Skip if no text to translate
            if total_cells_to_translate == 0:
                print_success("No text to translate in the Excel file.")
                if log_callback:
                    log_callback("⚠️ No text found to translate in this file")
                
                if progress:
                    progress.update(file_task, completed=1.0, description=f"[cyan]Processing {filename} - No translation needed")
                
                # Save file with original format
                wb.save(output_path)
                print_success(f"File saved at: {output_path}")
                return output_path

            # Second pass: translate and update cell content
            batch_size = 50  # Smaller batch size for better progress tracking
            
            for sheet_idx, (sheet, texts_to_translate, cell_references) in enumerate(sheet_translation_data):
                # Check for cancellation before each sheet
                if cancel_event and cancel_event.is_set():
                    print_info("Translation cancelled - closing workbook")
                    try:
                        wb.close()
                    except:
                        pass
                    return None
                
                if not texts_to_translate:
                    continue  # Skip sheets with no text to translate
                    
                print_info(f"Processing sheet: {sheet.name}")
                
                # Split into batches for processing
                total_batches = (len(texts_to_translate) - 1) // batch_size + 1
                
                for i in range(0, len(texts_to_translate), batch_size):
                    # Check for cancellation before each batch
                    if cancel_event and cancel_event.is_set():
                        print_info("Translation cancelled - closing workbook")
                        try:
                            wb.close()
                        except:
                            pass
                        return None
                    
                    batch_texts = texts_to_translate[i:i+batch_size]
                    batch_refs = cell_references[i:i+batch_size]
                    current_batch_num = i // batch_size + 1

                    if IS_DEBUGGING:
                        print_info(f"Translating batch {current_batch_num}/{total_batches} ({len(batch_texts)} texts)")
                    
                    # Define a progress callback for translation
                    def update_translation_progress(current: int, total: int) -> None:
                        if progress:
                            progress.update(trans_task, 
                                           description=f"[yellow]Translating batch {current_batch_num}/{total_batches} (Attempt {current+1}/{total+1})")
                    
                    # Translate batch
                    translated_batch = translate_batch(
                        batch_texts, 
                        target_lang,
                        api_client, 
                        progress_callback=update_translation_progress,
                        log_callback=log_callback,
                        translation_context=get_translation_context()
                    )
                    
                    # Check for cancellation after batch translation
                    if cancel_event and cancel_event.is_set():
                        print_info("Translation cancelled - closing workbook")
                        try:
                            wb.close()
                        except:
                            pass
                        return None
                    
                    # Debug: Check if translation actually happened (only in debug mode)
                    if IS_DEBUGGING and translated_batch and len(translated_batch) > 0:
                        # Compare first few characters to detect if translation occurred
                        sample_original = batch_texts[0][:50] if batch_texts else ""
                        sample_translated = translated_batch[0][:50] if translated_batch[0] else ""
                        if sample_original and sample_translated and sample_original == sample_translated:
                            print_warning(f"⚠️ WARNING: Translation may have failed - first text unchanged: '{sample_original[:30]}...'")
                        else:
                            print_info(f"✅ Translation verified - text changed from '{sample_original[:30]}...' to '{sample_translated[:30]}...'")
                    
                    # Update translated content
                    if IS_DEBUGGING:
                        print_info(f"Updating content for batch {current_batch_num}...")
                    update_count = 0
                    skip_count = 0
                    
                    for j, ref in enumerate(batch_refs):
                        # Update progress
                        if progress:
                            total_cells_translated += 1
                            progress.update(trans_task, completed=total_cells_translated)
                            
                        # Check if index j is within translated_batch
                        if j < len(translated_batch) and translated_batch[j] is not None and translated_batch[j].strip():
                            try:
                                # Verify translation actually changed the text
                                original_text = batch_texts[j] if j < len(batch_texts) else ""
                                translated_text = translated_batch[j]
                                
                                # Skip if translation is same as original (translation may have failed)
                                if original_text and translated_text and original_text.strip() == translated_text.strip():
                                    skip_count += 1
                                    print_warning(f"⚠️ Skipping update for item {j}: translation unchanged (may indicate API failure)")
                                    continue
                                
                                # Update content for shape and cell
                                # Check if ref is a multi-line cell reference (new format)
                                if isinstance(ref, tuple) and len(ref) == 4 and isinstance(ref[0], object) and hasattr(ref[0], 'value'):
                                    # New format: (cell_ref, lines_to_translate, lines_to_keep, cell_lines)
                                    cell_ref, lines_to_translate, lines_to_keep, original_lines = ref
                                    
                                    try:
                                        # Split translated text by newline (API returns only the lines we translated, joined by newline)
                                        translated_lines = translated_text.split('\n')
                                        
                                        # Build final cell text by combining translated and skipped lines
                                        # Initialize with original lines to preserve structure
                                        final_lines = list(original_lines)
                                        
                                        # First, place lines that should be kept (skipped) - these are already in final_lines
                                        # No need to update them
                                        
                                        # Then, place translated lines at their original positions
                                        translated_line_idx = 0
                                        for line_idx, original_line in lines_to_translate:
                                            if line_idx < len(final_lines) and translated_line_idx < len(translated_lines):
                                                # Use translated line, preserving original if translation is empty
                                                translated_line = translated_lines[translated_line_idx].strip()
                                                if translated_line:
                                                    final_lines[line_idx] = translated_line
                                                else:
                                                    # If translation is empty, keep original
                                                    final_lines[line_idx] = original_line
                                                translated_line_idx += 1
                                        
                                        # Combine all lines back into cell text
                                        final_cell_text = '\n'.join(final_lines)
                                        
                                        # Update cell value
                                        cell_ref.value = final_cell_text
                                        update_count += 1
                                        
                                        if IS_DEBUGGING:
                                            print_success(f"✅ Updated multi-line cell: {len(lines_to_translate)} line(s) translated, {len(lines_to_keep)} line(s) kept")
                                        
                                    except Exception as multi_line_err:
                                        print_warning(f"Error updating multi-line cell: {str(multi_line_err)}")
                                        # Fallback: try to update as single cell
                                        try:
                                            cell_ref.value = translated_text
                                            update_count += 1
                                        except:
                                            skip_count += 1
                                
                                elif isinstance(ref, tuple) and ref[0] == 'shape':
                                    # Process shape: ref is ('shape', sheet_obj, shape_index)
                                    _, sheet_obj, shape_index = ref  # Unpack tuple
                                    try:
                                        # Get shape object again
                                        shape_to_update = sheet_obj.api.Shapes.Item(shape_index)
                                        updated = False
                                        
                                        # Try multiple methods to update text for shape
                                        
                                        # Method 1: TextFrame
                                        try:
                                            if hasattr(shape_to_update, 'TextFrame') and shape_to_update.TextFrame.HasText:
                                                shape_to_update.TextFrame.Characters().Text = translated_batch[j]
                                                updated = True
                                        except:
                                            pass
                                            
                                        # Method 2: TextFrame2
                                        if not updated:
                                            try:
                                                if hasattr(shape_to_update, 'TextFrame2'):
                                                    shape_to_update.TextFrame2.TextRange.Text = translated_batch[j]
                                                    updated = True
                                            except:
                                                pass
                                                
                                        # Method 3: AlternativeText
                                        if not updated:
                                            try:
                                                if hasattr(shape_to_update, 'AlternativeText'):
                                                    shape_to_update.AlternativeText = translated_batch[j]
                                                    updated = True
                                            except:
                                                pass
                                                
                                        # Method 4: TextEffect (for WordArt)
                                        if not updated:
                                            try:
                                                if hasattr(shape_to_update, 'TextEffect') and hasattr(shape_to_update.TextEffect, 'Text'):
                                                    shape_to_update.TextEffect.Text = translated_batch[j]
                                                    updated = True
                                            except:
                                                pass
                                                
                                        # Method 5: OLEFormat
                                        if not updated:
                                            try:
                                                if hasattr(shape_to_update, 'OLEFormat') and hasattr(shape_to_update.OLEFormat, 'Object'):
                                                    if hasattr(shape_to_update.OLEFormat.Object, 'Text'):
                                                        shape_to_update.OLEFormat.Object.Text = translated_batch[j]
                                                        updated = True
                                            except:
                                                pass
                                                
                                        if updated:
                                            if IS_DEBUGGING:
                                                print_success(f"Updated text for shape {shape_index} on sheet '{sheet_obj.name}'")
                                        else:
                                            if IS_DEBUGGING:
                                                print_warning(f"Could not update text for shape {shape_index} on sheet '{sheet_obj.name}'")
                                        
                                    except Exception as update_err:
                                        print_warning(f"Error updating shape {shape_index} on sheet '{sheet_obj.name}': {str(update_err)}")
                                
                                elif isinstance(ref, tuple) and ref[0] == 'group_shape':
                                    # Process group shape: ref is ('group_shape', sheet_obj, parent_shape_index, group_shape_index)
                                    _, sheet_obj, parent_shape_index, group_shape_index = ref
                                    try:
                                        parent_shape = sheet_obj.api.Shapes.Item(parent_shape_index)
                                        group_shape = parent_shape.GroupItems.Item(group_shape_index)
                                        updated = False
                                        
                                        # Try multiple methods to update text for group shape
                                        try:
                                            if hasattr(group_shape, 'TextFrame') and group_shape.TextFrame.HasText:
                                                group_shape.TextFrame.Characters().Text = translated_batch[j]
                                                updated = True
                                        except:
                                            pass
                                        
                                        if not updated:
                                            try:
                                                if hasattr(group_shape, 'TextFrame2'):
                                                    group_shape.TextFrame2.TextRange.Text = translated_batch[j]
                                                    updated = True
                                            except:
                                                pass
                                        
                                        if not updated:
                                            try:
                                                if hasattr(group_shape, 'AlternativeText'):
                                                    group_shape.AlternativeText = translated_batch[j]
                                                    updated = True
                                            except:
                                                pass
                                        
                                        if updated:
                                            if IS_DEBUGGING:
                                                print_success(f"✅ Updated text in group shape {parent_shape_index}/{group_shape_index} on sheet '{sheet_obj.name}'")
                                        else:
                                            if IS_DEBUGGING:
                                                print_warning(f"⚠️ Could not update text in group shape {parent_shape_index}/{group_shape_index}")
                                            
                                    except Exception as group_update_err:
                                        print_error(f"❌ Error updating group shape {parent_shape_index}/{group_shape_index}: {str(group_update_err)}")
                                        if log_callback:
                                            log_callback(f"❌ Error updating group shape {parent_shape_index}/{group_shape_index}: {str(group_update_err)}")
                                
                                elif isinstance(ref, tuple) and ref[0] == 'nested_group_shape':
                                    # Process nested group shape: ref is ('nested_group_shape', sheet_obj, parent_shape_index, group_shape_index, nested_shape_index)
                                    _, sheet_obj, parent_shape_index, group_shape_index, nested_shape_index = ref
                                    try:
                                        parent_shape = sheet_obj.api.Shapes.Item(parent_shape_index)
                                        group_shape = parent_shape.GroupItems.Item(group_shape_index)
                                        nested_shape = group_shape.GroupItems.Item(nested_shape_index)
                                        updated = False
                                        
                                        # Try multiple methods to update text for nested group shape
                                        try:
                                            if hasattr(nested_shape, 'TextFrame') and nested_shape.TextFrame.HasText:
                                                nested_shape.TextFrame.Characters().Text = translated_batch[j]
                                                updated = True
                                        except:
                                            pass
                                        
                                        if not updated:
                                            try:
                                                if hasattr(nested_shape, 'TextFrame2'):
                                                    nested_shape.TextFrame2.TextRange.Text = translated_batch[j]
                                                    updated = True
                                            except:
                                                pass
                                        
                                        if updated:
                                            if IS_DEBUGGING:
                                                print_success(f"✅ Updated text in nested group shape {parent_shape_index}/{group_shape_index}/{nested_shape_index} on sheet '{sheet_obj.name}'")
                                        else:
                                            if IS_DEBUGGING:
                                                print_warning(f"⚠️ Could not update text in nested group shape {parent_shape_index}/{group_shape_index}/{nested_shape_index}")
                                            
                                    except Exception as nested_update_err:
                                        print_error(f"❌ Error updating nested group shape {parent_shape_index}/{group_shape_index}/{nested_shape_index}: {str(nested_update_err)}")
                                        if log_callback:
                                            log_callback(f"❌ Error updating nested group shape {parent_shape_index}/{group_shape_index}/{nested_shape_index}: {str(nested_update_err)}")
                                
                                elif hasattr(ref, 'value'):  # Is a cell
                                    try:
                                        old_value = ref.value
                                        ref.value = translated_batch[j]
                                        update_count += 1
                                        if IS_DEBUGGING and log_callback:
                                            log_callback(f"✅ Updated cell {ref.address}: '{str(old_value)[:30]}...' → '{translated_batch[j][:30]}...'")
                                    except Exception as cell_err:
                                        print_error(f"❌ Failed to update cell {ref.address}: {str(cell_err)}")
                                        if log_callback:
                                            log_callback(f"❌ Failed to update cell {ref.address}: {str(cell_err)}")
                                else:
                                    print_warning(f"Unknown reference type: {type(ref)}")

                            except Exception as update_single_err:
                                # Catch general errors when updating a specific cell/shape
                                ref_info = f"Shape index {ref[2]} on sheet {ref[1].name}" if isinstance(ref, tuple) else f"Cell {ref.address}"
                                print_error(f"❌ Could not update content for {ref_info}: {str(update_single_err)}")
                                if log_callback:
                                    log_callback(f"❌ Update failed for {ref_info}: {str(update_single_err)}")
                                import traceback
                                print_error(f"Traceback: {traceback.format_exc()}")
                    
                    # Log update summary
                    if update_count > 0 or skip_count > 0:
                        print_info(f"📊 Batch {current_batch_num} summary: {update_count} updated, {skip_count} skipped (unchanged)")

            # Update file task
            if progress:
                progress.update(file_task, completed=0.8, description=f"[cyan]Processing {filename} - Saving file")
                progress.update(trans_task, completed=total_cells_to_translate, description="[yellow]Translation complete")

            # Save file with original format
            print_info(f"Saving translated file to: {output_path}")
            try:
                # Save the workbook
                wb.save(output_path)
                print_success(f"File saved successfully: {output_path}")
                
                # Close workbook before quitting app to ensure changes are saved
                wb.close()
                print_info("Workbook closed successfully")
            except Exception as save_err:
                print_error(f"Error saving/closing workbook: {str(save_err)}")
                # Try to close anyway
                try:
                    wb.close()
                except:
                    pass
                raise save_err
            
            if progress:
                progress.update(file_task, completed=1.0, description=f"[cyan]Processing {filename} - Complete")

            return output_path

        except Exception as wb_process_err:
            print_error(f"Error processing workbook '{filename}': {str(wb_process_err)}")
            # Ensure workbook is closed if error occurs before saving
            if wb is not None:
                try:
                    wb.close()
                except Exception as close_err:
                    print_warning(f"Error trying to close workbook after processing error: {close_err}")
            if progress and file_task:
                progress.update(file_task, completed=1.0, description=f"[red]Processing {filename} - Failed")
            return None
        finally:
            # Close workbook (if not already closed) and Excel app
            try:
                if 'wb' in locals() and wb is not None:
                    try:
                        if hasattr(wb, 'api') and hasattr(wb.api, 'Saved') and not wb.api.Saved:  # Check if workbook needs saving
                            try:
                                wb.save()
                            except:
                                pass
                    except:
                        pass
                    try:
                        wb.close()
                    except:
                        pass
            except:
                pass
            # Ensure app is closed
            try:
                if 'app' in locals() and app is not None:
                    if hasattr(app, 'pid') and app.pid:  # Check if app exists and is still running
                        app.quit()
                        print_info("Excel application closed.")
            except Exception as app_err:
                print_warning(f"Error closing Excel application: {str(app_err)}")

    except Exception as e:
        print_error(f"Critical error when processing Excel file '{input_path}': {str(e)}")
        if progress and file_task:
            progress.update(file_task, completed=1.0, description=f"[red]Processing {filename} - Failed")
        return None 


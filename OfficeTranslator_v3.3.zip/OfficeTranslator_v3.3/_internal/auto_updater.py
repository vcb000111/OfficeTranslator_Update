# -*- coding: utf-8 -*-
"""
Auto Updater Module
===================
Handles automatic update process:
1. Download new_version.zip from update link
2. Extract to temp directory
3. Create updater.bat to replace files after app closes
4. Run updater.bat and exit app
"""

import os
import sys
import shutil
import tempfile
import zipfile
import subprocess
import winreg
import ctypes
from pathlib import Path
from typing import Optional, Callable

# Import requests for downloading
try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

# Import proxy config from update_checker
try:
    from update_checker import get_proxy_config, build_proxy_url, check_proxy_server_status
    PROXY_AVAILABLE = True
except ImportError:
    PROXY_AVAILABLE = False
    def get_proxy_config():
        return None
    def build_proxy_url(proxy_config):
        return proxy_config if proxy_config else None
    def check_proxy_server_status(proxy_config, timeout=3):
        return "unknown"

def get_debug_win10_flag() -> bool:
    """
    Get IS_DEBUGGING_WIN_10 flag from environment variable or .env file.
    Allows testing workarounds on built exe without recompiling.
    
    Priority:
    1. Environment variable IS_DEBUGGING_WIN_10
    2. .env file (IS_DEBUGGING_WIN_10=true/false)
    3. Default: False
    
    Returns:
        bool: True if debug mode enabled, False otherwise
    """
    # First, check environment variable
    env_value = os.getenv("IS_DEBUGGING_WIN_10", "").strip().lower()
    if env_value in ("true", "1", "yes"):
        if not getattr(sys, 'frozen', False):
            print("[Auto Update] DEBUG MODE enabled via environment variable")
        return True
    elif env_value in ("false", "0", "no"):
        return False
    
    # Second, try to read from .env file
    try:
        from update_checker import load_env_variable
        env_file_value = load_env_variable("IS_DEBUGGING_WIN_10", "").strip().lower()
        if env_file_value in ("true", "1", "yes"):
            if not getattr(sys, 'frozen', False):
                print("[Auto Update] DEBUG MODE enabled via .env file")
            return True
        elif env_file_value in ("false", "0", "no"):
            return False
    except Exception:
        pass  # If can't load, use default
    
    # Default: False
    return False

# Debug flag to simulate Windows 10 long paths disabled (for testing workarounds)
# Can be set via environment variable or .env file
IS_DEBUGGING_WIN_10 = get_debug_win10_flag()


def is_admin() -> bool:
    """
    Check if the current process is running with administrator privileges.
    
    Returns:
        bool: True if running as admin, False otherwise
    """
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except Exception:
        return False


def is_long_paths_enabled() -> bool:
    """
    Check if long paths are enabled on Windows 10/11.
    
    Returns:
        bool: True if long paths are enabled, False otherwise
    """
    # Debug mode: simulate Windows 10 with long paths disabled
    if IS_DEBUGGING_WIN_10:
        if not getattr(sys, 'frozen', False):
            print("[Auto Update] DEBUG MODE: Simulating Windows 10 with long paths disabled")
        return False
    
    if sys.platform != "win32":
        return True  # Not Windows, assume supported
    
    try:
        # Check registry key for long paths
        key = winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SYSTEM\CurrentControlSet\Control\FileSystem",
            0,
            winreg.KEY_READ
        )
        try:
            value, _ = winreg.QueryValueEx(key, "LongPathsEnabled")
            return value == 1
        except FileNotFoundError:
            return False
        finally:
            winreg.CloseKey(key)
    except (OSError, PermissionError):
        # Can't read registry, assume not enabled or can't check
        return False


def enable_long_paths() -> bool:
    """
    Attempt to enable long paths on Windows 10/11.
    Requires administrator privileges.
    
    Returns:
        bool: True if successfully enabled, False otherwise
    """
    if sys.platform != "win32":
        return True  # Not Windows
    
    if not is_admin():
        return False  # Need admin rights
    
    try:
        # Open registry key with write access
        key = winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SYSTEM\CurrentControlSet\Control\FileSystem",
            0,
            winreg.KEY_WRITE
        )
        try:
            # Set LongPathsEnabled to 1
            winreg.SetValueEx(key, "LongPathsEnabled", 0, winreg.REG_DWORD, 1)
            return True
        finally:
            winreg.CloseKey(key)
    except (OSError, PermissionError) as e:
        if not getattr(sys, 'frozen', False):
            print(f"[Auto Update] Could not enable long paths: {str(e)}")
        return False


def get_short_path(path: str) -> str:
    """
    Get the short (8.3) path name for a given path.
    This is a workaround for long paths when long paths are not enabled.
    
    Args:
        path: Long path to convert
        
    Returns:
        str: Short path if available, original path otherwise
    """
    if sys.platform != "win32":
        return path
    
    try:
        # Use GetShortPathNameW Windows API
        kernel32 = ctypes.windll.kernel32
        buffer = ctypes.create_unicode_buffer(260)  # MAX_PATH
        length = kernel32.GetShortPathNameW(path, buffer, 260)
        if length > 0:
            return buffer.value
    except Exception:
        pass
    
    return path


def normalize_path_for_batch(path: str) -> str:
    """
    Normalize path for use in batch scripts.
    Removes extended path prefix (\\?\\) as batch scripts don't support it.
    
    Args:
        path: Path that may contain extended path prefix
        
    Returns:
        str: Normalized path without extended prefix
    """
    if not path:
        return path
    
    # Remove \\?\ prefix if present
    if path.startswith("\\\\?\\"):
        # Remove \\?\ prefix
        normalized = path[4:]
        # Handle UNC paths: \\?\UNC\server\share -> \\server\share
        if normalized.startswith("UNC\\"):
            normalized = "\\" + normalized[3:]
        return normalized
    
    return path


def ensure_long_path_support(path: str) -> str:
    """
    Ensure a path can be used even if long paths are not enabled.
    Uses workarounds like short paths or \\?\ prefix.
    
    Args:
        path: Path to ensure compatibility
        
    Returns:
        str: Compatible path
    """
    if sys.platform != "win32":
        return path
    
    # Check if path is already using \\?\ prefix
    if path.startswith("\\\\?\\"):
        return path
    
    # If long paths are enabled and not in debug mode, return as is
    if is_long_paths_enabled() and not IS_DEBUGGING_WIN_10:
        return path
    
    # Debug mode or long paths disabled: apply workarounds
    if IS_DEBUGGING_WIN_10 and not getattr(sys, 'frozen', False):
        print(f"[Auto Update] DEBUG MODE: Applying workarounds for path: {path[:80]}...")
    
    # Try to use \\?\ prefix for absolute paths (bypasses 260 char limit)
    # Note: This only works if the underlying filesystem supports it
    if os.path.isabs(path):
        # Convert to extended path format
        if path.startswith("\\\\"):
            # UNC path: \\?\UNC\server\share
            extended_path = "\\\\?\\UNC" + path[1:]
        else:
            # Local path: \\?\C:\path
            extended_path = "\\\\?\\" + path
        
        # Verify the extended path works
        try:
            if os.path.exists(path):
                # Test if we can access it
                os.path.getsize(extended_path)
                return extended_path
        except Exception:
            pass
    
    # Fallback: try short path
    short_path = get_short_path(path)
    if short_path != path and len(short_path) < 260:
        return short_path
    
    # Last resort: return original path (may fail if too long)
    return path


def check_and_enable_long_paths() -> bool:
    """
    Check if long paths are enabled, and attempt to enable if not.
    Logs appropriate messages.
    
    Returns:
        bool: True if long paths are enabled (or enabled successfully), False otherwise
    """
    if sys.platform != "win32":
        return True  # Not Windows
    
    # Debug mode: skip enabling and force workarounds
    if IS_DEBUGGING_WIN_10:
        if not getattr(sys, 'frozen', False):
            print("[Auto Update] DEBUG MODE: Skipping long paths enable, forcing workarounds")
        return False
    
    if is_long_paths_enabled():
        if not getattr(sys, 'frozen', False):
            print("[Auto Update] Long paths are already enabled")
        return True
    
    # Try to enable if we have admin rights
    if is_admin():
        if not getattr(sys, 'frozen', False):
            print("[Auto Update] Long paths not enabled. Attempting to enable (requires admin)...")
        if enable_long_paths():
            if not getattr(sys, 'frozen', False):
                print("[Auto Update] Long paths enabled successfully!")
            return True
        else:
            if not getattr(sys, 'frozen', False):
                print("[Auto Update] Failed to enable long paths")
    else:
        if not getattr(sys, 'frozen', False):
            print("[Auto Update] Long paths not enabled. Admin rights required to enable.")
            print("[Auto Update] Will use workarounds (short paths, extended paths) if needed.")
    
    return False


def get_app_directory() -> str:
    """
    Get the directory where the application is located.
    In dev mode, can be overridden by UPDATE_TARGET_DIR_DEV in .env.dev
    """
    if getattr(sys, 'frozen', False):
        # Running as compiled exe (production) - always use exe directory
        return os.path.dirname(sys.executable)
    else:
        # Running as script (development)
        # Check if UPDATE_TARGET_DIR_DEV is configured in .env.dev
        try:
            from update_checker import load_env_variable
            update_target_dir = load_env_variable("UPDATE_TARGET_DIR_DEV", "").strip()
            if update_target_dir:
                # Resolve path (absolute or relative)
                if os.path.isabs(update_target_dir):
                    target_path = update_target_dir
                else:
                    # Relative path - resolve relative to project root
                    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                    target_path = os.path.abspath(os.path.join(project_root, update_target_dir))
                
                # Create directory if it doesn't exist
                if not os.path.exists(target_path):
                    try:
                        os.makedirs(target_path, exist_ok=True)
                        if not getattr(sys, 'frozen', False):
                            print(f"[Auto Update] Created update target directory: {target_path}")
                    except Exception as e:
                        if not getattr(sys, 'frozen', False):
                            print(f"[Auto Update] Warning: Could not create target directory {target_path}: {str(e)}")
                        # Fall back to project root
                        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                
                # Use configured directory
                if not getattr(sys, 'frozen', False):
                    print(f"[Auto Update] Using configured update target directory: {target_path}")
                return target_path
        except Exception as e:
            if not getattr(sys, 'frozen', False):
                print(f"[Auto Update] Warning: Could not load UPDATE_TARGET_DIR_DEV: {str(e)}")
        
        # Default: use project root
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def download_update_zip(update_link: str, proxy_config: Optional[dict] = None, 
                      progress_callback: Optional[Callable[[int, int], None]] = None) -> Optional[str]:
    """
    Download new_version.zip from update link
    
    Args:
        update_link: URL or network path to update zip file
        proxy_config: Optional proxy configuration
        progress_callback: Optional callback function(loaded_bytes, total_bytes) for progress
        
    Returns:
        Optional[str]: Path to downloaded zip file, or None if error
    """
    if not REQUESTS_AVAILABLE:
        return None
    
    try:
        # Check if using local zip file in dev mode
        if not getattr(sys, 'frozen', False):
            try:
                from update_checker import load_env_variable
                use_local = load_env_variable("USE_LOCAL_UPDATE_DEV", "true").strip().lower()
                if use_local in ("true", "1", "yes"):
                    local_zip = load_env_variable("UPDATE_ZIP_SOURCE_DEV", "").strip()
                    if local_zip and os.path.exists(local_zip):
                        # Use local zip file instead of downloading
                        if not getattr(sys, 'frozen', False):
                            print(f"[Auto Update] Using local zip file: {local_zip}")
                        if progress_callback:
                            progress_callback(100, 100)  # Simulate 100% progress
                        return local_zip
                    elif local_zip:
                        if not getattr(sys, 'frozen', False):
                            print(f"[Auto Update] Warning: Local zip file not found: {local_zip}")
            except Exception as e:
                if not getattr(sys, 'frozen', False):
                    print(f"[Auto Update] Warning: Could not check local update config: {str(e)}")
        
        # Get temp directory
        temp_dir = tempfile.gettempdir()
        zip_path = os.path.join(temp_dir, "OfficeTranslator_update.zip")
        
        # If update_link is a network path, convert to file:// URL or use direct copy
        if update_link.startswith('\\\\'):
            # Network path - try to find zip file
            # First, try common names
            common_names = ["new_version.zip", "update.zip", "OfficeTranslator.zip", "OfficeTranslator_update.zip"]
            for name in common_names:
                network_zip = os.path.join(update_link, name)
                if os.path.exists(network_zip):
                    shutil.copy2(network_zip, zip_path)
                    return zip_path
            
            # If not found, try to find any zip file in network path
            try:
                for file in os.listdir(update_link):
                    if file.endswith('.zip'):
                        network_zip = os.path.join(update_link, file)
                        shutil.copy2(network_zip, zip_path)
                        return zip_path
            except Exception:
                pass
            
            return None
        
        # Build proxy URLs if proxy config provided
        proxies = None
        if proxy_config:
            if build_proxy_url:
                proxies = build_proxy_url(proxy_config)
            else:
                proxies = proxy_config
        
        # Download from URL
        verify_ssl = False if proxies else True
        
        # Try different URL patterns
        urls_to_try = []
        if update_link.endswith('.zip'):
            # Direct zip URL
            urls_to_try.append(update_link)
        else:
            # Try common zip file names
            common_names = ["new_version.zip", "update.zip", "OfficeTranslator.zip", "OfficeTranslator_update.zip"]
            for name in common_names:
                # Try with and without trailing slash
                base_url = update_link.rstrip('/')
                urls_to_try.append(f"{base_url}/{name}")
        
        # Try each URL until one works
        response = None
        last_error = None
        for url in urls_to_try:
            try:
                response = requests.get(
                    url,
                    stream=True,
                    proxies=proxies,
                    verify=verify_ssl,
                    timeout=300  # 5 minutes timeout
                )
                response.raise_for_status()
                break  # Success, exit loop
            except Exception as e:
                last_error = e
                continue
        
        if response is None:
            raise Exception(f"Could not download update from any URL. Last error: {str(last_error)}")
        
        # Get total size if available
        total_size = int(response.headers.get('content-length', 0))
        
        # Download with progress
        downloaded = 0
        with open(zip_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if progress_callback and total_size > 0:
                        progress_callback(downloaded, total_size)
        
        return zip_path
        
    except Exception as e:
        if not getattr(sys, 'frozen', False):
            print(f"[Auto Update] Error downloading update: {str(e)}")
        return None


def extract_update_zip(zip_path: str, extract_to: Optional[str] = None) -> Optional[str]:
    """
    Extract update zip to temp directory
    
    Args:
        zip_path: Path to zip file
        extract_to: Optional directory to extract to (default: temp/OfficeTranslator_update)
        
    Returns:
        Optional[str]: Path to extracted directory, or None if error
    """
    try:
        if extract_to is None:
            temp_dir = tempfile.gettempdir()
            extract_to = os.path.join(temp_dir, "OfficeTranslator_update")
        
        # Remove existing extract directory if exists
        if os.path.exists(extract_to):
            shutil.rmtree(extract_to)
        
        os.makedirs(extract_to, exist_ok=True)
        
        # Extract zip
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_to)
        
        return extract_to
        
    except Exception as e:
        if not getattr(sys, 'frozen', False):
            print(f"[Auto Update] Error extracting update: {str(e)}")
        return None


def create_updater_bat(app_dir: str, new_version_dir: str) -> Optional[str]:
    """
    Create updater.bat to replace files after app closes
    
    Args:
        app_dir: Current application directory (will be updated)
        new_version_dir: Directory containing new version files
        
    Returns:
        Optional[str]: Path to updater.bat, or None if error
    """
    try:
        # Log target directory for debugging
        if not getattr(sys, 'frozen', False):
            print(f"[Auto Update] Target update directory: {app_dir}")
            print(f"[Auto Update] New version source: {new_version_dir}")
        
        # Check if new_version_dir contains a single subdirectory (common when extracting zip)
        # If so, we should copy from that subdirectory, not the root
        # Note: new_version_dir may be in extended path format, use it for Python operations
        copy_source_dir = new_version_dir
        try:
            items = [item for item in os.listdir(new_version_dir) if not item.startswith('.')]
            if len(items) == 1:
                single_item = os.path.join(new_version_dir, items[0])
                if os.path.isdir(single_item):
                    # Only one subdirectory - copy from inside it
                    copy_source_dir = single_item
                    if not getattr(sys, 'frozen', False):
                        print(f"[Auto Update] Detected single subdirectory, copying from: {copy_source_dir}")
        except Exception:
            pass  # Use new_version_dir as is
        
        # Normalize copy_source_dir for batch script (batch scripts don't support extended paths)
        copy_source_dir = normalize_path_for_batch(copy_source_dir)
        
        # Get temp directory for updater.bat
        temp_dir = tempfile.gettempdir()
        updater_bat = os.path.join(temp_dir, "OfficeTranslator_updater.bat")
        
        # Get executable name, process name, and command to start app
        if getattr(sys, 'frozen', False):
            exe_name = os.path.basename(sys.executable)
            process_name = exe_name
            start_command = f'"{os.path.join(app_dir, exe_name)}"'
        else:
            # Dev mode: need to find project root where gui_translator.py is located
            project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            gui_script = os.path.join(project_root, "gui_translator.py")
            exe_name = "python.exe"
            process_name = "python.exe"
            start_command = f'python "{gui_script}"'
        
        # Create updater.bat content
        bat_content = f"""@echo off
setlocal enabledelayedexpansion
REM Office Translator Auto Updater
REM This script will replace old version with new version after app closes

echo [Auto Update] Waiting for application to close...
:wait_loop
tasklist /FI "IMAGENAME eq {process_name}" 2>NUL | find /I /N "{process_name}">NUL
if "%ERRORLEVEL%"=="0" (
    timeout /t 1 /nobreak >NUL
    goto wait_loop
)

echo [Auto Update] Application closed. Starting update...

REM Wait a bit more to ensure all files are released
timeout /t 2 /nobreak >NUL

REM Set directories
set "APP_DIR={app_dir}"
set "NEW_DIR={new_version_dir}"

REM Remove old version (except input, output, log - these are preserved)
echo [Auto Update] Removing old version files...

REM IMPORTANT: Explicitly protect input, output, log directories
REM These directories MUST NOT be deleted or modified
echo [Auto Update] Protecting input, output, log directories...

REM First, explicitly remove _internal folder (hidden folder, needs special handling)
if exist "%APP_DIR%\\_internal" (
    echo [Auto Update] Removing _internal directory...
    REM Remove hidden attribute first, then delete
    attrib -H "%APP_DIR%\\_internal" /S /D >NUL 2>&1
    rd /s /q "%APP_DIR%\\_internal" 2>NUL
    if exist "%APP_DIR%\\_internal" (
        REM If still exists, try again with force
        timeout /t 1 /nobreak >NUL
        attrib -H "%APP_DIR%\\_internal" /S /D >NUL 2>&1
        rd /s /q "%APP_DIR%\\_internal" 2>NUL
    )
)

REM Remove other directories (non-hidden)
REM CRITICAL: Skip input, output, log directories - these are preserved and MUST NOT be deleted
for /d %%d in ("%APP_DIR%\\*") do (
    set "dir_name=%%~nxd"
    set "should_delete=1"
    REM Explicitly check and skip protected directories
    if /i "%%dir_name"=="input" (
        echo [Auto Update] SKIPPING input directory (protected)
        set "should_delete=0"
    )
    if /i "%%dir_name"=="output" (
        echo [Auto Update] SKIPPING output directory (protected)
        set "should_delete=0"
    )
    if /i "%%dir_name"=="log" (
        echo [Auto Update] SKIPPING log directory (protected)
        set "should_delete=0"
    )
    if /i "%%dir_name"=="_internal" (
        REM Already handled above, skip
        set "should_delete=0"
    )
    if "!should_delete!"=="1" (
        echo [Auto Update] Removing directory: %%dir_name
        rd /s /q "%%d" 2>NUL
    )
)

REM Remove files (skip input, output, log - these are directories, not files, but check anyway)
for %%f in ("%APP_DIR%\\*.*") do (
    set "file_name=%%~nxf"
    if /i not "%%file_name"=="input" if /i not "%%file_name"=="output" if /i not "%%file_name"=="log" (
        echo [Auto Update] Removing file: %%file_name
        del /f /q "%%f" 2>NUL
    )
)

REM Copy new version files (only contents, not the root directory itself)
REM Skip input, output, log directories from source - these are preserved
echo [Auto Update] Copying new version files...

REM First, explicitly copy _internal folder (hidden folder, needs special handling)
if exist "{copy_source_dir}\\_internal" (
    echo [Auto Update] Copying _internal directory...
    REM Remove old _internal if exists
    if exist "%APP_DIR%\\_internal" (
        attrib -H "%APP_DIR%\\_internal" /S /D >NUL 2>&1
        rd /s /q "%APP_DIR%\\_internal" 2>NUL
    )
    REM Copy with all flags including hidden files
    xcopy "{copy_source_dir}\\_internal" "%APP_DIR%\\_internal\\" /E /I /H /Y /K >NUL
    REM Set hidden attribute after copy
    attrib +H "%APP_DIR%\\_internal" >NUL 2>&1
)

REM Copy other directories (non-hidden)
REM Skip input, output, log directories - these are preserved
for /d %%d in ("{copy_source_dir}\\*") do (
    set "dir_name=%%~nxd"
    if /i not "%%dir_name"=="input" if /i not "%%dir_name"=="output" if /i not "%%dir_name"=="log" (
        if /i not "%%dir_name"=="_internal" (
            echo [Auto Update] Copying directory: %%dir_name
            xcopy "%%d" "%APP_DIR%\\%%dir_name\\" /E /I /H /Y >NUL
        )
    )
)

REM Copy files (not directories) from source
REM Skip input, output, log - these are directories, not files, but check anyway
for %%f in ("{copy_source_dir}\\*.*") do (
    set "file_name=%%~nxf"
    if /i not "%%file_name"=="input" if /i not "%%file_name"=="output" if /i not "%%file_name"=="log" (
        echo [Auto Update] Copying file: %%file_name
        copy /Y "%%f" "%APP_DIR%\\" >NUL
    )
)

REM Verify important directories exist (create if missing)
echo [Auto Update] Verifying important directories...
if not exist "%APP_DIR%\\input" (
    echo [Auto Update] Creating input directory...
    mkdir "%APP_DIR%\\input" 2>NUL
)
if not exist "%APP_DIR%\\output" (
    echo [Auto Update] Creating output directory...
    mkdir "%APP_DIR%\\output" 2>NUL
)
if not exist "%APP_DIR%\\log" (
    echo [Auto Update] Creating log directory...
    mkdir "%APP_DIR%\\log" 2>NUL
)

REM Clean up temp files
echo [Auto Update] Cleaning up temporary files...
if exist "{new_version_dir}" rd /s /q "{new_version_dir}" 2>NUL
if exist "{os.path.join(tempfile.gettempdir(), 'OfficeTranslator_update.zip')}" del /f /q "{os.path.join(tempfile.gettempdir(), 'OfficeTranslator_update.zip')}" 2>NUL

REM Start application
echo [Auto Update] Starting updated application...
cd /d "%APP_DIR%"
{start_command}

REM Delete this batch file
timeout /t 2 /nobreak >NUL
del /f /q "%~f0"

echo [Auto Update] Update completed successfully!
"""
        
        # Write bat file
        with open(updater_bat, 'w', encoding='utf-8') as f:
            f.write(bat_content)
        
        return updater_bat
        
    except Exception as e:
        if not getattr(sys, 'frozen', False):
            print(f"[Auto Update] Error creating updater.bat: {str(e)}")
        return None


def run_auto_update(update_link: str, proxy_config: Optional[dict] = None,
                   progress_callback: Optional[Callable[[str, int, int], None]] = None) -> bool:
    """
    Run complete auto update process
    
    Args:
        update_link: URL or network path to update
        proxy_config: Optional proxy configuration
        progress_callback: Optional callback function(stage, current, total) for progress
            stage: "download", "extract", "create_bat", "complete"
            current: current progress
            total: total progress
        
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        # Check and attempt to enable long paths support
        check_and_enable_long_paths()
        # Step 1: Download zip
        if progress_callback:
            progress_callback("download", 0, 100)
        
        def download_progress(loaded, total):
            if progress_callback and total > 0:
                progress = int((loaded / total) * 50)  # Download is 50% of total
                progress_callback("download", progress, 100)
        
        zip_path = download_update_zip(update_link, proxy_config, download_progress)
        if not zip_path:
            return False
        
        if progress_callback:
            progress_callback("download", 50, 100)
        
        # Step 2: Extract zip
        if progress_callback:
            progress_callback("extract", 50, 100)
        
        extract_dir = extract_update_zip(zip_path)
        if not extract_dir:
            return False
        
        if progress_callback:
            progress_callback("extract", 75, 100)
        
        # Step 3: Create updater.bat
        if progress_callback:
            progress_callback("create_bat", 75, 100)
        
        app_dir = get_app_directory()
        # Ensure paths are compatible with long path limitations (for Python operations)
        app_dir_extended = ensure_long_path_support(app_dir)
        extract_dir_extended = ensure_long_path_support(extract_dir)
        
        # Normalize paths for batch script (batch scripts don't support extended paths)
        app_dir_normalized = normalize_path_for_batch(app_dir_extended)
        extract_dir_normalized = normalize_path_for_batch(extract_dir_extended)
        
        # Log target directory for user information
        if not getattr(sys, 'frozen', False):
            print(f"[Auto Update] Will update directory: {app_dir_normalized}")
            if app_dir_extended != app_dir_normalized:
                print(f"[Auto Update] Using extended path for Python: {app_dir_extended[:80]}...")
        
        # Use normalized paths for batch script
        updater_bat = create_updater_bat(app_dir_normalized, extract_dir_normalized)
        if not updater_bat:
            return False
        
        if progress_callback:
            progress_callback("create_bat", 90, 100)
        
        # Step 4: Run updater.bat and exit
        if progress_callback:
            progress_callback("complete", 100, 100)
        
        # Run updater.bat in background (detached)
        subprocess.Popen(
            [updater_bat],
            shell=True,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        )
        
        return True
        
    except Exception as e:
        if not getattr(sys, 'frozen', False):
            print(f"[Auto Update] Error in auto update process: {str(e)}")
            import traceback
            traceback.print_exc()
        return False


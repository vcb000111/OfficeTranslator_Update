# Changelog

Tất cả các thay đổi đáng chú ý trong dự án này sẽ được ghi lại trong file này.

## [3.3] - 2025-11-21

### Fixed
- **Excel Text Detection**: Sửa lỗi bỏ sót text trong file Excel, đặc biệt là các cột ngoài phạm vi kiểm tra ban đầu
  - Cải thiện logic skip hàng trống: Tăng ngưỡng kiểm tra từ 50 lên 100 cột
  - Với file có <= 100 cột: Kiểm tra tất cả các cột để đảm bảo không bỏ sót dữ liệu
  - Với file có > 100 cột: Sử dụng strategic sampling với nhiều điểm kiểm tra hơn
    - Kiểm tra 30 cột đầu (bao gồm cột K và các cột tiếp theo)
    - Sample mỗi 20 cột để phủ toàn bộ phạm vi
    - Kiểm tra cột giữa và 20 cột cuối
  - Cải thiện fallback method: Tăng phạm vi từ 1000x100 lên 5000x200 rows/columns
  - Sửa lỗi format cell_references trong fallback method để đảm bảo update đúng

### Improved
- **Excel Processing Performance**: Tối ưu hiệu suất quét text trong Excel
  - Loại bỏ duplicate columns trong danh sách kiểm tra
  - Sắp xếp danh sách cột để tối ưu quá trình quét
  - Đảm bảo không bỏ sót dữ liệu ở các cột như K, L, M và các cột khác

## [3.2] - 2025-11-20

### Added
- **Auto Update System**: Thêm hệ thống tự động cập nhật phiên bản mới hoàn chỉnh
  - Tự động tải file cập nhật (.zip) từ update link
  - Tự động giải nén file cập nhật vào thư mục tạm
  - Tự động tạo script cài đặt để thay thế file sau khi ứng dụng đóng
  - Tự động khởi động lại ứng dụng với phiên bản mới
  - Progress dialog hiển thị tiến trình: Downloading → Extracting → Preparing → Complete
  - Bảo vệ dữ liệu: Tự động bảo vệ các thư mục input, output, log (không bị xóa hoặc ghi đè)
  - Hỗ trợ proxy với xác thực cho quá trình tải cập nhật
  - Hỗ trợ long paths trên Windows 10 (tự động bật hoặc dùng workarounds)
  - Tương thích Windows 10 và Windows 11
  - Tự động migrate settings từ thư mục cũ sang AppData để không bị mất khi update
- **Enhanced Translation Prompts**: Cải thiện và mở rộng các prompt files chuyên ngành
  - Cập nhật và chuẩn hóa format cho tất cả các prompt files theo chuẩn thống nhất
  - Bổ sung hàng trăm thuật ngữ chuyên ngành cho các lĩnh vực:
    - Accounting & Finance: Thuật ngữ kế toán, tài chính, thuế, báo cáo tài chính
    - Human Resources: Thuật ngữ nhân sự, tuyển dụng, đào tạo, lương thưởng
    - IT & Information Systems: Thuật ngữ công nghệ thông tin, hệ thống, bảo mật
    - Quality Control: Thuật ngữ kiểm soát chất lượng, tiêu chuẩn
    - Production & Manufacturing: Thuật ngữ sản xuất, thiết bị, quy trình
    - Procurement: Thuật ngữ mua hàng, đấu thầu, hợp đồng
    - Maintenance: Thuật ngữ bảo trì, bảo dưỡng thiết bị
  - Chia thuật ngữ thành 2 loại rõ ràng:
    - Terms to Keep Unchanged: Các thuật ngữ kỹ thuật giữ nguyên tiếng Anh
    - Terms to Translate: Các thuật ngữ cần dịch sang tiếng Việt với bản dịch chuẩn
  - Cải thiện độ chính xác và nhất quán trong dịch thuật theo từng chuyên ngành

### Changed
- **Version Update**: Cập nhật phiên bản từ v3.1 lên v3.2
- **Settings Storage**: 
  - Di chuyển settings và proxy settings vào AppData (`%APPDATA%\OfficeDocumentTranslator\`)
  - Tự động migrate settings từ thư mục cũ sang AppData khi khởi động
  - Settings được giữ nguyên qua các lần update
- **Update Dialog**: Thêm button "Cập nhật thủ công" (hoặc "Manual Update") vào dialog thông báo cập nhật
  - Button "Bắt đầu tự động cập nhật" (hoặc "Start Auto Update") để tự động cập nhật
  - Button "Cập nhật thủ công" (hoặc "Manual Update") để mở link cập nhật cho user tự update
  - Tự động mở URL trong trình duyệt hoặc mở thư mục mạng trong Windows Explorer
  - Hỗ trợ cả URL (http/https) và network path (\\server\share)
- **Proxy Handling**:
  - Kiểm tra trạng thái proxy server (online/offline/needs_auth) trước khi sử dụng
  - Chỉ sử dụng proxy khi proxy server online, tự động bỏ qua nếu offline
  - Proxy settings được lưu trong AppData để không bị mất khi update
- **Environment Variables**: Hỗ trợ tách biệt biến môi trường cho dev và production
  - Development: Đọc từ `.env.dev` (khi chạy Python script)
  - Production: Đọc từ `.env.pro` hoặc `.env.enc` (khi chạy EXE)
  - Update URLs: `VERSION_DEVELOPMENT`, `UPDATE_LINK_DEVELOPMENT` (dev) và `VERSION_PRODUCTION`, `UPDATE_LINK_PRODUCTION` (pro)

### Technical Details
- **Auto Updater Module**: Module mới `src/auto_updater.py` xử lý quá trình tự động cập nhật
  - `download_update_zip()`: Tải file .zip từ URL hoặc network path
  - `extract_update_zip()`: Giải nén file .zip vào thư mục tạm
  - `create_updater_bat()`: Tạo batch script để thay thế file sau khi app đóng
  - `run_auto_update()`: Orchestrate toàn bộ quá trình cập nhật
  - Bảo vệ dữ liệu: Tự động skip xóa/copy các thư mục input, output, log
  - Hỗ trợ long paths: Tự động bật hoặc dùng workarounds (extended paths, short paths)
  - Tương thích Windows 10/11: Tự động xử lý các khác biệt về long paths
- **Update Checker Module**: Cải tiến `src/update_checker.py`
  - `check_proxy_server_status()`: Kiểm tra trạng thái proxy (online/offline/needs_auth)
  - `load_env_variable()`: Đọc environment variables trực tiếp từ `.env` hoặc `.env.enc`
  - `get_version_check_url()` và `get_update_link_url()`: Tự động chọn URL đúng (DEV/PRO) dựa trên môi trường
- **Settings Persistence**:
  - Settings được lưu trong `%APPDATA%\OfficeDocumentTranslator\app_settings.json`
  - Proxy settings được lưu trong `%APPDATA%\OfficeDocumentTranslator\proxy_settings.json`
  - Tự động migrate settings từ thư mục cũ sang AppData khi khởi động
  - Settings được giữ nguyên qua các lần update

## [3.1] - 2025-11-15

### Added
- **File Selection Mode**: Thêm chức năng chọn file riêng lẻ thay vì chỉ chọn thư mục
  - Thêm 2 radiobuttons để chọn giữa "Folder" và "File"
  - Hỗ trợ chọn nhiều file cùng lúc (multiple file selection)
  - Hiển thị danh sách file đã chọn với tên file (tối đa 3 file, sau đó hiển thị "... (+N more)")
  - Lưu danh sách file đã chọn vào settings để khôi phục khi mở lại ứng dụng
  - Validation: Kiểm tra file còn tồn tại trước khi dịch
- **Version History Dialog**: Thêm button "Phiên bản" để xem lịch sử cập nhật phiên bản
- **Auto Update Checker**: Thêm tính năng tự động kiểm tra phiên bản mới khi khởi động ứng dụng
  - Tự động kiểm tra từ GitHub repository khi ứng dụng khởi động
  - Hiển thị dialog thông báo nếu có phiên bản mới với link tải về
  - Kiểm tra ngầm trong background thread, không block UI
  - Đọc phiên bản hiện tại từ file `version.txt` (embedded trong build)
  - So sánh semantic version để xác định phiên bản mới
- **Auto Update System**: Thêm tính năng tự động cập nhật phiên bản mới (v3.1+)
  - Tự động tải file cập nhật (.zip) từ update link
  - Tự động giải nén file cập nhật vào thư mục tạm
  - Tự động tạo script cài đặt để thay thế file sau khi ứng dụng đóng
  - Tự động khởi động lại ứng dụng với phiên bản mới
  - Progress dialog hiển thị tiến trình: Downloading → Extracting → Preparing → Complete
  - Bảo vệ dữ liệu: Tự động bảo vệ các thư mục input, output, log (không bị xóa hoặc ghi đè)
  - Hỗ trợ proxy với xác thực cho quá trình tải cập nhật
  - Hỗ trợ long paths trên Windows 10 (tự động bật hoặc dùng workarounds)
  - Tương thích Windows 10 và Windows 11
- **Proxy Support with Authentication**: Thêm hỗ trợ proxy với xác thực cho mạng công ty
  - Tự động phát hiện proxy từ Windows environment variables và registry
  - Kiểm tra trạng thái proxy server (online/offline/needs_auth) trước khi sử dụng
  - Dialog nhập username/password proxy khi cần xác thực (407 Proxy Authentication Required)
  - Tự động xử lý SSL certificate verification cho proxy self-signed
  - Lưu proxy credentials vào AppData để sử dụng lại (không bị mất khi update)
  - Hỗ trợ URL encoding cho username/password có ký tự đặc biệt
  - Normalize proxy URL để tránh duplicate `http://` prefix
  - Chỉ sử dụng proxy khi proxy server online, tự động bỏ qua nếu offline
- **Image Translation Note**: Thêm lưu ý về việc không hỗ trợ dịch hình ảnh trong dialog Notes

### Changed
- **Version Update**: Cập nhật phiên bản từ v3.0 lên v3.1
- **File Filtering**: Bỏ logic bỏ qua file có suffix "_TRANSLATED_" - giờ có thể dịch lại file đã dịch
- **Translation Logic**: Cập nhật `run_translation()` để xử lý cả hai chế độ:
  - Folder mode: Xử lý tất cả file trong thư mục (như cũ)
  - File mode: Xử lý từng file đã chọn riêng lẻ
- **UI Layout**: Thêm file selection frame với label và button riêng, hiển thị/ẩn dựa trên mode đã chọn
- **Settings Storage**: 
  - Thêm `input_mode` và `selected_files` vào settings để lưu trữ
  - Di chuyển settings và proxy settings vào AppData để không bị mất khi update
  - Tự động migrate settings từ thư mục cũ sang AppData
- **Update Dialog**: Thay đổi button "Tải về phiên bản mới" thành "Bắt đầu tự động cập nhật" (hoặc "Start Auto Update")
  - Tự động cập nhật là phương pháp duy nhất để cập nhật phiên bản mới

### Removed
- **PDF Translation Support**: Bỏ chức năng dịch file PDF do hạn chế về chỉnh sửa format sau khi dịch

### Technical Details
- **File Selection**: Sử dụng `filedialog.askopenfilenames()` để chọn nhiều file
- **File Validation**: Tự động lọc các file không được hỗ trợ và kiểm tra file còn tồn tại
- **UI State Management**: Sử dụng `grid()` và `grid_remove()` để hiển thị/ẩn các frame tương ứng với mode
- **Update Checker Module**: Tách logic kiểm tra phiên bản ra file `src/update_checker.py` riêng
  - `get_current_version()`: Đọc version từ `version.txt` (tìm trong exe_dir, _internal, src/, parent_dir)
  - `get_latest_version()`: Fetch version từ GitHub raw URL với timeout 5s
  - `compare_versions()`: So sánh semantic version (major.minor.patch)
  - `check_for_update()`: Orchestrate update check process
  - `check_proxy_server_status()`: Kiểm tra trạng thái proxy (online/offline/needs_auth)
- **Auto Updater Module**: Module mới `src/auto_updater.py` xử lý quá trình tự động cập nhật
  - `download_update_zip()`: Tải file .zip từ URL hoặc network path
  - `extract_update_zip()`: Giải nén file .zip vào thư mục tạm
  - `create_updater_bat()`: Tạo batch script để thay thế file sau khi app đóng
  - `run_auto_update()`: Orchestrate toàn bộ quá trình cập nhật
  - Bảo vệ dữ liệu: Tự động skip xóa/copy các thư mục input, output, log
  - Hỗ trợ long paths: Tự động bật hoặc dùng workarounds (extended paths, short paths)
  - Tương thích Windows 10/11: Tự động xử lý các khác biệt về long paths
- **Proxy Handling**:
  - `detect_system_proxy()`: Phát hiện proxy từ `HTTP_PROXY`, `HTTPS_PROXY`, Windows registry
  - `check_proxy_server_status()`: Kiểm tra proxy server online/offline trước khi sử dụng
  - `build_proxy_url()`: Xây dựng proxy URL với authentication (URL-encoded username:password)
  - `normalize_proxy_url()`: Chuẩn hóa proxy URL, loại bỏ duplicate `http://` prefix
  - `get_proxy_config()`: Ưu tiên saved settings từ AppData, fallback về system proxy
  - SSL verification tự động disabled khi dùng proxy (corporate proxy thường dùng self-signed cert)
  - Retry logic với `verify=False` khi gặp SSL certificate error
  - Chỉ sử dụng proxy khi proxy server online, tự động bỏ qua nếu offline
- **Settings Persistence**:
  - Settings được lưu trong `%APPDATA%\OfficeDocumentTranslator\app_settings.json`
  - Proxy settings được lưu trong `%APPDATA%\OfficeDocumentTranslator\proxy_settings.json`
  - Tự động migrate settings từ thư mục cũ sang AppData khi khởi động
  - Settings được giữ nguyên qua các lần update
- **Version File**: File `version.txt` được embed vào build trong `_internal` directory
- **Environment Variables**: Hỗ trợ tách biệt biến môi trường cho dev và production
  - Development: Đọc từ `.env.dev` (khi chạy Python script)
  - Production: Đọc từ `.env.pro` hoặc `.env.enc` (khi chạy EXE)
  - Update URLs: `VERSION_DEVELOPMENT`, `UPDATE_LINK_DEVELOPMENT` (dev) và `VERSION_PRODUCTION`, `UPDATE_LINK_PRODUCTION` (pro)

## [3.0] - 2025-11-13

### Added
- **Security Warning Disclaimer**: Thêm disclaimer vào security warning dialog thông báo DP-IT Team không chịu trách nhiệm về vấn đề bảo mật hoặc rò rỉ dữ liệu
- **Settings Persistence**: Thêm chức năng lưu và tự động load settings từ lần chạy trước (input folder, output folder, target language, UI language)
- **Debug Configuration**: Thêm config `SAVE_SECURITY_PREFERENCE` ở đầu file để điều khiển việc lưu security warning preference (dùng cho debug)
- **OneDir Build Mode**: Tạo file `build_exe_onedir.py` để build với PyInstaller --onedir mode, tối ưu dung lượng file và tốc độ khởi động

### Changed
- **UI Padding**: Giảm padding top và bottom của các elements để tăng không gian hiển thị cho activity log
  - Main frame padding: 20 → 10
  - LabelFrame padding: 8 → 5
  - Giảm pady spacing giữa các elements
- **Security Warning**: Cập nhật message để bao gồm disclaimer về trách nhiệm của DP-IT Team (có trong cả 3 ngôn ngữ: en, vi, ja)

### Removed
- **API Key Link in EXE**: Ẩn link "Get FREE Gemini API Key" khi chạy ở chế độ executable (chỉ hiển thị khi chạy script)
- **Reset Security Warning Button**: Bỏ nút reset security warning (thay bằng config `SAVE_SECURITY_PREFERENCE`)
- **API Key Free Text**: Bỏ tất cả text "lấy API miễn phí" trong GUI
- **Setup Folder**: Bỏ tạo thư mục `setup` và các file hướng dẫn khi build onedir
- **README.txt**: Bỏ tạo file README.txt khi build onedir

### Fixed
- **OneDir Build Error**: Sửa lỗi build onedir - bỏ flag `--onedir` khi sử dụng file `.spec` (mode đã được định nghĩa trong spec file)

### Improved
- **OneDir Build**: 
  - Tự động ẩn thư mục `_internal` sau khi build (dùng `attrib +H` trên Windows)
  - Tối ưu cấu trúc package, chỉ giữ lại các file cần thiết
- **Settings Management**: 
  - Tự động lưu settings khi user thay đổi input/output folder, target language, hoặc UI language
  - Hiển thị thông báo "Loaded settings from last session" khi có settings đã lưu
- **Code Organization**: 
  - Tách localization strings ra file `localization.py` riêng
  - Cải thiện cấu trúc code để dễ bảo trì

### Technical Details
- **Settings Storage**: Settings được lưu trong file `.app_settings.json` (JSON format)
- **OneDir vs OneFile**: 
  - OneDir: File exe nhỏ hơn, khởi động nhanh hơn, dễ debug
  - OneFile: Một file duy nhất nhưng lớn hơn và chậm hơn
- **Hidden Files**: 
  - `.env` file được set hidden sau khi tạo
  - `_internal` folder được set hidden sau khi build onedir

## [2.0.0] - 2024-05

### Added
- **GUI Interface**: Thêm giao diện đồ họa user-friendly (`gui_translator.py`)
- **Multi-format Support**: Hỗ trợ thêm Word (.docx, .doc) và PowerPoint (.pptx, .ppt)
- **Build Tools**: Thêm script `build_exe.py` để tạo standalone executable
- **Real-time Progress**: Theo dõi tiến trình dịch real-time
- **Batch Processing**: Xử lý nhiều file cùng lúc

### Improved
- Format preservation cho tất cả các loại file
- Error handling và retry mechanism
- User experience với GUI

## [1.0.0] - 2024-04

### Added
- Initial release với hỗ trợ Excel translation
- Core translation engine với Google Gemini API
- Command line interface

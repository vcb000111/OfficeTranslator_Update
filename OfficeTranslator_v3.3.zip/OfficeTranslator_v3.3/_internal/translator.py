#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Unified Office Document Translator
---------------------------------
Translates text content in Microsoft Office documents (Excel, Word, PowerPoint)
between Japanese, English, and Vietnamese using the Gemini API.

This script combines the functionality of trans-excel.py and trans-office.py
into a single, unified interface with improved error handling, progress tracking,
and a modern command-line interface.
"""

import os
import sys
import time
import argparse
import json
import re
import glob
import subprocess
import mimetypes
from enum import Enum
from typing import List, Dict, Tuple, Optional, Union, Callable, Any
from pathlib import Path
import datetime
import logging
from logging.handlers import RotatingFileHandler
import base64
import hashlib

# Add rich for improved terminal UI
try:
    from rich.console import Console
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskID
    from rich.panel import Panel
    from rich.text import Text
    HAS_RICH = True
except ImportError:
    HAS_RICH = False

# ============================================================================
# DEBUG CONFIGURATION
# ============================================================================
# Set to True to enable detailed logging (for debugging)
# Set to False to disable detailed logging (for production)
# Automatically set to False when running as executable
IS_DEBUGGING = not getattr(sys, 'frozen', False)  # True for script, False for exe
# ============================================================================

# Setup logging to file
_log_file_handler = None
_log_file_path = None

def setup_file_logging():
    """Setup file logging to log directory"""
    global _log_file_handler, _log_file_path
    
    try:
        # Determine app directory (exe or script)
        if getattr(sys, 'frozen', False):
            app_dir = os.path.dirname(sys.executable)
        else:
            app_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Create log directory
        log_dir = os.path.join(app_dir, "log")
        os.makedirs(log_dir, exist_ok=True)
        
        # Create log file with timestamp
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        log_filename = f"translation_{timestamp}.log"
        _log_file_path = os.path.join(log_dir, log_filename)
        
        # Setup rotating file handler (max 10MB per file, keep 5 backup files)
        _log_file_handler = RotatingFileHandler(
            _log_file_path,
            maxBytes=10*1024*1024,  # 10MB
            backupCount=5,
            encoding='utf-8'
        )
        
        # Set format
        formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        _log_file_handler.setFormatter(formatter)
        _log_file_handler.setLevel(logging.DEBUG)
        
        return True
    except Exception as e:
        # If logging setup fails, continue without file logging
        print(f"Warning: Could not setup file logging: {e}")
        return False

def get_log_file_path():
    """Get the current log file path"""
    return _log_file_path

# Initialize file logging on module import
if setup_file_logging():
    log_path = get_log_file_path()
    if log_path:
        print(f"📝 Log file: {log_path}")

# Enhanced PowerPoint processing imports
try:
    import zipfile
    import xml.etree.ElementTree as ET
    from lxml import etree
    HAS_LXML = True
except ImportError:
    HAS_LXML = False

# Image processing for enhanced PowerPoint support
try:
    import base64
    import io
    HAS_IMAGE_LIBS = True
except ImportError:
    HAS_IMAGE_LIBS = False

try:
    import win32com.client
    import comtypes
    HAS_COM = True
except ImportError:
    HAS_COM = False

try:
    from PIL import Image
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

# Define document type enum
class DocType(Enum):
    """Enum for supported document types"""
    EXCEL = "excel"
    WORD = "word"
    POWERPOINT = "powerpoint"
    UNKNOWN = "unknown"

# Initialize rich console if available
console = Console() if HAS_RICH else None

def print_info(message: str) -> None:
    """Print an informational message with rich formatting if available"""
    if HAS_RICH:
        console.print(f"[bold blue]INFO[/bold blue] {message}")
    else:
        print(f"INFO: {message}")
    
    # Write to log file
    if _log_file_handler:
        try:
            _log_file_handler.emit(logging.LogRecord(
                name="translator",
                level=logging.INFO,
                pathname="",
                lineno=0,
                msg=message,
                args=(),
                exc_info=None
            ))
        except:
            pass

def print_success(message: str) -> None:
    """Print a success message with rich formatting if available"""
    if HAS_RICH:
        console.print(f"[bold green]SUCCESS[/bold green] {message}")
    else:
        print(f"SUCCESS: {message}")
    
    # Write to log file
    if _log_file_handler:
        try:
            _log_file_handler.emit(logging.LogRecord(
                name="translator",
                level=logging.INFO,
                pathname="",
                lineno=0,
                msg=f"SUCCESS: {message}",
                args=(),
                exc_info=None
            ))
        except:
            pass

def print_warning(message: str) -> None:
    """Print a warning message with rich formatting if available"""
    if HAS_RICH:
        console.print(f"[bold yellow]WARNING[/bold yellow] {message}")
    else:
        print(f"WARNING: {message}")
    
    # Write to log file
    if _log_file_handler:
        try:
            _log_file_handler.emit(logging.LogRecord(
                name="translator",
                level=logging.WARNING,
                pathname="",
                lineno=0,
                msg=message,
                args=(),
                exc_info=None
            ))
        except:
            pass

def print_error(message: str) -> None:
    """Print an error message with rich formatting if available"""
    if HAS_RICH:
        console.print(f"[bold red]ERROR[/bold red] {message}")
    else:
        print(f"ERROR: {message}")
    
    # Write to log file
    if _log_file_handler:
        try:
            _log_file_handler.emit(logging.LogRecord(
                name="translator",
                level=logging.ERROR,
                pathname="",
                lineno=0,
                msg=message,
                args=(),
                exc_info=None
            ))
        except:
            pass

def print_header(title: str) -> None:
    """Print a header with rich formatting if available"""
    if HAS_RICH:
        console.print(Panel(Text(title, justify="center"), style="bold blue"))
    else:
        border = "=" * (len(title) + 10)
        print(f"\n{border}\n    {title}\n{border}")
    
    # Write to log file
    if _log_file_handler:
        try:
            _log_file_handler.emit(logging.LogRecord(
                name="translator",
                level=logging.INFO,
                pathname="",
                lineno=0,
                msg=f"=== {title} ===",
                args=(),
                exc_info=None
            ))
        except:
            pass

def check_and_install_dependencies() -> bool:
    """
    Check if required dependencies are installed and install if needed.
    
    Returns:
        bool: True if all dependencies are available, False otherwise
    """
    try:
        # Create requirements file
        script_dir = os.path.dirname(os.path.abspath(__file__))
        req_file = os.path.join(script_dir, "translator-requirements.txt")
        
        if not os.path.exists(req_file):
            print_info("Creating requirements file...")
            with open(req_file, 'w', encoding='utf-8') as f:
                f.write(
                    "openai>=1.0.0\n"
                    "xlwings>=0.30.0\n"
                    "python-pptx>=0.6.21\n"
                    "python-docx>=0.8.11\n"
                    "python-dotenv>=1.0.0\n"
                    "rich>=13.0.0\n"
                    "tqdm>=4.66.0\n"
                )
            print_success(f"Requirements file created at: {req_file}")
        
        print_info("Checking for required libraries...")
        
        # Check if packages are installed
        missing_packages = []
        required_packages = {
            "openai": "OpenAI API client",
            "xlwings": "Excel file processing",
            "pptx": "PowerPoint file processing (python-pptx)",
            "docx": "Word file processing (python-docx)",
            "dotenv": "Environment variable loading (python-dotenv)",
            "rich": "Enhanced terminal output"
        }
        
        for package, description in required_packages.items():
            try:
                __import__(package)
            except ImportError:
                missing_packages.append(package)
                print_warning(f"Missing {description} ({package})")
        
        # If packages are missing, attempt to install them
        if missing_packages:
            print_info(f"Missing packages: {', '.join(missing_packages)}")
            print_info("Attempting to install missing packages automatically...")
            
            try:
                # Install required packages
                subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", req_file])
                print_success("Successfully installed required packages.")
            except subprocess.CalledProcessError as e:
                print_error(f"Failed to install packages automatically: {str(e)}")
                print_info("Please manually install the required packages with this command:")
                print_info(f"pip install -r {req_file}")
                return False
        else:
            print_success("All required libraries are already installed.")
            
        # Verify imports after installation attempt
        try:
            import openai
            import xlwings as xw
            import pptx
            import docx
            from dotenv import load_dotenv
            
            
            # Try to import rich again if it was missing
            if "rich" in missing_packages:
                import rich
                from rich.console import Console
                from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
                from rich.panel import Panel
                from rich.text import Text
                global console, HAS_RICH
                console = Console()
                HAS_RICH = True
                print_success("Rich library loaded successfully - enhanced UI enabled.")
                
            print_success("All required libraries loaded successfully.")
            return True
        except ImportError as e:
            print_error(f"Error importing library after installation attempt: {str(e)}")
            print_info("Please manually install the required libraries and try again:")
            print_info(f"pip install -r {req_file}")
            return False
    except Exception as e:
        print_error(f"Error checking libraries: {str(e)}")
        return False

def get_file_type(file_path: str) -> DocType:
    """
    Determine the document type based on file extension.
    
    Args:
        file_path: Path to the file
        
    Returns:
        DocType: Type of document (EXCEL, WORD, POWERPOINT, or UNKNOWN)
    """
    ext = os.path.splitext(file_path)[1].lower()
    
    if ext in ['.xlsx', '.xls', '.xlsm']:
        return DocType.EXCEL
    elif ext in ['.docx', '.doc']:
        return DocType.WORD
    elif ext in ['.pptx', '.ppt']:
        return DocType.POWERPOINT
    else:
        return DocType.UNKNOWN

def clean_text(text: Optional[str]) -> str:
    """
    Clean and normalize text before translation.
    
    Args:
        text: The text to clean
        
    Returns:
        str: Cleaned text
    """
    if not text or not isinstance(text, str):
        return ""
    text = ' '.join(text.split())  # Normalize whitespace
    return text.strip()

def get_api_config(env_file: str) -> Dict[str, Any]:
    """
    Get API configuration from .env file.
    Supports multiple API providers: Gemini, OpenAI, Claude, etc.
    
    Args:
        env_file: Path to .env file
        
    Returns:
        Dict with keys: base_url, model, api_key_name, api_keys
    """
    # Default configuration (Gemini)
    config = {
        "base_url": "https://generativelanguage.googleapis.com/v1beta/",
        "model": "gemini-2.0-flash",
        "api_key_name": "GEMINI_API_KEY",
        "api_keys": []
    }
    
    # Try to load from .env file
    try:
        from dotenv import load_dotenv
        load_dotenv(env_file)
        
        # Check for API provider configuration
        api_provider = os.getenv("API_PROVIDER", "gemini").lower()
        
        if api_provider == "openai":
            config["base_url"] = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
            config["model"] = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
            config["api_key_name"] = "OPENAI_API_KEY"
        elif api_provider == "claude" or api_provider == "anthropic":
            config["base_url"] = os.getenv("ANTHROPIC_BASE_URL", "https://api.anthropic.com/v1")
            config["model"] = os.getenv("ANTHROPIC_MODEL", "claude-3-5-sonnet-20241022")
            config["api_key_name"] = "ANTHROPIC_API_KEY"
        elif api_provider == "gemini":
            # Use defaults (already set)
            pass
        else:
            # Custom provider - read from env
            config["base_url"] = os.getenv("API_BASE_URL", config["base_url"])
            config["model"] = os.getenv("API_MODEL", config["model"])
            config["api_key_name"] = os.getenv("API_KEY_NAME", config["api_key_name"])
        
        # Override with explicit settings if provided
        if os.getenv("API_BASE_URL"):
            config["base_url"] = os.getenv("API_BASE_URL")
        if os.getenv("API_MODEL"):
            config["model"] = os.getenv("API_MODEL")
            
    except Exception as e:
        print_warning(f"Could not load API config from .env: {e}, using defaults")
    
    return config


class APIClientManager:
    """
    Manages multiple API clients with automatic fallback support.
    Supports 1 primary API key and 4 backup API keys.
    Compatible with multiple API providers (Gemini, OpenAI, Claude, etc.)
    """
    def __init__(self, api_keys: List[str], base_url: Optional[str] = None, model: Optional[str] = None):
        """
        Initialize API Client Manager with list of API keys.
        
        Args:
            api_keys: List of API keys (primary first, then backups)
            base_url: Optional API base URL (defaults to Gemini if not provided)
            model: Optional model name (defaults to gemini-2.0-flash if not provided)
        """
        if not api_keys:
            raise ValueError("At least one API key is required")
        
        self.api_keys = [key.strip() for key in api_keys if key and key.strip()]
        if not self.api_keys:
            raise ValueError("No valid API keys provided")
        
        # Use provided config or defaults (Gemini)
        self.base_url = base_url or "https://generativelanguage.googleapis.com/v1beta/"
        self.model = model or "gemini-2.0-flash"
        
        self.current_key_index = 0
        self.clients = []
        self._initialize_clients()
    
    def _initialize_clients(self):
        """Initialize OpenAI-compatible clients for all API keys"""
        try:
            from openai import OpenAI
        except ImportError:
            raise ImportError("OpenAI library is required. Install with: pip install openai")
        
        for idx, api_key in enumerate(self.api_keys):
            try:
                client = OpenAI(
                    base_url=self.base_url,
                    api_key=api_key,
                )
                self.clients.append(client)
                if idx == 0:
                    print_info(f"Primary API key initialized (Provider: {self._get_provider_name()}, Model: {self.model})")
                else:
                    print_info(f"Backup API key {idx} initialized")
            except Exception as e:
                print_warning(f"Failed to initialize API key {idx + 1}: {str(e)}")
                self.clients.append(None)
    
    def _get_provider_name(self) -> str:
        """Get provider name from base_url"""
        if "generativelanguage.googleapis.com" in self.base_url:
            return "Gemini"
        elif "openai.com" in self.base_url:
            return "OpenAI"
        elif "anthropic.com" in self.base_url:
            return "Anthropic/Claude"
        else:
            return "Custom"
    
    def get_current_client(self):
        """Get the currently active API client"""
        if self.current_key_index < len(self.clients) and self.clients[self.current_key_index]:
            return self.clients[self.current_key_index]
        return None
    
    def get_current_key_info(self):
        """Get information about current API key"""
        if self.current_key_index == 0:
            return "Primary API key"
        else:
            return f"Backup API key {self.current_key_index}"
    
    def switch_to_next_key(self):
        """
        Switch to the next available API key.
        
        Returns:
            bool: True if switched to next key, False if no more keys available
        """
        self.current_key_index += 1
        
        # Find next available client
        while self.current_key_index < len(self.clients):
            if self.clients[self.current_key_index] is not None:
                print_warning(f"Switching to {self.get_current_key_info()}")
                return True
            self.current_key_index += 1
        
        # No more keys available
        print_error(f"All API keys exhausted. Total keys tried: {len(self.api_keys)}")
        return False
    
    def has_more_keys(self):
        """Check if there are more API keys available"""
        return self.current_key_index < len(self.api_keys) - 1
    
    def get_total_keys(self):
        """Get total number of API keys"""
        return len(self.api_keys)
    
    def get_active_key_index(self):
        """Get index of currently active API key"""
        return self.current_key_index


def _get_encryption_key() -> bytes:
    """Generate encryption key from a fixed seed"""
    # Use a fixed seed to generate consistent key
    # Note: Seed should remain constant across versions to ensure .env.enc files
    # created with older versions can still be decrypted by newer versions
    seed = "OfficeTranslator_DPIT"
    return hashlib.sha256(seed.encode('utf-8')).digest()

def encrypt_env_file(env_file_path: str, output_path: str) -> bool:
    """
    Encrypt .env file to .env.enc
    
    Args:
        env_file_path: Path to source .env file
        output_path: Path to output encrypted file (.env.enc)
        
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        # Read .env file
        with open(env_file_path, 'rb') as f:
            data = f.read()
        
        # Get encryption key
        key = _get_encryption_key()
        
        # XOR encryption
        encrypted = bytearray()
        for i, byte in enumerate(data):
            encrypted.append(byte ^ key[i % len(key)])
        
        # Encode to base64
        encoded = base64.b64encode(bytes(encrypted))
        
        # Write encrypted file
        with open(output_path, 'wb') as f:
            f.write(encoded)
        
        return True
    except Exception as e:
        print_warning(f"Error encrypting .env file: {e}")
        return False

def decrypt_env_file(enc_file_path: str) -> Optional[str]:
    """
    Decrypt .env.enc file and return decrypted content as string
    
    Args:
        enc_file_path: Path to encrypted .env.enc file
        
    Returns:
        Optional[str]: Decrypted content as string, or None if failed
    """
    try:
        # Read encrypted file
        with open(enc_file_path, 'rb') as f:
            encoded = f.read()
        
        if not encoded:
            print_warning(f"Error decrypting .env.enc file: File is empty")
            return None
        
        # Decode from base64
        try:
            encrypted = base64.b64decode(encoded, validate=True)
        except Exception as e:
            print_warning(f"Error decrypting .env.enc file: Invalid base64 encoding - {e}")
            return None
        
        # Get decryption key
        key = _get_encryption_key()
        
        # XOR decryption
        decrypted = bytearray()
        for i, byte in enumerate(encrypted):
            decrypted.append(byte ^ key[i % len(key)])
        
        # Convert to string with error handling
        try:
            return decrypted.decode('utf-8')
        except UnicodeDecodeError as e:
            print_warning(f"Error decrypting .env.enc file: Invalid UTF-8 after decryption (wrong encryption key?) - {e}")
            # Try to decode with error handling to see partial content
            try:
                partial = decrypted.decode('utf-8', errors='replace')
                print_warning(f"Partial decrypted content (first 100 chars): {partial[:100]}")
            except:
                pass
            return None
    except FileNotFoundError:
        print_warning(f"Error decrypting .env.enc file: File not found - {enc_file_path}")
        return None
    except Exception as e:
        print_warning(f"Error decrypting .env.enc file: {e}")
        return None

def get_env_file_path() -> str:
    """
    Get the correct .env file path based on environment (dev vs production).
    
    - Development (running as Python script): Uses .env.dev
    - Production (running as EXE): Uses .env.pro
    
    Falls back to .env if specific file doesn't exist.
    
    Returns:
        str: Path to .env file to use
    """
    # Get app directory
    if getattr(sys, 'frozen', False):
        # Running as compiled exe (production)
        app_dir = os.path.dirname(sys.executable)
        env_file_pro = os.path.join(app_dir, ".env.pro")
        env_file = os.path.join(app_dir, ".env")
        
        # Try .env.pro first, fallback to .env
        if os.path.exists(env_file_pro):
            return env_file_pro
        else:
            return env_file
    else:
        # Running as script (development)
        app_dir = os.path.dirname(os.path.abspath(__file__))
        # Go up one level from src/ to project root
        parent_dir = os.path.dirname(app_dir)
        env_file_dev = os.path.join(parent_dir, ".env.dev")
        env_file = os.path.join(parent_dir, ".env")
        
        # Try .env.dev first, fallback to .env
        if os.path.exists(env_file_dev):
            return env_file_dev
        else:
            return env_file


def find_env_enc_file(env_file: str) -> Optional[str]:
    """
    Find .env.enc file in multiple locations (for onedir mode support)
    Tries:
    1. _internal directory (onedir mode - files are in _internal/) - priority for exe
    2. Same directory as env_file (.env.enc) - fallback
    
    Args:
        env_file: Path to .env file
        
    Returns:
        Optional[str]: Path to .env.enc file if found, None otherwise
    """
    # Try _internal directory first (onedir mode - priority for exe)
    if getattr(sys, 'frozen', False):
        # Running as exe - try _internal directory first
        exe_dir = os.path.dirname(sys.executable)
        internal_dir = os.path.join(exe_dir, "_internal")
        internal_enc_file = os.path.join(internal_dir, ".env.enc")
        if os.path.exists(internal_enc_file):
            return internal_enc_file
    
    # Try same directory as env_file (fallback)
    enc_file = env_file + ".enc"
    if os.path.exists(enc_file):
        return enc_file
    
    return None

def load_api_keys_from_env(env_file: str, api_key_name: str = "GEMINI_API_KEY") -> List[str]:
    """
    Load API keys from .env.enc (encrypted) or .env file.
    Supports multiple API providers: GEMINI_API_KEY, OPENAI_API_KEY, ANTHROPIC_API_KEY, etc.
    Supports: {api_key_name} (primary) and {api_key_name}_2, {api_key_name}_3, {api_key_name}_4, {api_key_name}_5 (backups)
    
    Args:
        env_file: Path to .env file (will also check for .env.enc)
        api_key_name: Name of API key variable (default: "GEMINI_API_KEY")
        
    Returns:
        List[str]: List of API keys (primary first, then backups)
    """
    api_keys = []
    
    # Check for encrypted file first (.env.enc) - try multiple locations
    enc_file = find_env_enc_file(env_file)
    if enc_file and os.path.exists(enc_file):
        # Decrypt and load from encrypted file
        decrypted_content = decrypt_env_file(enc_file)
        if decrypted_content:
            # Parse decrypted content
            for line in decrypted_content.split('\n'):
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                if '=' in line:
                    key, value = line.split('=', 1)
                    key = key.strip()
                    value = value.strip().strip('"').strip("'")
                    # Remove BOM if present
                    if value.startswith('\ufeff'):
                        value = value[1:]
                    if key.startswith(api_key_name):
                        if value and len(value) > 10:
                            api_keys.append(value)
                            if key == api_key_name:
                                print_info(f"Primary API key loaded from encrypted .env.enc")
                            else:
                                key_num = key.replace(f'{api_key_name}_', '')
                                print_info(f"Backup API key {key_num} loaded from encrypted .env.enc")
            if api_keys:
                return api_keys
    
    # Fallback to regular .env file
    # Try to load using dotenv first
    try:
        from dotenv import load_dotenv
        load_dotenv(env_file)
        
        # Load primary key
        primary_key = os.getenv(api_key_name)
        if primary_key and primary_key.strip() and len(primary_key.strip()) > 10:
            api_keys.append(primary_key.strip())
            print_info(f"Primary API key loaded from .env")
        
        # Load backup keys
        for i in range(2, 6):  # {api_key_name}_2 to {api_key_name}_5
            backup_key = os.getenv(f"{api_key_name}_{i}")
            if backup_key and backup_key.strip() and len(backup_key.strip()) > 10:
                api_keys.append(backup_key.strip())
                print_info(f"Backup API key {i-1} loaded from .env")
    except Exception as e:
        print_warning(f"Could not load API keys using dotenv: {e}")
    
    # Fallback: manual file reading
    if not api_keys and os.path.exists(env_file):
        try:
            encodings = ['utf-8', 'utf-16', 'utf-16-le', 'utf-16-be', 'latin-1']
            content = None
            
            for encoding in encodings:
                try:
                    with open(env_file, 'r', encoding=encoding) as f:
                        content = f.read()
                        break
                except (UnicodeDecodeError, UnicodeError):
                    continue
            
            if content:
                # Load primary key
                for line in content.splitlines():
                    line = line.strip()
                    if line.startswith('#') or not line:
                        continue
                    if line.startswith(f"{api_key_name}=") and not line.startswith(f"{api_key_name}_"):
                        key = line.split("=", 1)[1].strip().strip('"').strip("'")
                        if key.startswith('\ufeff'):
                            key = key[1:]
                        if key and len(key) > 10:
                            api_keys.append(key)
                            print_info(f"Primary API key loaded from .env (manual)")
                            break
                
                # Load backup keys
                for i in range(2, 6):
                    for line in content.splitlines():
                        line = line.strip()
                        if line.startswith('#') or not line:
                            continue
                        if line.startswith(f"{api_key_name}_{i}="):
                            key = line.split("=", 1)[1].strip().strip('"').strip("'")
                            if key.startswith('\ufeff'):
                                key = key[1:]
                            if key and len(key) > 10:
                                api_keys.append(key)
                                print_info(f"Backup API key {i-1} loaded from .env (manual)")
                                break
        except Exception as e:
            print_warning(f"Error reading .env file manually: {str(e)}")
    
    if not api_keys:
        print_error(f"No valid API keys found in .env file")
        print_info(f"Please add at least {api_key_name} to your .env file")
        print_info(f"You can also add {api_key_name}_2, {api_key_name}_3, {api_key_name}_4, {api_key_name}_5 as backups")
    
    return api_keys


def redact_sensitive_info(text: str) -> tuple[str, dict]:
    """
    Redact sensitive information from text before sending to API.
    Returns (redacted_text, mapping_dict) where mapping_dict maps placeholders to original values.
    
    Args:
        text: Original text to redact
        
    Returns:
        tuple: (redacted_text, mapping_dict)
    """
    import re
    mapping = {}
    redacted = text
    
    # Pattern for email addresses
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    email_count = 0
    # Find all matches first, then replace from end to start to preserve positions
    email_matches = list(re.finditer(email_pattern, redacted))
    for match in reversed(email_matches):  # Replace from end to start
        email_count += 1
        placeholder = f"[EMAIL_{email_count}]"
        original = match.group()
        mapping[placeholder] = original
        # Replace at specific position
        start, end = match.span()
        redacted = redacted[:start] + placeholder + redacted[end:]
    
    # Pattern for phone numbers (Vietnamese, international formats)
    phone_patterns = [
        r'\b0\d{9,10}\b',  # Vietnamese: 0901234567, 0123456789
        r'\b\+84\d{9,10}\b',  # International: +84901234567
        r'\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b',  # US format: 123-456-7890
        r'\b\d{4}[-.\s]?\d{3}[-.\s]?\d{3}\b',  # Alternative format
    ]
    phone_count = 0
    for pattern in phone_patterns:
        # Find all matches first
        phone_matches = list(re.finditer(pattern, redacted))
        for match in reversed(phone_matches):  # Replace from end to start
            # Skip if already replaced or is part of a placeholder
            context = redacted[max(0, match.start()-15):match.end()+15]
            if '[PHONE_' in context or '[EMAIL_' in context or '[CARD_' in context:
                continue
            phone_count += 1
            placeholder = f"[PHONE_{phone_count}]"
            original = match.group()
            mapping[placeholder] = original
            # Replace at specific position
            start, end = match.span()
            redacted = redacted[:start] + placeholder + redacted[end:]
    
    # Pattern for credit card numbers (13-19 digits, may have spaces/dashes)
    card_pattern = r'\b(?:\d{4}[-\s]?){3}\d{1,4}\b'
    card_count = 0
    card_matches = list(re.finditer(card_pattern, redacted))
    for match in reversed(card_matches):  # Replace from end to start
        # Skip if it's a phone number or part of placeholder
        context = redacted[max(0, match.start()-15):match.end()+15]
        if '[PHONE_' in context or '[EMAIL_' in context or '[CARD_' in context:
            continue
        # Validate it looks like a card (Luhn check would be better but simpler for now)
        digits_only = re.sub(r'[-\s]', '', match.group())
        if 13 <= len(digits_only) <= 19:
            card_count += 1
            placeholder = f"[CARD_{card_count}]"
            original = match.group()
            mapping[placeholder] = original
            # Replace at specific position
            start, end = match.span()
            redacted = redacted[:start] + placeholder + redacted[end:]
    
    return redacted, mapping


def restore_sensitive_info(text: str, mapping: dict) -> str:
    """
    Restore sensitive information from placeholders after translation.
    
    Args:
        text: Translated text with placeholders
        mapping: Dictionary mapping placeholders to original values
        
    Returns:
        str: Text with original sensitive info restored
    """
    restored = text
    for placeholder, original in mapping.items():
        restored = restored.replace(placeholder, original)
    return restored


def should_translate(text: Optional[str]) -> bool:
    """
    Check if text needs translation.
    
    Args:
        text: The text to check
        
    Returns:
        bool: True if text should be translated, False otherwise
    """
    text = clean_text(text)
    if not text or len(text) < 2:
        return False
    if re.match(r'^[\d\s,.-]+$', text):  # Contains only numbers and number formatting characters
        return False
    if isinstance(text, str) and text.startswith('='):  # Excel formula
        return False
    return True

def translate_batch(
    texts: List[str], 
    target_lang: str = "ja", 
    api_client: Any = None,
    progress_callback: Optional[Callable[[int, int], None]] = None,
    log_callback: Optional[Callable[[str], None]] = None,
    translation_context: str = "general"
) -> List[str]:
    """
    Translate a batch of texts to the target language.
    
    Args:
        texts: List of texts to translate
        target_lang: Target language code ("ja" for Japanese, "vi" for Vietnamese, "en" for English)
        api_client: OpenAI client instance
        progress_callback: Optional callback to report progress
        log_callback: Optional callback for logging messages
        translation_context: Context/department for specialized terminology ("general", "qc", "production", "engineering")
        
    Returns:
        List[str]: List of translated texts
    """
    if not texts:
        return []

    # Read system prompt from file (in config folder)
    # Support loading base prompt + context-specific prompt
    script_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(script_dir)
    config_dir = os.path.join(parent_dir, "config")
    
    # Map context to prompt file
    context_to_file = {
        "general": "translator-system-prompt.txt",
        "qc": "translator-system-prompt-qc.txt",
        "production": "translator-system-prompt-production.txt",
        "engineering": "translator-system-prompt-engineering.txt",
        "it": "translator-system-prompt-it.txt",
        "accounting": "translator-system-prompt-accounting.txt",
        "hr": "translator-system-prompt-hr.txt",
        "procurement": "translator-system-prompt-procurement.txt",
        "maintenance": "translator-system-prompt-maintenance.txt"
    }
    
    # Get prompt filename for selected context
    # Debug: Log the context received
    print_info(f"[Translate Batch] Received translation_context parameter: '{translation_context}'")
    prompt_filename = context_to_file.get(translation_context, "translator-system-prompt.txt")
    print_info(f"[Translate Batch] Mapped to prompt file: {prompt_filename}")
    
    # Load base prompt (common instructions)
    base_prompt_file = os.path.join(config_dir, "translator-system-prompt-base.txt")
    base_prompt = ""
    if os.path.exists(base_prompt_file):
        with open(base_prompt_file, 'r', encoding='utf-8') as f:
            base_prompt = f.read()
        print_info(f"Loaded base prompt: translator-system-prompt-base.txt")
    else:
        print_warning(f"Base prompt file not found: translator-system-prompt-base.txt, using context-specific file only")
    
    # Load context-specific prompt file
    prompt_file = os.path.join(config_dir, prompt_filename)
    
    # Fallback to general prompt if context-specific file doesn't exist
    if not os.path.exists(prompt_file):
        print_warning(f"Context-specific prompt file not found: {prompt_filename}, falling back to general")
        prompt_file = os.path.join(config_dir, "translator-system-prompt.txt")
    
    # Fallback to old location for compatibility
    if not os.path.exists(prompt_file):
        prompt_file = os.path.join(parent_dir, "translator-system-prompt.txt")
    
    # Combine base prompt + context-specific prompt
    system_prompt = ""
    if base_prompt:
        system_prompt = base_prompt + "\n\n"
        print_info(f"✓ Base prompt loaded and will be combined with domain-specific prompt")
    
    # Check if the context-specific prompt file exists
    if os.path.exists(prompt_file):
        with open(prompt_file, 'r', encoding='utf-8') as f:
            context_prompt = f.read()
        system_prompt += context_prompt
        # Log which prompt file is being used
        prompt_file_basename = os.path.basename(prompt_file)
        if base_prompt:
            print_info(f"✓ Combined prompts: base + {prompt_file_basename} (context: {translation_context})")
        else:
            print_info(f"Using translation prompt: {prompt_file_basename} (context: {translation_context})")
    else:
        # Use default prompt if file doesn't exist
        system_prompt = """You are a professional translator. Follow these rules strictly:
1. Output ONLY the translation, nothing else
2. DO NOT include the original text in your response
3. DO NOT add any explanations or notes
4. Keep IDs, model numbers, and special characters unchanged
5. Use standard terminology for technical terms
6. Preserve the original formatting (spaces, line breaks)
7. Use proper grammar and punctuation
8. Only keep unchanged: proper names, IDs, and technical codes
9. Translate all segments separated by "|||" and keep them separated with the same delimiter"""
        # Create default prompt file
        with open(prompt_file, 'w', encoding='utf-8') as f:
            f.write(system_prompt)
        print_info(f"Default prompt file created at: {prompt_file}")

    # Redact sensitive information before sending to API
    redacted_texts = []
    all_mappings = []  # Store mappings for each text
    
    for text in texts:
        redacted, mapping = redact_sensitive_info(text)
        redacted_texts.append(redacted)
        all_mappings.append(mapping)

    # Combine texts with separator
    separator = "|||"
    combined_text = separator.join(redacted_texts)

    # Determine translation direction based on parameter
    language_map = {
        "ja": "to Japanese",
        "vi": "to Vietnamese", 
        "en": "to English",
        "th": "to Thai",
        "zh": "to Chinese (Simplified)",
        "ko": "to Korean",
        "fr": "to French",
        "de": "to German",
        "ru": "to Russian"
    }
    direction = language_map.get(target_lang, "to the target language")
    
    user_prompt = f"Translate the following text {direction}, keeping segments separated by '{separator}':\n\n{combined_text}"

    # Debug: Show metadata only (no actual content)
    if len(texts) > 0:
        total_chars = sum(len(t) for t in texts)
        msg = f"Translating {len(texts)} texts {direction} (total {total_chars} characters)"
        print_info(msg)
        if log_callback:
            log_callback(msg)
        
        # Count redacted items
        total_redacted = sum(len(m) for m in all_mappings)
        if total_redacted > 0:
            protected_msg = f"Protected {total_redacted} sensitive information item(s)"
            print_info(protected_msg)
            if log_callback:
                log_callback(protected_msg)

    # Add retry mechanism for API calls
    retries = 0
    max_retries = 3  # Maximum number of retries for API calls
    delay_seconds = 2  # Delay between API calls
    
    while retries <= max_retries:
        try:
            # Update progress if callback provided
            if progress_callback:
                progress_callback(retries, max_retries)
                
            # Get current API client (handles fallback automatically)
            current_client = api_client
            if hasattr(api_client, 'get_current_client'):
                current_client = api_client.get_current_client()
                if not current_client:
                    if api_client.switch_to_next_key():
                        current_client = api_client.get_current_client()
                    else:
                        raise Exception("No available API clients")
                
            # Call translation API
            key_info = api_client.get_current_key_info() if hasattr(api_client, 'get_current_key_info') else "API key"
            print_info(f"Calling translation API with {key_info} (attempt {retries+1}/{max_retries+1})...")
            # Get model from client manager if available, otherwise use default
            model_name = api_client.model if hasattr(api_client, 'model') else "gemini-2.0-flash"
            
            response = current_client.chat.completions.create(
                model=model_name,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ]
            )
            
            # Debug response
            print_info("API response received, analyzing structure...")
            
            # Extract content from response (handle different response structures)
            translated_text = None
            
            # Try accessing as a dictionary first (most reliable method for unknown structures)
            try:
                response_dict = {}
                if hasattr(response, '__dict__'):
                    response_dict = response.__dict__
                elif hasattr(response, 'model_dump'):
                    response_dict = response.model_dump()
                else:
                    import json
                    try:
                        response_dict = json.loads(json.dumps(response, default=lambda o: o.__dict__))
                    except:
                        # Last resort, try string conversion
                        response_str = str(response)
                        if HAS_RICH:
                            print_info("Raw response preview:")
                            console.print(response_str[:100] + "...", style="dim")
                        else:
                            print_info(f"Raw response: {response_str[:100]}...")
                
                # Try to debug response structure on first attempt
                if retries == 0 and HAS_RICH:
                    keys = list(response_dict.keys()) if isinstance(response_dict, dict) else 'Not a dictionary'
                    print_info(f"Response keys: {keys}")
            except Exception as dict_err:
                print_warning(f"Could not convert response to dictionary: {str(dict_err)}")
            
            # First try standard OpenAI format
            try:
                if hasattr(response, 'choices') and response.choices and len(response.choices) > 0:
                    if hasattr(response.choices[0], 'message') and hasattr(response.choices[0].message, 'content'):
                        translated_text = response.choices[0].message.content
                        print_success("Found content in standard OpenAI format")
            except Exception as std_err:
                print_warning(f"Could not extract via standard path: {str(std_err)}")
            
            # If still no content, try alternative paths or direct access
            if not translated_text:
                try:
                    # Try direct string conversion (some APIs return the text directly)
                    if hasattr(response, '__str__'):
                        response_str = str(response).strip()
                        if response_str and len(response_str) > 0 and not response_str.startswith('{'):
                            translated_text = response_str
                            print_success("Using direct string conversion")
                except Exception as str_err:
                    print_warning(f"String conversion failed: {str(str_err)}")
            
            # Last resort: look for any attribute that might contain our text
            if not translated_text:
                print_info("Searching for content in response attributes...")
                content_attributes = ['content', 'text', 'answer', 'result', 'output', 'response', 'data']
                
                # Check direct attributes first
                for attr in content_attributes:
                    if hasattr(response, attr):
                        potential_content = getattr(response, attr)
                        if isinstance(potential_content, str) and potential_content.strip():
                            translated_text = potential_content
                            print_success(f"Found content in '{attr}' attribute")
                            break
                
                # If still not found, check nested attributes
                if not translated_text and isinstance(response_dict, dict):
                    # Check all dictionary paths that might contain the content
                    for attr in content_attributes:
                        if attr in response_dict and isinstance(response_dict[attr], str) and response_dict[attr].strip():
                            translated_text = response_dict[attr]
                            print_success(f"Found content in response_dict['{attr}']")
                            break
            
            # If we still don't have content, raise error with details
            if not translated_text:
                response_repr = str(response)[:500]  # Get truncated string representation
                raise ValueError(f"Could not extract translation content from API response of type {type(response).__name__}. Response preview: {response_repr}")

            # Split translation result into separate parts
            translated_parts = translated_text.split(separator)
            
            # Debug: Show metadata only
            if len(translated_parts) > 0:
                total_translated_chars = sum(len(p) for p in translated_parts)
                print_info(f"Translation received: {len(translated_parts)} parts, {total_translated_chars} characters")

            # Handle case when number of translated parts doesn't match
            if len(translated_parts) != len(texts):
                print_warning(f"Number of translated parts ({len(translated_parts)}) doesn't match number of original texts ({len(texts)})")
                # Ensure number of translated parts equals number of original texts
                if len(translated_parts) < len(texts):
                    # Not enough parts - extend with original texts
                    translated_parts.extend(redacted_texts[len(translated_parts):])
                elif len(translated_parts) > len(texts):
                    # Too many parts - handle based on input count
                    if len(texts) == 1:
                        # Single text input: join all parts back together (API may have included separator in translation)
                        num_parts = len(translated_parts)
                        combined = separator.join(translated_parts)
                        translated_parts = [combined]
                        print_info(f"Joined {num_parts} parts into single translation (API included separator in result)")
                else:
                    # Multiple texts: take only first N parts
                    extra_parts = len(translated_parts) - len(texts)
                    translated_parts = translated_parts[:len(texts)]
                    print_warning(f"Taking only first {len(texts)} parts, discarding {extra_parts} extra parts")
            
            # Restore sensitive information from placeholders
            restored_parts = []
            for i, translated_part in enumerate(translated_parts):
                if i < len(all_mappings):
                    restored = restore_sensitive_info(translated_part, all_mappings[i])
                    restored_parts.append(restored)
                else:
                    restored_parts.append(translated_part)
            
            translated_parts = restored_parts

            # Delay to avoid exceeding API limits
            time.sleep(delay_seconds)
            return translated_parts

        except Exception as e:
            error_str = str(e).lower()
            is_quota_error = "429" in error_str or "quota" in error_str or "rate limit" in error_str or "too many requests" in error_str
            
            retries += 1
            
            # If quota exceeded and we have more API keys, switch to next key
            if is_quota_error and hasattr(api_client, 'switch_to_next_key'):
                if api_client.switch_to_next_key():
                    print_warning(f"Quota exceeded on {api_client.get_current_key_info()}, switching to next key...")
                    retries = 0  # Reset retries when switching keys
                    time.sleep(1)  # Brief delay before retry with new key
                    continue
                else:
                    print_error(f"All API keys exhausted. Cannot continue translation.")
                    return texts
            
            # Regular retry logic
            if retries > max_retries:
                # If we have more API keys, try switching before giving up
                if hasattr(api_client, 'switch_to_next_key') and api_client.has_more_keys():
                    if api_client.switch_to_next_key():
                        print_warning(f"Max retries reached, switching to {api_client.get_current_key_info()}...")
                        retries = 0  # Reset retries when switching keys
                        time.sleep(2)  # Brief delay before retry with new key
                        continue
                
                print_error(f"Error translating batch after {max_retries} retries: {str(e)}")
                # Return original texts if translation fails
                return texts
            
            print_warning(f"API call failed (attempt {retries}/{max_retries}): {str(e)}")
            print_info(f"Retrying in {retries * 2} seconds...")
            time.sleep(retries * 2)  # Exponential backoff
            
    # This point should not be reached due to the return in the exception handler above
    return texts 

# Import processors from separate files
from excel_processor import process_excel_file
from word_processor import process_word_file
from powerpoint_processor import process_powerpoint_file, process_powerpoint_file_basic, AdvancedPowerPointProcessor

# Legacy function definitions removed - now imported from processor modules
# All processor functions and helper functions have been moved to separate files:
# - excel_processor.py
# - word_processor.py  
# - powerpoint_processor.py

def process_file(
    input_path: str, 
    target_lang: str = "ja",
    output_dir: Optional[str] = None,
    progress: Optional[Any] = None,
    log_callback: Optional[Callable[[str], None]] = None
) -> Optional[str]:
    """
    Process a file based on its type.
    
    Args:
        input_path: Path to the file
        target_lang: Target language code
        progress: Optional rich progress instance
        log_callback: Optional callback function(message) to log messages to GUI
        
    Returns:
        Optional[str]: Path to the translated file, or None if processing failed
    """
    # Check if file exists
    if not os.path.exists(input_path):
        print_error(f"File does not exist: {input_path}")
        return None
    
    # Import required libraries
    try:
        from dotenv import load_dotenv
        from openai import OpenAI
    except ImportError as e:
        print_error(f"Failed to import required libraries: {str(e)}")
        return None
    
    # Load environment variables from .env file
    # Use get_env_file_path() to get correct file (dev vs pro)
    env_file = get_env_file_path()
    
    # Get API configuration
    api_config = get_api_config(env_file)
    
    # Load all API keys (primary + backups) - support multiple providers
    api_keys = load_api_keys_from_env(env_file, api_key_name=api_config["api_key_name"])
    if not api_keys:
        print_error(f"No API keys found in .env file.")
        print_info(f"Please add at least {api_config['api_key_name']} to your .env file.")
        print_info(f"You can also add {api_config['api_key_name']}_2, {api_config['api_key_name']}_3, {api_config['api_key_name']}_4, {api_config['api_key_name']}_5 as backups.")
        return None
    
    # Initialize API Client Manager with fallback support
    try:
        client_manager = APIClientManager(
            api_keys, 
            base_url=api_config["base_url"],
            model=api_config["model"]
        )
        print_info(f"API Client Manager initialized with {len(api_keys)} API key(s)")
        if len(api_keys) > 1:
            print_info(f"   Primary: 1 key, Backups: {len(api_keys) - 1} key(s)")
    except Exception as e:
        print_error(f"Failed to initialize API Client Manager: {str(e)}")
        return None
    
    # Use the manager as the client (it will handle fallback automatically)
    client = client_manager
    
    # Determine file type
    file_type = get_file_type(input_path)
    
    # Process file based on type
    if file_type == DocType.EXCEL:
        print_info(f"Processing Excel file: {os.path.basename(input_path)}")
        return process_excel_file(input_path, target_lang, client, output_dir, progress, log_callback)
    elif file_type == DocType.WORD:
        print_info(f"Processing Word file: {os.path.basename(input_path)}")
        return process_word_file(input_path, target_lang, client, output_dir, progress, log_callback)
    elif file_type == DocType.POWERPOINT:
        print_info(f"Processing PowerPoint file: {os.path.basename(input_path)}")
        return process_powerpoint_file(input_path, target_lang, client, output_dir, progress, log_callback)
    else:
        print_error(f"Unsupported file type: {os.path.basename(input_path)}")
        return None

def process_directory(
    input_dir: str, 
    target_lang: str = "ja",
    output_dir: Optional[str] = None,
    progress_callback: Optional[Callable[[int, int], None]] = None,
    log_callback: Optional[Callable[[str], None]] = None
) -> Tuple[List[str], List[str]]:
    """
    Process all supported files in the input directory.
    
    Args:
        input_dir: Path to the input directory
        target_lang: Target language code
        progress_callback: Optional callback function(current, total) called after each file is processed
        log_callback: Optional callback function(message) to log messages to GUI
        
    Returns:
        Tuple[List[str], List[str]]: Lists of successful and failed files
    """
    # Ensure directory path exists
    if not os.path.isdir(input_dir):
        print_error(f"Directory does not exist: {input_dir}")
        return [], []

    # Find all supported files in the directory
    excel_files = glob.glob(os.path.join(input_dir, "*.xlsx")) + glob.glob(os.path.join(input_dir, "*.xls"))
    word_files = glob.glob(os.path.join(input_dir, "*.docx")) + glob.glob(os.path.join(input_dir, "*.doc"))
    ppt_files = glob.glob(os.path.join(input_dir, "*.pptx")) + glob.glob(os.path.join(input_dir, "*.ppt"))
    # Filter out:
    # 1. Temporary files (starting with ~$)
    # 2. Hidden files (starting with .)
    def should_process_file(file_path: str) -> bool:
        filename = os.path.basename(file_path)
        # Skip temporary files
        if filename.startswith('~$'):
            return False
        # Skip hidden files
        if filename.startswith('.'):
            return False
        return True
    
    excel_files = [f for f in excel_files if should_process_file(f)]
    word_files = [f for f in word_files if should_process_file(f)]
    ppt_files = [f for f in ppt_files if should_process_file(f)]
    
    all_files = excel_files + word_files + ppt_files

    if not all_files:
        print_warning(f"No supported files found in directory: {input_dir}")
        print_info("Supported formats: .xlsx, .xls, .docx, .doc, .pptx, .ppt")
        return [], []

    print_info(f"Found {len(excel_files)} Excel files, {len(word_files)} Word files, and {len(ppt_files)} PowerPoint files")
    
    # Log file names for debugging
    if excel_files:
        print_info(f"Excel files: {[os.path.basename(f) for f in excel_files]}")
    if word_files:
        print_info(f"Word files: {[os.path.basename(f) for f in word_files]}")
    if ppt_files:
        print_info(f"PowerPoint files: {[os.path.basename(f) for f in ppt_files]}")

    # Initialize rich progress if available
    progress = None
    if HAS_RICH:
        progress = Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            console=console
        )
    else:
        print_info("Install 'rich' package for enhanced progress display")
    
    # Process each file
    successful_files = []
    failed_files = []
    
    # Start progress tracking if available
    if progress:
        with progress:
            main_task = progress.add_task(f"[blue]Processing {len(all_files)} files", total=len(all_files))
            
            for file_idx, file_path in enumerate(all_files):
                # Skip temporary files (usually starting with ~$)
                if os.path.basename(file_path).startswith('~$'):
                    print_info(f"Skipping temporary file: {os.path.basename(file_path)}")
                    continue

                progress.update(main_task, description=f"[blue]Processing file {file_idx+1}/{len(all_files)}")
                
                output_file = process_file(file_path, target_lang, output_dir, progress, log_callback)
                
                if output_file:
                    successful_files.append(os.path.basename(file_path))
                else:
                    failed_files.append(os.path.basename(file_path))
                    
                progress.update(main_task, advance=1)
                
                # Call progress callback if provided
                if progress_callback:
                    try:
                        progress_callback(file_idx + 1, len(all_files))
                    except Exception as e:
                        print_warning(f"Progress callback error: {e}")
    else:
        # Process without rich progress display
        for file_idx, file_path in enumerate(all_files):
            # Skip temporary files (usually starting with ~$)
            if os.path.basename(file_path).startswith('~$'):
                print_info(f"Skipping temporary file: {os.path.basename(file_path)}")
                continue

            print_info(f"Processing file {file_idx+1}/{len(all_files)}: {os.path.basename(file_path)}")
            
            output_file = process_file(file_path, target_lang, output_dir)
            
            if output_file:
                successful_files.append(os.path.basename(file_path))
            else:
                failed_files.append(os.path.basename(file_path))
            
            # Call progress callback if provided
            if progress_callback:
                try:
                    progress_callback(file_idx + 1, len(all_files))
                except Exception as e:
                    print_warning(f"Progress callback error: {e}")

    print_header("Directory Processing Summary")
    print_success(f"Successfully processed: {len(successful_files)} files")
    if failed_files:
        print_warning(f"Failed to process: {len(failed_files)} files")
        if len(failed_files) <= 5:
            for failed in failed_files:
                print_warning(f"  - {failed}")
        else:
            for failed in failed_files[:5]:
                print_warning(f"  - {failed}")
            print_warning(f"  ... and {len(failed_files) - 5} more")

    return successful_files, failed_files

# PDF file processing removed to streamline the application
# process_powerpoint_file is now imported from powerpoint_processor.py

def main():
    """Main entry point for the translator"""
    # Display header
    print_header("Office Document Translator")
    
    # Setup argument parser
    parser = argparse.ArgumentParser(
        description='Translate Microsoft Office documents (Excel, Word, PowerPoint) between multiple languages',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    
    # Add arguments
    parser.add_argument('--to', choices=['ja', 'vi', 'en', 'th', 'zh', 'ko'], default='ja',
                        help='Target language (ja: Japanese, vi: Vietnamese, en: English, th: Thai, zh: Chinese, ko: Korean)')
    parser.add_argument('--file', type=str, help='Path to a specific file to translate')
    parser.add_argument('--dir', type=str, help='Path to a directory containing files to translate')
    parser.add_argument('--output-dir', type=str, help='Path to the output directory (defaults to "./output")')
    parser.add_argument('--version', action='version', version='Office Document Translator v1.0.0')
    
    # Parse arguments
    args = parser.parse_args()
    
    # Check if required libraries are installed
    if not check_and_install_dependencies():
        print_error("Failed to install or load required dependencies.")
        return 1
    
    # Set output directory if specified
    # This part is a bit redundant as the individual processors also create the output dir
    # but it's good for clarity and potential future use.
    output_dir_arg = args.output_dir
    if output_dir_arg:
        if not os.path.exists(output_dir_arg):
            os.makedirs(output_dir_arg)
            print_info(f"Output directory created: {output_dir_arg}")
        # Note: Individual processors will use their own output logic within script_dir/output for now.
        # This global output_dir_arg is not directly passed to them yet.
        print_info(f"Global output directory specified: {output_dir_arg} (Note: processors use local ./output)")

    # Create input directory if not specified and no file/dir given
    if not args.file and not args.dir:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        input_dir = os.path.join(script_dir, "input")
        
        if not os.path.exists(input_dir):
            os.makedirs(input_dir)
            print_info(f"Created 'input' directory at: {input_dir}")
            print_info("Please place files to translate in this directory or use --file/--dir arguments.")
            return 0 # Exit gracefully if input dir was just created
        
        args.dir = input_dir # Default to processing the input directory
        print_info(f"No file or directory specified, defaulting to input directory: {args.dir}")

    # Process based on provided arguments
    target_lang = args.to
    language_names = {
        'ja': 'Japanese',
        'vi': 'Vietnamese',
        'en': 'English',
        'th': 'Thai',
        'zh': 'Chinese (Simplified)',
        'ko': 'Korean',
        'fr': 'French',
        'de': 'German',
        'ru': 'Russian'
    }
    print_info(f"Target language: {language_names.get(target_lang, target_lang)}")
    
    start_time = time.time()
    
    if args.file:
        # Process single file
        if os.path.exists(args.file):
            output_file = process_file(args.file, target_lang)
            if output_file:
                print_success(f"File successfully translated: {output_file}")
            else:
                print_error(f"Failed to translate file: {args.file}")
                return 1
        else:
            print_error(f"File not found: {args.file}")
            return 1
    elif args.dir:
        # Process directory
        if os.path.isdir(args.dir):
            successful, failed = process_directory(args.dir, target_lang)
            if not successful and failed:
                print_warning("No files were successfully translated.")
                # return 1 # Don't exit if some files failed but others might have succeeded
            elif not successful and not failed:
                print_info("No files found to process in the directory.")
        else:
            print_error(f"Directory not found: {args.dir}")
            return 1
    else:
        # This case should ideally be handled by the default input directory logic
        print_error("No file or directory specified, and default input directory is empty or not found.")
        return 1
    
    end_time = time.time()
    elapsed_time = end_time - start_time
    
    # Format time nicely
    if elapsed_time < 60:
        time_str = f"{elapsed_time:.2f} seconds"
    elif elapsed_time < 3600:
        minutes = int(elapsed_time // 60)
        seconds = elapsed_time % 60
        time_str = f"{minutes} minute{'s' if minutes != 1 else ''} and {seconds:.2f} seconds"
    else:
        hours = int(elapsed_time // 3600)
        minutes = int((elapsed_time % 3600) // 60)
        seconds = elapsed_time % 60
        time_str = f"{hours} hour{'s' if hours != 1 else ''}, {minutes} minute{'s' if minutes != 1 else ''}, and {seconds:.2f} seconds"
    
    print_info(f"Total execution time: {time_str}")
    
    return 0

if __name__ == "__main__":
    sys.exit(main()) 